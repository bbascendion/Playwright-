import { Page, expect } from '@playwright/test';

export class LoginPage {
  constructor(private page: Page) {}

  private usernameTxt = '#username';
  private passwordTxt = '#password';
  private loginBtn = '#Login';

  async navigate(url: string) {
    await this.page.goto(url, {
      waitUntil: 'networkidle'
    });
  }

  async login(username: string, password: string) {
    await this.page.fill(this.usernameTxt, username);
    await this.page.fill(this.passwordTxt, password);
    await this.page.click(this.loginBtn);
  }

  async verifyLoginSuccessful() {
    await expect(this.page).not.toHaveURL(/login/i);
  }
}
