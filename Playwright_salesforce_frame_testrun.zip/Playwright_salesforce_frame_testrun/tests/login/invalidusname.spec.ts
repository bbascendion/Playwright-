import { test, expect } from '@playwright/test';
import { env } from '../../config/env';

test('Invalid Username With Valid Password', async ({ page }) => {
  test.setTimeout(60000);

  await page.goto(env.baseUrl!, {
    waitUntil: 'domcontentloaded'
  });

  console.log('Login page opened');

  // Use an invalid username; the configured password is valid.
  await page.locator('#username').fill(
    'invalid.user@test.com'
  );

  console.log('Invalid username entered; valid password will be used');

  // Continue to the password step.
  await page.locator('#Login').click();

  // Wait for Password Field
  const passwordField = page.locator('#password');

  await passwordField.waitFor({
    state: 'visible',
    timeout: 30000
  });

  // Keep the password valid so this test isolates the username.
  await passwordField.fill(env.password!);

  console.log('Password entered');

  // Submit the invalid username and valid password.
  await page.locator('#Login').click();

  console.log('Login submitted');

  // Verify Error Message
  const errorMessage = page.locator('#error');

  await expect(errorMessage).toBeVisible({
    timeout: 30000
  });

  await expect(errorMessage).toContainText(
    'Please check your username and password'
  );

  console.log(
    'Invalid Username validation successful'
  );
});