import { test, expect } from '@playwright/test';
import { env } from '../../config/env';

test('Invalid Password Login', async ({ page }) => {
  test.setTimeout(60000);

  // Navigate to Salesforce Login Page
  await page.goto(env.baseUrl!, {
    waitUntil: 'domcontentloaded'
  });

  console.log('✅ Login page opened');

  // Enter Valid Username
  await page.locator('#username').fill(
    env.username!
  );

  console.log('✅ Valid username entered');

  // Submit Username
  await page.locator('#Login').click();

  // Wait for Password Page
  const passwordField = page.locator('#password');

  await passwordField.waitFor({
    state: 'visible',
    timeout: 30000
  });

  // Enter Invalid Password
  await passwordField.fill(
    'InvalidPassword123'
  );

  console.log('Invalid password entered');

  // Click Login
  await page.locator('#Login').click();

  console.log(' Login submitted');

  // Verify Error Message
  const errorMessage = page.locator('#error');

  await expect(errorMessage).toBeVisible({
    timeout: 30000
  });

  await expect(errorMessage).toContainText(
    'Please check your username and password'
  );

  console.log(
    'Invalid Password validation successful'
  );
});