import { test, expect } from '@playwright/test';
import { env } from '../../config/env';

test('Salesforce Login', async ({ page, context }) => {

  test.setTimeout(180000);

  console.log('URL:', env.baseUrl);

  await page.goto(env.baseUrl!, {
    waitUntil: 'domcontentloaded'
  });
  // Username Page
  await page.locator('#username').waitFor({
    state: 'visible',
    timeout: 30000
  });

  await page.locator('#username').fill(env.username!);

  console.log(' Username entered');

  // Submit Username
  await page.locator('#Login').click();

  console.log('Username submitted');

  // Wait for Password Page
  const passwordField = page.locator('#password');

  await passwordField.waitFor({
    state: 'visible',
    timeout: 60000
  });

  // Enter Password
  await passwordField.fill(env.password!);

  console.log('Password entered');

  // Remember Me
  const rememberMe = page.locator('#rememberUn');

  if (await rememberMe.isVisible().catch(() => false)) {
    if (!(await rememberMe.isChecked())) {
      await rememberMe.check();
      console.log('Remember Me checked');
    }
  }

  // Login
  await page.locator('#Login').click();

  console.log('Login submitted');

  // MFA Wait
  console.log('Waiting 30 seconds for MFA code entry...');
  await page.waitForTimeout(30000);

  // Verify Button
  const verifyButton = page.locator(
    'input[value="Verify"], button:has-text("Verify")'
  );

  if (await verifyButton.count() > 0) {
    await verifyButton.first().click();
    console.log(' Verify button clicked');
  }

  // Allow post-login page to settle before checking Classic vs Lightning
  await page.waitForLoadState('domcontentloaded');
  await page.waitForTimeout(5000);

  // ---- Switch to Lightning if Classic UI loaded ----
  const isLightningAlready = page.url().includes('/lightning/');

  if (!isLightningAlready) {
    console.log('Lightning URL not detected, checking for Classic UI...');

    const switchToLightningLink = page.locator(
      '#switch-to-lightning, a:has-text("Switch to Lightning Experience"), a:has-text("Switch to Lightning")'
    );

    const switchLinkVisible = await switchToLightningLink
      .first()
      .isVisible()
      .catch(() => false);

    if (switchLinkVisible) {
      console.log('Classic UI detected. Clicking "Switch to Lightning Experience"...');

      await switchToLightningLink.first().click();

      console.log('Switch to Lightning clicked');

      // Give it time to redirect/render Lightning
      await page.waitForLoadState('domcontentloaded');
    } else {
      console.log('Switch to Lightning link not found - possibly already on Lightning or link not rendered yet');
    }
  } else {
    console.log('Lightning URL already detected, no switch needed');
  }

  // Wait for Salesforce Lightning Home
  await page.waitForURL('**/lightning/**', {
    timeout: 180000
  });

  console.log(' Lightning URL Loaded');

  // Allow Lightning UI to finish rendering
  await page.waitForTimeout(5000);

  // Verify Accounts Tab
  const accountsTab = page.getByRole('link', {
    name: 'Accounts'
  });

  await accountsTab.waitFor({
    state: 'visible',
    timeout: 60000
  });

  console.log('Accounts tab available');

  await expect(accountsTab).toBeVisible();

  console.log(' Salesforce Home Loaded');

  // Save Auth Session
  await context.storageState({
    path: 'auth.json'
  });

  console.log(' Auth State Saved');

  console.log('Salesforce Login Successful');
});