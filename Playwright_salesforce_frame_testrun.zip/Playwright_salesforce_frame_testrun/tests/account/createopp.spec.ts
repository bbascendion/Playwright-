// import { test, expect } from '@playwright/test';
// import { routes } from '../../config/routes';

// test.use({
//   storageState: 'auth.json'
// });

// test('Create Opportunity From Existing Account', async ({
//   page
// }) => {

//   const accountName =
//     'MASONRY-CNCRT SANTO-N TWOPOUNDBAG CRGN D-I';

//   // Open Accounts Object
//   await page.goto(routes.accountList('filterName=__Recent'));

//   console.log('Accounts Page Opened');

//   // Open List View Dropdown
//   const listViewDropdown =
//     page.locator(
//       'button[title*="Select a List View"]'
//     );

//   await listViewDropdown.waitFor({
//     state: 'visible',
//     timeout: 30000
//   });

//   await listViewDropdown.click();

//   console.log('List View Dropdown Opened');

//   // Select All Accounts
//   await page
//     .getByText('All Accounts', {
//       exact: true
//     })
//     .click();

//   console.log('All Accounts Selected');

//   // Search Existing Account
//   const searchBox =
//     page.getByPlaceholder(
//       'Search this list...'
//     );

//   await searchBox.waitFor({
//     state: 'visible',
//     timeout: 30000
//   });

//   await searchBox.click();
// await searchBox.clear();
// await searchBox.fill(accountName);

// // Trigger Salesforce search
// await searchBox.press('Enter');

// console.log(
//   `Searching Account: ${accountName}`
// );

// // Wait until the account appears in results
// const accountLink = page
//   .getByRole('link', {
//     name: accountName,
//     exact: true
//   })
//   .first();

// await expect(accountLink).toBeVisible({
//   timeout: 30000
// });

// console.log('Search Result Found');

// // Click account
// await accountLink.click();

// console.log(
//   `Account Opened: ${accountName}`
// );

//   // Click New Opportunity
//   const newOpportunityButton =
//     page.locator(
//       '[name="Global.NewOpportunity"]'
//     );

//   await newOpportunityButton.waitFor({
//     state: 'visible',
//     timeout: 30000
//   });

//   await newOpportunityButton.click();

//   console.log(
//     'New Opportunity Button Clicked'
//   );

//   // Opportunity Name
//   const opportunityNameField =
//     page.getByLabel(
//       'Opportunity Name'
//     );

//   await opportunityNameField.waitFor({
//     state: 'visible',
//     timeout: 30000
//   });

//   await opportunityNameField.fill(
//     accountName
//   );

//   console.log(
//     `Opportunity Name Entered: ${accountName}`
//   );

//   // Stage Dropdown
  
// // Stage Dropdown Selection
// // Open Stage dropdown
// const stageDropdown = page.locator(
//   '.forceInputPicklist'
// ).first();

// await stageDropdown.waitFor({
//   state: 'visible',
//   timeout: 30000
// });

// await stageDropdown.click();

// console.log(' Stage Dropdown Opened');

// // Select Prospecting
// const prospectingOption = page.locator(
//   'a[title="Prospecting"], li a:text-is("Prospecting")'
// );

// await prospectingOption.waitFor({
//   state: 'visible',
//   timeout: 10000
// });

// await prospectingOption.click();

// console.log(' Stage Selected: Prospecting');

//   // Save Opportunity
//   const saveButton =
//     page.getByRole(
//       'button',
//       { name: 'Save' }
//     );

//   await saveButton.waitFor({
//     state: 'visible',
//     timeout: 30000
//   });

//   await saveButton.click();

//   console.log(
//     'Opportunity Saved'
//   );

//   // Validation
//   await expect(
//     page.getByText(accountName)
//       .first()
//   ).toBeVisible({
//     timeout: 30000
//   });

//   console.log(
//     ` Opportunity Created Successfully: ${accountName}`
//   );
// });