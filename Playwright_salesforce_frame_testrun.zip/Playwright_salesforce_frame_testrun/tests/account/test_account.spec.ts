import { test, expect, Page, Frame, FrameLocator, TestInfo } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { env } from '../../config/env';
import { getRandomAccountName } from '../../utils/account';

// ===========================================================================
// Shared helpers
// ===========================================================================
function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}


function parseCsvLine(line: string): string[] {
  const values: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];

    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      values.push(current);
      current = '';
    } else {
      current += char;
    }
  }

  values.push(current);

  return values.map((value) => value.trim());
}

async function readCsv(
  filePath: string
): Promise<Record<string, string>[]> {
  if (!fs.existsSync(filePath)) {
    throw new Error(`CSV file not found: ${filePath}`);
  }

  const content = fs.readFileSync(filePath, 'utf8');

  const lines = content
    .split(/\r?\n/)
    .filter((line) => line.trim() !== '');

  if (lines.length === 0) {
    return [];
  }

  const headers = parseCsvLine(lines[0]);

  return lines.slice(1).map((line) => {
    const values = parseCsvLine(line);
    const row: Record<string, string> = {};

    headers.forEach((header, index) => {
      row[header] = values[index] ?? '';
    });

    return row;
  });
}

type AccountCsvDetails = {
  accountName: string;
  billingStreet: string;
  billingCity: string;
  billingState: string;
  billingPostalCode: string;
  billingCountry: string;
};

function getAccountCsvDetails(
  records: Record<string, string>[],
  accountName: string
): AccountCsvDetails {
  const row = records.find(
    (record) =>
      (record['forseva1__Account__r.Name'] || '').trim().toLowerCase() ===
      accountName.trim().toLowerCase()
  );

  if (!row) {
    throw new Error(
      `No CSV row found for selected account "${accountName}". ` +
      `The account name must exist in salesfrocedataauto.csv.`
    );
  }

  return {
    accountName: row['forseva1__Account__r.Name'] || '',
    billingStreet: row['forseva1__Address1__c'] || '',
    billingCity: row['forseva1__Account__r.BillingCity'] || '',
    billingState: row['forseva1__Account__r.BillingState'] || '',
    billingPostalCode: row['forseva1__Account__r.BillingPostalCode'] || '',
    billingCountry: row['forseva1__Account__r.BillingCountry'] || '',
  };
}

async function captureScreenshot(
  page: Page,
  testInfo: TestInfo,
  label: string
): Promise<string> {
  const dir = path.join(process.cwd(), 'test-results', 'screenshots');
  fs.mkdirSync(dir, { recursive: true });

  const safeLabel = label.replace(/[^a-z0-9-_]+/gi, '_');
  const filePath = path.join(dir, `${Date.now()}-${safeLabel}.png`);

  await page.screenshot({ path: filePath, fullPage: true });

  await testInfo.attach(label, {
    path: filePath,
    contentType: 'image/png',
  });

  console.log(`Screenshot captured: ${filePath}`);
  return filePath;
}

async function expectAccountHeading(page: Page, accountName: string): Promise<void> {
  await expect(
    page.getByRole('heading', {
      name: new RegExp(`Account ${escapeRegExp(accountName)}`, 'i'),
    })
  ).toBeVisible({ timeout: 30000 });
}

async function gotoAccount(
  page: Page,
  accountUrl: string,
  accountName: string
): Promise<void> {
  await page.goto(accountUrl, { waitUntil: 'domcontentloaded' });
  await expectAccountHeading(page, accountName);
  await page.waitForTimeout(3000);
}

/**
 * Clicks an action button in the Account highlights panel
 * (Review Credit, Prequalify Credit, Consumer Credit Review).
 *
 * These are visible directly on the page, so the button is clicked without
 * opening the dropdown. The "Show more actions" menu is used only as a
 * fallback if the button is not visible (for example on a narrow viewport).
 */
async function clickAccountAction(
  page: Page,
  actionName: string,
  testInfo?: TestInfo,
  screenshotLabel?: string
): Promise<void> {
  const exact = new RegExp(`^${escapeRegExp(actionName)}$`, 'i');

  const directAction = page
    .getByRole('button', { name: exact })
    .or(page.getByRole('link', { name: exact }))
    .first();

  const directVisible = await directAction
    .waitFor({ state: 'visible', timeout: 15000 })
    .then(() => true)
    .catch(() => false);

  if (directVisible) {
    console.log(`"${actionName}" button is visible on the Account page.`);

    if (testInfo && screenshotLabel) {
      await captureScreenshot(page, testInfo, screenshotLabel);
    }

    await directAction.click();
    console.log(`"${actionName}" button clicked.`);
    return;
  }

  console.log(
    `"${actionName}" not visible on the page; falling back to the actions dropdown.`
  );

  const showMoreActions = page.getByRole('button', { name: /show more actions/i });

  await expect(showMoreActions).toBeVisible({ timeout: 30000 });
  await showMoreActions.click();

  const menuAction = page
    .getByRole('menuitem', { name: exact })
    .or(page.locator('a', { hasText: exact }))
    .first();

  await expect(menuAction).toBeVisible({ timeout: 30000 });

  if (testInfo && screenshotLabel) {
    await captureScreenshot(page, testInfo, screenshotLabel);
  }

  await menuAction.click();
  console.log(`"${actionName}" clicked from dropdown.`);
}

// ===========================================================================
// Visualforce iframe helpers
// ===========================================================================
type FrameProbe = (frame: Frame) => Promise<boolean>;

function frameToFrameLocator(page: Page, frame: Frame): FrameLocator {
  const name = frame.name();

  if (name) {
    return page.frameLocator(`iframe[name="${name}"]`);
  }

  try {
    const url = new URL(frame.url());
    return page.frameLocator(`iframe[src*="${url.pathname}"]`).first();
  } catch {
    const children = page.frames().filter((f) => f !== page.mainFrame());
    return page.frameLocator('iframe').nth(Math.max(children.indexOf(frame), 0));
  }
}

async function findVfFrame(page: Page, probe: FrameProbe): Promise<Frame | null> {
  for (const frame of page.frames()) {
    if (frame === page.mainFrame() || frame.isDetached()) {
      continue;
    }

    try {
      if (await probe(frame)) {
        return frame;
      }
    } catch {
      // Frame navigating or detached; ignore.
    }
  }

  return null;
}

async function waitForVfFrame(
  page: Page,
  probe: FrameProbe,
  description: string,
  timeoutMs = 90000
): Promise<FrameLocator> {
  const start = Date.now();

  while (Date.now() - start < timeoutMs) {
    const frame = await findVfFrame(page, probe);

    if (frame) {
      console.log(
        `Found frame for "${description}": name="${frame.name()}" url="${frame.url()}"`
      );
      return frameToFrameLocator(page, frame);
    }

    await page.waitForTimeout(2000);
  }

  const dump = page
    .frames()
    .map((f, i) => `  [${i}] name="${f.name()}" url="${f.url()}"`)
    .join('\n');

  throw new Error(
    `Timed out after ${timeoutMs}ms waiting for iframe: ${description}\nFrames:\n${dump}`
  );
}

const requestReportsProbe: FrameProbe = async (frame) =>
  frame
    .getByRole('button', { name: /request reports/i })
    .or(frame.locator('input[value*="Request Reports" i]'))
    .or(frame.getByRole('heading', { name: /request .*credit reports/i }))
    .or(frame.getByText(/request .*credit reports/i))
    .first()
    .isVisible()
    .catch(() => false);

const requestReportsButtonProbe: FrameProbe = async (frame) =>
  frame
    .getByRole('button', { name: /request reports/i })
    .or(frame.locator('input[value*="Request Reports" i]'))
    .first()
    .isVisible()
    .catch(() => false);

const goButtonProbe: FrameProbe = async (frame) =>
  frame
    .getByRole('button', { name: /^Go$/i })
    .or(frame.locator('input[value="Go" i]'))
    .first()
    .isVisible()
    .catch(() => false);

const doneButtonProbe: FrameProbe = async (frame) =>
  frame
    .getByRole('button', { name: /^Done$/i })
    .or(frame.locator('input[value="Done" i]'))
    .first()
    .isVisible()
    .catch(() => false);

// ===========================================================================
// LMA login -> Subscribers -> Ascendion -> subscriber Login -> Lightning
// (performed ONCE per run)
// ===========================================================================
async function isSubscriberAccountPage(page: Page): Promise<boolean> {
  return /\/lightning\/(r|o)\/Account\//i.test(page.url());
}

async function loginToSalesforce(page: Page): Promise<Page> {
  console.log('Navigating to LMA...');

  await page.goto(env.baseUrl!, { waitUntil: 'domcontentloaded' });

  if (await isSubscriberAccountPage(page)) {
    console.log('Subscriber org session already available.');
    return page;
  }

  const usernameField = page.locator('#username');

  const loginPageDisplayed = await usernameField.isVisible().catch(() => false);

  if (loginPageDisplayed) {
    await usernameField.fill(env.username!);
    await page.locator('#Login').click();

    const passwordField = page.locator('#password');

    await expect(passwordField).toBeVisible({ timeout: 60000 });

    await passwordField.fill(env.password!);
    await page.locator('#Login').click();

    console.log('LMA login submitted.');
  } else {
    console.log('Existing LMA session detected.');
  }

  // LMA opens in Salesforce Classic, so do not wait for a /lightning/ URL.
  const subscribersTab = page.getByRole('link', { name: /^Subscribers$/i });

  await expect(subscribersTab).toBeVisible({ timeout: 120000 });
  await subscribersTab.click();

  console.log('Subscribers tab opened.');

  await expect(
    page.getByText('Subscriber Organizations', { exact: true })
  ).toBeVisible({ timeout: 30000 });

  // First textbox = global search; last textbox = Subscriber list search.
  const visibleTextboxes = page.getByRole('textbox');
  const textboxCount = await visibleTextboxes.count();

  console.log(`Textboxes found on Subscribers page: ${textboxCount}`);

  if (textboxCount < 2) {
    throw new Error('Subscriber Organization search textbox was not found.');
  }

  const subscriberSearch = visibleTextboxes.last();

  await expect(subscriberSearch).toBeVisible({ timeout: 30000 });

  await subscriberSearch.fill(env.subscriberOrgId!);
  await subscriberSearch.press('Enter');

  console.log(`Subscriber Org searched: ${env.subscriberOrgId}`);

  const ascendionLink = page.getByRole('link', {
    name: /^Ascendion Engineering Private Limited$/i,
  });

  await expect(ascendionLink).toBeVisible({ timeout: 30000 });

  const [overviewPage] = await Promise.all([
    page.context().waitForEvent('page'),
    ascendionLink.click(),
  ]);

  await overviewPage.waitForLoadState('domcontentloaded');

  console.log('Overview URL:', overviewPage.url());

  await expect(overviewPage.locator('body')).toContainText('Login Access Granted', {
    timeout: 30000,
  });

  console.log('Ascendion Subscriber Overview opened.');

  const subscriberLoginUsername = process.env.SUBSCRIBER_LOGIN_USERNAME;

  let loginLink;

  if (subscriberLoginUsername) {
    const loginRow = overviewPage.getByRole('row').filter({
      hasText: subscriberLoginUsername,
    });

    await expect(loginRow).toBeVisible({ timeout: 30000 });

    loginLink = loginRow.getByRole('link', { name: /^Login$/i });
  } else {
    const loginLinks = overviewPage.getByRole('link', { name: /^Login$/i });
    const loginLinkCount = await loginLinks.count();

    console.log(`Subscriber Login links found: ${loginLinkCount}`);

    if (loginLinkCount === 0) {
      throw new Error('No subscriber Login link was found.');
    }

    loginLink = loginLinks.first();
  }

  await expect(loginLink).toBeVisible({ timeout: 30000 });

  // Subscriber Login may reuse the same page or open a new page.
  const context = overviewPage.context();
  const pagesBeforeLogin = context.pages();

  await loginLink.click();
  await overviewPage.waitForTimeout(3000);

  const subscriberPage =
    context.pages().find((candidate) => !pagesBeforeLogin.includes(candidate)) ||
    overviewPage;

  await subscriberPage.waitForLoadState('domcontentloaded');

  console.log('Subscriber URL after Login:', subscriberPage.url());

  const subscriberOrigin = new URL(subscriberPage.url()).origin;

  await subscriberPage.goto(
    `${subscriberOrigin}/lightning/o/Account/list?filterName=__Recent`,
    { waitUntil: 'domcontentloaded' }
  );

  await subscriberPage.waitForURL('**/lightning/o/Account/**', {
    timeout: 120000,
  });

  await expect(
    subscriberPage.getByRole('link', { name: /^Accounts$/i })
  ).toBeVisible({ timeout: 60000 });

  console.log('Subscriber Lightning Accounts page loaded:', subscriberPage.url());

  return subscriberPage;
}

// ===========================================================================
// Account search / report list helpers
// ===========================================================================
async function waitForAccountsList(page: Page): Promise<void> {
  console.log('Waiting for Accounts list to load...');

  const listViewToggle = page
    .locator('button, a')
    .filter({ hasText: /Recently Viewed|Select a List View/i })
    .first();

  await expect(listViewToggle).toBeVisible({ timeout: 30000 });
  await listViewToggle.click();

  const allAccountsOption = page
    .locator('lightning-menu-item, lightning-button-menu-item, li, a, button')
    .filter({ hasText: /^All Accounts$/i })
    .first();

  await expect(allAccountsOption).toBeVisible({ timeout: 15000 });
  await allAccountsOption.click();

  console.log('All Accounts selected.');

  await page.waitForLoadState('domcontentloaded');
  await page.waitForTimeout(3000);
}

async function createAccountIfNotFound(
  page: Page,
  accountDetails: AccountCsvDetails
): Promise<void> {
  const {
    accountName,
    billingStreet,
    billingCity,
    billingState,
    billingPostalCode,
    billingCountry,
  } = accountDetails;

  console.log(
    `Account "${accountName}" was not found. Starting New Account creation using CSV details.`
  );

  // IMPORTANT:
  // This function is called ONLY after searchAccountAndOpen() confirms
  // that the account does not already exist.

  const newAccountButton = page
    .getByRole('button', { name: /^New$/i })
    .or(page.getByRole('link', { name: /^New$/i }))
    .or(
      page.locator('button, a').filter({
        hasText: /^New$/i,
      })
    )
    .first();

  await expect(newAccountButton).toBeVisible({ timeout: 30000 });
  await newAccountButton.click();

  console.log('New Account button clicked.');

  const accountDialog = page
    .getByRole('dialog')
    .filter({ hasText: /New Account/i })
    .first();

  const dialogVisible = await accountDialog
    .waitFor({ state: 'visible', timeout: 10000 })
    .then(() => true)
    .catch(() => false);

  const formRoot = dialogVisible ? accountDialog : page;

  // Account Name
  const accountNameField = formRoot
    .locator('input[name="Name"]')
    .or(formRoot.getByRole('textbox', { name: /^Account Name$/i }))
    .or(formRoot.getByLabel(/^Account Name$/i))
    .first();

  await expect(accountNameField).toBeVisible({ timeout: 30000 });
  await accountNameField.fill(accountName);

  console.log(`Account Name: ${accountName}`);

  // Billing Country
  if (billingCountry.trim()) {
    const billingCountryField = formRoot
      .getByRole('combobox', { name: /^Billing Country$/i })
      .first();

    await expect(billingCountryField).toBeVisible({ timeout: 30000 });
    await billingCountryField.click();

    const countryOption = page.getByRole('option', {
      name: billingCountry,
      exact: true,
    }).first();

    await expect(countryOption).toBeVisible({ timeout: 15000 });
    await countryOption.click();

    console.log(`Billing Country: ${billingCountry}`);
  } else {
    console.log('Billing Country is blank in CSV; skipping.');
  }

  // Billing Street
  const billingStreetField = formRoot
    .getByLabel('Billing Street', { exact: true })
    .first();

  await expect(billingStreetField).toBeVisible({ timeout: 30000 });
  await billingStreetField.fill(billingStreet);

  console.log(`Billing Street: ${billingStreet}`);

  // Billing City
  const billingCityField = formRoot
    .getByLabel('Billing City', { exact: true })
    .first();

  await expect(billingCityField).toBeVisible({ timeout: 30000 });
  await billingCityField.fill(billingCity);

  console.log(`Billing City: ${billingCity}`);

  // Billing State/Province
  if (billingState.trim()) {
    const billingStateField = formRoot
      .getByRole('combobox', { name: /^Billing State\/Province$/i })
      .first();

    await expect(billingStateField).toBeVisible({ timeout: 30000 });
    await billingStateField.click();

    const stateOption = page.getByRole('option', {
      name: billingState,
      exact: true,
    }).first();

    await expect(stateOption).toBeVisible({ timeout: 15000 });
    await stateOption.click();

    console.log(`Billing State: ${billingState}`);
  } else {
    console.log('Billing State is blank in CSV; skipping.');
  }

  // Billing Zip/Postal Code
  const billingPostalCodeField = formRoot
    .getByLabel('Billing Zip/Postal Code', { exact: true })
    .first();

  await expect(billingPostalCodeField).toBeVisible({ timeout: 30000 });
  await billingPostalCodeField.fill(billingPostalCode);

  console.log(`Billing Postal Code: ${billingPostalCode}`);

  // Validate the values before saving.
  const enteredAccountName = await accountNameField.inputValue();

  if (enteredAccountName.trim() !== accountName.trim()) {
    throw new Error(
      `Account Name mismatch. Expected: ${accountName}, Actual: ${enteredAccountName}`
    );
  }

  console.log('====================================');
  console.log('ACCOUNT DATA FROM CSV ENTERED');
  console.log('====================================');
  console.log(`Account Name        : ${accountName}`);
  console.log(`Billing Street      : ${billingStreet}`);
  console.log(`Billing City        : ${billingCity}`);
  console.log(`Billing State       : ${billingState}`);
  console.log(`Billing Postal Code : ${billingPostalCode}`);
  console.log(`Billing Country     : ${billingCountry}`);
  console.log('====================================');

  // Save
  const saveButton = formRoot
    .locator('button[name="SaveEdit"]')
    .or(formRoot.getByRole('button', { name: /^Save$/i }))
    .first();

  await expect(saveButton).toBeVisible({ timeout: 30000 });
  await saveButton.click();

  console.log(`Create Account Save clicked for "${accountName}".`);

  // Wait for Salesforce to finish saving/navigating.
  await page.waitForTimeout(3000);

  // If Salesforce reports a duplicate, do NOT continue with report generation
  // against an account that was not actually created.
  const duplicatePopup = page
    .locator('div[role="dialog"]')
    .filter({ hasText: /Similar Records Exist|Duplicate/i })
    .first();

  const duplicateVisible = await duplicatePopup
    .isVisible()
    .catch(() => false);

  if (duplicateVisible) {
    throw new Error(
      `Salesforce reported a duplicate Account while creating "${accountName}".`
    );
  }

  // The newly created Account must be opened before report generation starts.
  await expectAccountHeading(page, accountName);

  await page.waitForLoadState('domcontentloaded');
  await page.waitForTimeout(3000);

  console.log(
    `New Account created with CSV address details and opened: ${accountName}`
  );
}
async function searchAccountAndOpen(
  page: Page,
  accountDetails: AccountCsvDetails
): Promise<void> {
  const accountName = accountDetails.accountName;

  await waitForAccountsList(page);

  console.log(`Searching for random account: ${accountName}`);

  const searchBox = page
    .getByRole('searchbox')
    .or(page.getByPlaceholder(/search/i))
    .first();

  await expect(searchBox).toBeVisible({ timeout: 30000 });

  await searchBox.click();
  await searchBox.fill(accountName);
  await page.keyboard.press('Enter');

  await page.waitForTimeout(3000);

  const accountLink = page
    .getByRole('link', {
      name: new RegExp(`^${escapeRegExp(accountName)}$`, 'i'),
    })
    .first();

  const accountFound = await accountLink
    .waitFor({ state: 'visible', timeout: 10000 })
    .then(() => true)
    .catch(() => false);

  if (accountFound) {
    // Existing account path: DO NOT create or modify the account.
    console.log(`Account found: ${accountName}`);

    await accountLink.click();

    await expectAccountHeading(page, accountName);

    await page.waitForLoadState('domcontentloaded');
    await page.waitForTimeout(3000);

    console.log(`Existing Account page loaded: ${accountName}`);
    return;
  }

  // Missing account path: this is the ONLY place where account creation occurs.
  console.log(
    `No existing Account found for "${accountName}". Creating new Account from CSV details.`
  );

  await createAccountIfNotFound(page, accountDetails);
}
async function openReportViewAll(page: Page, reportLabel: RegExp): Promise<void> {
  console.log(`Opening ${reportLabel} View All...`);

  const reportLink = page.getByRole('link', { name: reportLabel }).first();

  for (let i = 0; i < 12; i++) {
    if (await reportLink.isVisible().catch(() => false)) {
      break;
    }

    await page.keyboard.press('PageDown');
    await page.waitForTimeout(500);
  }

  await expect(reportLink).toBeVisible({ timeout: 30000 });

  await reportLink.scrollIntoViewIfNeeded();
  await reportLink.click();

  await page.waitForURL('**/related/**/view', { timeout: 30000 });

  await page.waitForLoadState('domcontentloaded');
  await page.waitForTimeout(2000);

  await expect(page.getByRole('heading', { name: reportLabel })).toBeVisible({
    timeout: 30000,
  });

  console.log(`${reportLabel} View All page loaded.`);
}

async function getReportCount(
  page: Page,
  reportType: 'Consumer' | 'Commercial'
): Promise<number> {
  const reportStatus = page.getByRole('status', {
    name:
      reportType === 'Consumer'
        ? 'Equifax Consumer Reports'
        : 'Equifax Commercial Reports',
  });

  await expect(reportStatus).toBeVisible({ timeout: 30000 });

  const statusText = (await reportStatus.textContent())?.trim() || '';

  const countMatch = statusText.match(/(\d+)\s+items?/i);

  if (!countMatch) {
    throw new Error(
      `Unable to extract ${reportType} report count from: "${statusText}"`
    );
  }

  return Number(countMatch[1]);
}

async function getConsumerReportIds(page: Page): Promise<number[]> {
  const reportLinks = page.getByRole('link', { name: /^EfxConsumer-\d+$/i });
  const linkCount = await reportLinks.count();
  const reportIds: number[] = [];

  for (let i = 0; i < linkCount; i++) {
    const linkText = (await reportLinks.nth(i).innerText()).trim();
    const match = linkText.match(/^EfxConsumer-(\d+)$/i);

    if (match) {
      reportIds.push(Number(match[1]));
    }
  }

  return reportIds;
}

async function getReturnToAccountButton(frame: FrameLocator) {
  return frame
    .getByRole('button', { name: /return to account detail/i })
    .or(frame.getByRole('link', { name: /return to account detail/i }))
    .first();
}

// ===========================================================================
// Consumer helpers
// ===========================================================================
async function getConsumerContactNames(frame: FrameLocator): Promise<string[]> {
  const nameCells = frame.locator('table tbody tr td:nth-child(2)');
  const nameCellCount = await nameCells.count();

  const names: string[] = [];

  for (let i = 0; i < nameCellCount; i++) {
    const text = (await nameCells.nth(i).textContent())?.trim() || '';

    if (text && text.toUpperCase() !== 'NAME') {
      names.push(text);
    }
  }

  console.log(`Available Consumer contacts: ${names.length}`);

  return names;
}

async function selectConsumerContacts(frame: FrameLocator): Promise<number> {
  const checkboxes = frame.getByRole('checkbox');
  const checkboxCount = await checkboxes.count();

  if (checkboxCount <= 1) {
    return 0;
  }

  const selectAllCheckbox = checkboxes.first();
  await expect(selectAllCheckbox).toBeVisible({ timeout: 10000 });

  if (!(await selectAllCheckbox.isChecked())) {
    await selectAllCheckbox.check({ force: true });
  }

  let selectedCount = 0;

  // Verify each contact row after using the header select-all checkbox.
  for (let i = 1; i < checkboxCount; i++) {
    const contactCheckbox = checkboxes.nth(i);

    await expect(contactCheckbox).toBeVisible({ timeout: 10000 });

    if (!(await contactCheckbox.isChecked())) {
      await contactCheckbox.check({ force: true });
    }

    await expect(contactCheckbox).toBeChecked();

    selectedCount++;
  }

  return selectedCount;
}

async function getConsumerRequestHitCount(
  frame: FrameLocator,
  expectedContactCount: number
): Promise<number> {
  const cells = frame.locator('table tbody tr td');
  const cellCount = await cells.count();
  let hitCount = 0;
  let noHitCount = 0;

  for (let i = 0; i < cellCount; i++) {
    const cellText = (await cells.nth(i).innerText())
      .replace(/\s+/g, ' ')
      .trim();

    if (/^Hit$/i.test(cellText)) {
      hitCount++;
    } else if (/^No[\s-]*Hit\b/i.test(cellText)) {
      noHitCount++;
    }
  }

  const statusCount = hitCount + noHitCount;

  if (statusCount !== expectedContactCount) {
    console.warn(
      `Consumer request status classification incomplete. Expected=${expectedContactCount}, classified=${statusCount}, Hit=${hitCount}, No Hit=${noHitCount}. Only HIT records will count toward the report total.`
    );
  }

  console.log(`Consumer request results: Hit=${hitCount}, No Hit=${noHitCount}`);
  return hitCount;
}

async function clickDoneAfterRequest(
  page: Page,
  expectedContactCount: number
): Promise<number> {
  console.log('Waiting for Consumer report processing to complete');

  let stableDoneChecks = 0;

  await expect
    .poll(
      async () => {
        const doneFrame = await findVfFrame(page, doneButtonProbe);
        const requestFrame = await findVfFrame(page, requestReportsButtonProbe);

        const doneVisible = doneFrame !== null;
        const requestReportsVisible = requestFrame !== null;

        if (doneVisible && !requestReportsVisible) {
          stableDoneChecks++;
        } else {
          stableDoneChecks = 0;
        }

        console.log(
          `Done=${doneVisible}, RequestReports=${requestReportsVisible}, stableChecks=${stableDoneChecks}`
        );

        return stableDoneChecks >= 2;
      },
      {
        timeout: 180000,
        intervals: [3000, 5000, 5000],
      }
    )
    .toBe(true);

  const finalFrame = await waitForVfFrame(page, doneButtonProbe, 'Done button', 30000);
  const hitCount = await getConsumerRequestHitCount(
    finalFrame,
    expectedContactCount
  );

  const doneButton = finalFrame
    .getByRole('button', { name: /^Done$/i })
    .or(finalFrame.locator('input[value="Done" i]'))
    .first();

  await expect(doneButton).toBeVisible({ timeout: 30000 });

  await doneButton.scrollIntoViewIfNeeded();
  await doneButton.click();

  console.log('Processing completed. Done button clicked.');
  return hitCount;
}

async function getPageErrorText(page: Page): Promise<string | null> {
  try {
    const bodyText = await page.locator('body').innerText();

    const match = bodyText.match(
      /(Error|Exception|Unable|Failed|Invalid|404|Not Found|No content|No records|No data)/i
    );

    if (!match) {
      return null;
    }

    return bodyText.replace(/\s+/g, ' ').trim().slice(0, 1500);
  } catch {
    return null;
  }
}

async function captureConsumerReportDetails(
  page: Page
): Promise<Record<string, string>> {
  const fullText = await page.locator('body').innerText();
  const bodyText = fullText.replace(/\s+/g, ' ').trim();

  const extracted: Record<string, string> = { pageText: bodyText };

  const patterns: Record<string, RegExp> = {
    'Equifax Report ID': /Equifax Consumer Report ID\s+([A-Za-z0-9-]+)/i,
    Contact: /Contact\s+([A-Z0-9\s\-.,]+)/i,
    Account: /Account\s+([A-Z0-9\s\-.,/&()]+)/i,
    'Beacon Score': /Beacon Score\s+([0-9]+)/i,
    'Credit Quality Rating': /Credit Quality Rating\s+([A-Za-z0-9\s\-.,]+)/i,
  };

  for (const [label, pattern] of Object.entries(patterns)) {
    const match = bodyText.match(pattern);

    if (match) {
      extracted[label] = match[1].trim();
    }
  }

  const pageErrorText = await getPageErrorText(page);

  if (pageErrorText) {
    extracted.pageError = pageErrorText;
  }

  return extracted;
}

// ===========================================================================
// Commercial helper: open newest report, screenshot, capture field values
// ===========================================================================
async function captureCommercialReportDetails(
  page: Page,
  testInfo: TestInfo,
  reportName: string
): Promise<Record<string, string>> {
  const link = page
    .getByRole('link', { name: new RegExp(`^${escapeRegExp(reportName)}$`, 'i') })
    .or(
      page
        .locator('a')
        .filter({ hasText: new RegExp(escapeRegExp(reportName), 'i') })
        .last()
    )
    .first();

  await expect(link).toBeVisible({ timeout: 30000 });
  await link.click();

  await page.waitForURL('**/lightning/r/**', { timeout: 30000 });
  await page.waitForLoadState('domcontentloaded');
  await page.waitForTimeout(3000);

  await captureScreenshot(page, testInfo, 'commercial-report-detail');

  const values: Record<string, string> = {};

  const rows = page.locator(
    'div.forcePageBlockSectionRow, div.slds-form-element, force-record-layout-item, records-record-layout-item'
  );

  const rowCount = await rows.count();

  for (let i = 0; i < rowCount; i++) {
    const row = rows.nth(i);

    const label = row.locator(
      'div.labelCol, span.slds-form-element__label, .detailLabel, label, th, .slds-text-title_caps'
    );
    const value = row.locator(
      'div.dataCol, .slds-form-element__static, lightning-formatted-text, lightning-formatted-number, lightning-formatted-date-time, .outputText, .valueCol, td'
    );

    if ((await label.count()) === 0 || (await value.count()) === 0) {
      continue;
    }

    const labelText = (await label.first().textContent())
      ?.replace(/\s+/g, ' ')
      .trim();
    const valueText = (await value.first().textContent())
      ?.replace(/\s+/g, ' ')
      .trim();

    if (labelText && valueText) {
      values[labelText] = valueText;
    }
  }

  if (Object.keys(values).length === 0) {
    values.pageText = (await page.locator('body').innerText())
      .replace(/\s+/g, ' ')
      .trim();
  }

  const outputPath = path.join(
    process.cwd(),
    'test-results',
    `commercial-report-${Date.now()}.json`
  );

  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, JSON.stringify(values, null, 2));

  console.log(`Commercial report values saved to ${outputPath}`);
  console.log(JSON.stringify(values, null, 2));

  return values;
}

// ===========================================================================
// ONE TEST: login once -> Consumer pull -> Commercial pull (same session)
// ===========================================================================
test(
  'One click: single login -> random account -> consumer report -> commercial report (Review Credit)',
  async ({ page }, testInfo) => {
    test.setTimeout(900000);

    const accountName = getRandomAccountName().trim();

    if (!accountName) {
      throw new Error('getRandomAccountName() returned an empty account name.');
    }

    console.log(`Selected random account from CSV: ${accountName}`);

    // Read the same CSV row so that, if this account does not exist,
    // the new Account is created with its complete address details.
    const csvPath = path.join(
      process.cwd(),
      'test-data',
      'salesfrocedataauto.csv'
    );

    const accountRecords = await readCsv(csvPath);
    const accountDetails = getAccountCsvDetails(
      accountRecords,
      accountName
    );

    console.log('Selected Account CSV details:');
    console.log(`  Account Name        : ${accountDetails.accountName}`);
    console.log(`  Billing Street      : ${accountDetails.billingStreet}`);
    console.log(`  Billing City        : ${accountDetails.billingCity}`);
    console.log(`  Billing State       : ${accountDetails.billingState}`);
    console.log(`  Billing Postal Code : ${accountDetails.billingPostalCode}`);
    console.log(`  Billing Country     : ${accountDetails.billingCountry}`);

    let activePage: Page = page;

    try {
      // =====================================================================
      // LOGIN (ONLY ONCE) + OPEN ACCOUNT
      // =====================================================================
      activePage = await loginToSalesforce(page);

      await searchAccountAndOpen(activePage, accountDetails);

      const accountUrl = activePage.url();

      // =====================================================================
      // PART 1 - CONSUMER REPORT PULL
      // =====================================================================
      await test.step('Consumer report pull', async () => {
        await openReportViewAll(activePage, /Equifax Consumer Reports/i);

        const consumerReportCountBefore = await getReportCount(
          activePage,
          'Consumer'
        );
        const consumerReportIdsBefore = await getConsumerReportIds(activePage);

        console.log(`Consumer Reports before request: ${consumerReportCountBefore}`);
        console.log('Consumer report IDs before request:', consumerReportIdsBefore);

        await captureScreenshot(activePage, testInfo, 'consumer-01-reports-before');

        await gotoAccount(activePage, accountUrl, accountName);

        // Consumer Credit Review is a visible button on the Account page.
        await clickAccountAction(
          activePage,
          'Consumer Credit Review',
          testInfo,
          'consumer-02-account-page-buttons'
        );

        const consumerIframe = activePage
          .locator('iframe[name^="vfFrameId_"]')
          .first();

        await expect(consumerIframe).toBeVisible({ timeout: 30000 });

        const frame = consumerIframe.contentFrame();

        await expect(
          frame.getByRole('heading', {
            level: 1,
            name: /request consumer credit reports/i,
          })
        ).toBeVisible({ timeout: 30000 });

        console.log('Request Consumer Credit Reports page loaded.');

        const contactNames = await getConsumerContactNames(frame);
        const availableContactCount = contactNames.length;

        if (availableContactCount === 0) {
          const cancelButton = frame.getByRole('button', { name: /^Cancel$/i });

          if (await cancelButton.isVisible().catch(() => false)) {
            await cancelButton.click();
          }

          throw new Error(
            `No Consumer contacts are available for account "${accountName}".`
          );
        }

        console.log('Contacts selected for report request:', contactNames);

        const selectedContactCount = await selectConsumerContacts(frame);

        if (selectedContactCount === 0) {
          throw new Error('No Consumer contact checkboxes could be selected.');
        }

        if (selectedContactCount !== availableContactCount) {
          throw new Error(
            `Contact/checkbox mismatch. Contacts=${availableContactCount}, selected=${selectedContactCount}`
          );
        }

        console.log(`${selectedContactCount} Consumer contact(s) selected.`);

        await captureScreenshot(activePage, testInfo, 'consumer-03-contacts-selected');

        const requestReportsButton = frame
          .getByRole('button', { name: /request reports/i })
          .or(frame.locator('input[value*="Request Reports" i]'))
          .first();

        await expect(requestReportsButton).toBeVisible({ timeout: 30000 });
        await requestReportsButton.click();

        console.log('Request Reports clicked.');

        const hitContactCount = await clickDoneAfterRequest(
          activePage,
          selectedContactCount
        );

        await activePage.waitForURL('**/lightning/r/Account/**/view', {
          timeout: 30000,
        });

        await expectAccountHeading(activePage, accountName);
        await activePage.waitForLoadState('domcontentloaded');
        await activePage.waitForTimeout(3000);

        await openReportViewAll(activePage, /Equifax Consumer Reports/i);

        const expectedConsumerReportCount =
          consumerReportCountBefore + hitContactCount;

        let consumerReportCountAfter = consumerReportCountBefore;

        console.log(`Consumer Reports expected count: ${expectedConsumerReportCount}`);

        await expect
          .poll(
            async () => {
              await activePage.reload({ waitUntil: 'domcontentloaded' });
              await activePage.waitForTimeout(2000);

              consumerReportCountAfter = await getReportCount(
                activePage,
                'Consumer'
              );

              console.log(
                `Consumer Reports: before=${consumerReportCountBefore}, current=${consumerReportCountAfter}, expected=${expectedConsumerReportCount}`
              );

              return consumerReportCountAfter;
            },
            {
              timeout: 120000,
              intervals: [5000, 10000, 15000],
            }
          )
          .toBe(expectedConsumerReportCount);

        console.log(
          `Consumer report generation successful. Final count=${consumerReportCountAfter}`
        );

        await captureScreenshot(activePage, testInfo, 'consumer-04-reports-after');

        if (hitContactCount > 0) {
          const previousReportIds = new Set(consumerReportIdsBefore);
          const newReportIds = (await getConsumerReportIds(activePage)).filter(
            (reportId) => !previousReportIds.has(reportId)
          );

          if (newReportIds.length === 0) {
            throw new Error(
              `Expected ${hitContactCount} new consumer report(s), but no new EfxConsumer report ID was found.`
            );
          }

          const latestReportId = Math.max(...newReportIds);
          const generatedLink = activePage.getByRole('link', {
            name: `EfxConsumer-${latestReportId}`,
            exact: true,
          });

          console.log(
            `Opening newest generated consumer report: EfxConsumer-${latestReportId}`
          );

          await expect(generatedLink).toBeVisible({ timeout: 30000 });
          await generatedLink.click();

          await activePage.waitForURL('**/lightning/r/**', { timeout: 30000 });
          await activePage.waitForLoadState('domcontentloaded');
          await activePage.waitForTimeout(3000);

          await captureScreenshot(activePage, testInfo, 'consumer-05-report-detail');

          const finalReportValues = await captureConsumerReportDetails(activePage);

          console.log(
            'Final generated report values:',
            JSON.stringify(finalReportValues, null, 2)
          );

          const outputPath = path.join(
            process.cwd(),
            'test-results',
            'consumer-report-values.json'
          );

          fs.mkdirSync(path.dirname(outputPath), { recursive: true });
          fs.writeFileSync(outputPath, JSON.stringify(finalReportValues, null, 2));

          console.log(`Saved report values to ${outputPath}`);

          expect(finalReportValues.pageText || finalReportValues.pageError).toBeTruthy();
        } else {
          console.log('No HIT contacts; no consumer report detail to open.');
        }
      });

      // =====================================================================
      // PART 2 - COMMERCIAL REPORT PULL (same session, no second login)
      // =====================================================================
      await test.step('Commercial report pull (Review Credit)', async () => {
        console.log('Consumer part completed. Starting Commercial report pull.');

        // Back to the same Account using the URL captured after the first login.
        await gotoAccount(activePage, accountUrl, accountName);

        await openReportViewAll(activePage, /Equifax Commercial Reports/i);

        const commercialReportCountBefore = await getReportCount(
          activePage,
          'Commercial'
        );

        console.log(
          `Commercial Reports before Review Credit: ${commercialReportCountBefore}`
        );

        await captureScreenshot(activePage, testInfo, 'commercial-01-reports-before');

        await gotoAccount(activePage, accountUrl, accountName);

        // Review Credit is a visible button on the Account page: click directly.
        await clickAccountAction(
          activePage,
          'Review Credit',
          testInfo,
          'commercial-02-review-credit-button'
        );

        const reviewFrame = await waitForVfFrame(
          activePage,
          goButtonProbe,
          'Review Credit page (Go button)'
        );

        const goButton = reviewFrame
          .getByRole('button', { name: /^Go$/i })
          .or(reviewFrame.locator('input[value="Go" i]'))
          .first();

        await expect(goButton).toBeVisible({ timeout: 30000 });

        await captureScreenshot(activePage, testInfo, 'commercial-03-review-credit-go-page');

        await goButton.click();

        console.log('Commercial Review Credit Go button clicked.');

        // Optional consumer selection page shown by Review Credit.
        const consumerHeading = reviewFrame.getByRole('heading', {
          name: /request consumer credit reports/i,
        });

        const consumerPageDisplayed = await consumerHeading
          .waitFor({ state: 'visible', timeout: 10000 })
          .then(() => true)
          .catch(() => false);

        if (consumerPageDisplayed) {
          console.log('Review Credit displayed Request Consumer Credit Reports page.');

          const validNames = await getConsumerContactNames(reviewFrame);

          if (validNames.length === 0) {
            const cancelButton = reviewFrame.getByRole('button', {
              name: /^Cancel$/i,
            });

            await expect(cancelButton).toBeVisible({ timeout: 10000 });
            await cancelButton.click();

            await activePage.waitForURL('**/lightning/r/Account/**/view', {
              timeout: 30000,
            });

            throw new Error(
              `No consumer contacts available for Review Credit on "${accountName}".`
            );
          }

          const checkboxes = reviewFrame.getByRole('checkbox');
          const checkboxCount = await checkboxes.count();

          // Index 0 is the select-all checkbox.
          for (let i = 1; i < checkboxCount; i++) {
            const checkbox = checkboxes.nth(i);

            if (
              (await checkbox.isVisible().catch(() => false)) &&
              (await checkbox.isEnabled().catch(() => false)) &&
              !(await checkbox.isChecked())
            ) {
              await checkbox.check({ force: true });
            }
          }

          await captureScreenshot(
            activePage,
            testInfo,
            'commercial-04-consumer-contacts-selected'
          );

          const consumerGoButton = reviewFrame
            .getByRole('button', { name: /^Go$/i })
            .or(reviewFrame.locator('input[value="Go" i]'))
            .first();

          await expect(consumerGoButton).toBeVisible({ timeout: 10000 });
          await consumerGoButton.click();

          console.log('Commercial flow continued after consumer selection page.');
        }

        await expect(
          reviewFrame.getByRole('heading', { name: /credit review/i })
        ).toBeVisible({ timeout: 120000 });

        console.log('Credit Review response page loaded.');

        await activePage.waitForTimeout(3000);

        await captureScreenshot(activePage, testInfo, 'commercial-05-credit-review-response');

        const errorMessage = reviewFrame
          .getByText(/error|exception|unable|failed|invalid/i)
          .first();

        const hasError = await errorMessage
          .waitFor({ state: 'visible', timeout: 5000 })
          .then(() => true)
          .catch(() => false);

        const returnButton = await getReturnToAccountButton(reviewFrame);

        await expect(returnButton).toBeVisible({ timeout: 60000 });

        if (hasError) {
          const errorText =
            (await errorMessage.textContent())?.trim() ||
            'Unknown Review Credit error';

          await captureScreenshot(activePage, testInfo, 'commercial-05b-credit-review-error');

          await returnButton.scrollIntoViewIfNeeded();
          await returnButton.click();

          throw new Error(`Review Credit failed: ${errorText}`);
        }

        await returnButton.scrollIntoViewIfNeeded();
        await returnButton.click();

        await activePage.waitForURL('**/lightning/r/Account/**/view', {
          timeout: 30000,
        });

        await expectAccountHeading(activePage, accountName);

        console.log('Returned to Account after Review Credit.');

        await openReportViewAll(activePage, /Equifax Commercial Reports/i);

        let commercialReportCountAfter = commercialReportCountBefore;

        await expect
          .poll(
            async () => {
              await activePage.reload({ waitUntil: 'domcontentloaded' });
              await activePage.waitForTimeout(2000);

              commercialReportCountAfter = await getReportCount(
                activePage,
                'Commercial'
              );

              console.log(
                `Commercial Reports: before=${commercialReportCountBefore}, current=${commercialReportCountAfter}`
              );

              return commercialReportCountAfter;
            },
            {
              timeout: 180000,
              intervals: [5000, 10000, 15000],
            }
          )
          .toBeGreaterThan(commercialReportCountBefore);

        console.log(
          `New Commercial Report generated. Count changed from ${commercialReportCountBefore} to ${commercialReportCountAfter}.`
        );

        await captureScreenshot(activePage, testInfo, 'commercial-06-reports-after');

        const newestReport = activePage
          .locator('a')
          .filter({ hasText: /Equifax CC-/i })
          .last();

        await expect(newestReport).toBeVisible({ timeout: 30000 });

        const newestReportName =
          (await newestReport.textContent())?.trim() || 'Equifax CC';

        const reportValues = await captureCommercialReportDetails(
          activePage,
          testInfo,
          newestReportName
        );

        expect(Object.keys(reportValues).length).toBeGreaterThan(0);

        console.log('============================================================');
        console.log('CONSUMER + COMMERCIAL REPORT PULL AND VALIDATION COMPLETED');
        console.log(
          `Commercial count: ${commercialReportCountBefore} -> ${commercialReportCountAfter}`
        );
        console.log('============================================================');
      });
    } catch (error) {
      try {
        if (!activePage.isClosed()) {
          await captureScreenshot(activePage, testInfo, 'failure-state');
        }
      } catch {
        // Ignore screenshot failure.
      }

      throw error;
    }
  }
);