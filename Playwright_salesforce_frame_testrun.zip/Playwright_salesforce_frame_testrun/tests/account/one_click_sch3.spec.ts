import {
  test,
  expect,
  Page,
  FrameLocator,
  Locator,
  TestInfo,
} from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { env } from '../../config/env';
import { captureScreenshot } from '../../utils/captureScreenshot';

/* ------------------------------------------------------------------ */
/* Config / small utilities                                            */
/* ------------------------------------------------------------------ */
/*
 * Optional environment variables:
 *   REPORT_RENDER_WAIT_MS            final paint buffer for reports (default 1500)
 *   COMMERCIAL_REPORT_RENDER_WAIT_MS final paint buffer for commercial reports (default 3000)
 *   REPORT_PDF_WAIT_MS               extra wait while a Commercial PDF report is pulled (default 5000)
 *   SUBSCRIBER_LOGIN_USERNAME        pick a specific subscriber Login link
 *   ACCOUNT_POOL_SIZE                limit the random pool to the N newest eligible accounts
 *   FORCE_ACCOUNT_CREATION=true      skip the random pick and always create an Account from CSV
 *   ACCOUNT_RECORD_TYPE              record type label to choose if the New Account
 *                                    record-type picker is shown (otherwise the default is used)
 */

const REPORT_RENDER_WAIT_MS = Number(process.env.REPORT_RENDER_WAIT_MS) || 1500;
const COMMERCIAL_REPORT_RENDER_WAIT_MS =
  Number(process.env.COMMERCIAL_REPORT_RENDER_WAIT_MS) || 3000;

// Extra time given to the PDF report to be pulled and painted before its screenshot.
const PDF_PULL_WAIT_MS = Number(process.env.REPORT_PDF_WAIT_MS) || 5000;

const ACCOUNT_VIEW_URL = '**/lightning/r/Account/**/view';
const VF_FRAME = 'iframe[name^="vfFrameId_"]';

// CSV files live in <project root>/test-data. Lookup is case-insensitive,
// so ".CSV" vs ".csv" does not matter on Linux/CI.
const ACCOUNT_CSV = 'salesfrocedataauto.csv';
const CONTACT_CSV = 'salesfrocedataauto2.csv';

// Column headers of salesfrocedataauto.csv (Account creation data).
const ACCT_COL = {
  name: 'forseva1__Account__r.Name',
  street: 'forseva1__Address1__c',
  city: 'forseva1__Account__r.BillingCity',
  state: 'forseva1__Account__r.BillingState',
  zip: 'forseva1__Account__r.BillingPostalCode',
  country: 'forseva1__Account__r.BillingCountry',
  phone: 'forseva1__Phone__c',
} as const;

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

const isVisible = (locator: Locator) =>
  locator.isVisible().catch(() => false);

/** Resolves with the key of the first condition that succeeds, or null if all fail. */
function waitForOutcome<K extends string>(
  conditions: Record<K, () => Promise<unknown>>
): Promise<K | null> {
  const entries = Object.entries(conditions) as [K, () => Promise<unknown>][];
  return new Promise((resolve) => {
    let pending = entries.length;
    for (const [key, run] of entries) {
      run()
        .then(() => resolve(key))
        .catch(() => {
          if (--pending === 0) resolve(null);
        });
    }
  });
}

const PROCESSING_TEXT = /Processing\s+Please\s+Wait/i;
const PDF_VIEWER_SELECTOR =
  'iframe[src*=".pdf" i], iframe[src*="pdf" i], embed[type="application/pdf"], object[type="application/pdf"], canvas';

/** "Processing Please Wait.." can be shown by the page itself or by a Visualforce iframe. */
async function isProcessingVisible(page: Page): Promise<boolean> {
  for (const frame of page.frames()) {
    const visible = await frame
      .getByText(PROCESSING_TEXT)
      .first()
      .isVisible()
      .catch(() => false);
    if (visible) return true;
  }
  return false;
}

async function isPdfViewerVisible(page: Page): Promise<boolean> {
  for (const frame of page.frames()) {
    const viewer = frame.locator(PDF_VIEWER_SELECTOR).first();
    if (await viewer.isVisible().catch(() => false)) return true;
  }
  return false;
}

/** Waits until "Processing Please Wait.." is gone and stays gone for two consecutive checks. */
async function waitForProcessingToClear(page: Page): Promise<void> {
  let clearChecks = 0;

  try {
    await expect
      .poll(
        async () => {
          clearChecks = (await isProcessingVisible(page)) ? 0 : clearChecks + 1;
          return clearChecks >= 2;
        },
        { timeout: 90000, intervals: [1000, 1000, 2000] }
      )
      .toBe(true);
  } catch {
    console.log('"Processing Please Wait" still visible after 90s, continuing.');
  }
}

/**
 * Waits for spinners and the "Processing Please Wait.." message to disappear.
 * For PDF reports it also waits for the viewer, then gives the PDF extra time to render.
 */
async function waitForReportToFinishLoading(
  page: Page,
  settleMs: number = REPORT_RENDER_WAIT_MS,
  expectPdf = false
): Promise<void> {
  console.log('Waiting for report/PDF content to finish loading...');

  const spinners = page.locator(
    'lightning-spinner, .slds-spinner, .slds-spinner_container, [role="progressbar"]'
  );
  try {
    await expect
      .poll(
        () =>
          spinners.evaluateAll((els) =>
            (els as HTMLElement[]).every((el) => el.offsetParent === null)
          ),
        { timeout: 15000, intervals: [500, 1000, 2000] }
      )
      .toBe(true);
  } catch {
    console.log('Spinner still present after 15s, continuing.');
  }

  await waitForProcessingToClear(page);

  if (expectPdf) {
    const pdfFound = await expect
      .poll(() => isPdfViewerVisible(page), {
        timeout: 15000,
        intervals: [500, 1000, 2000],
      })
      .toBe(true)
      .then(() => true)
      .catch(() => false);

    if (!pdfFound) console.log('PDF viewer did not become visible in 15s.');

    console.log(`Waiting ${PDF_PULL_WAIT_MS}ms for the PDF report to render...`);
    await page.waitForTimeout(PDF_PULL_WAIT_MS);

    // The processing message can reappear while the PDF is being pulled.
    await waitForProcessingToClear(page);
  }

  await page.waitForTimeout(settleMs);
}

/* ------------------------------------------------------------------ */
/* CSV helpers (parsed once, cached)                                   */
/* ------------------------------------------------------------------ */

/** RFC-4180 style parser: handles quoted fields, escaped quotes and line breaks inside quotes. */
function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let current = '';
  let inQuotes = false;

  const input = text.replace(/^\uFEFF/, '');

  for (let i = 0; i < input.length; i++) {
    const char = input[i];

    if (inQuotes) {
      if (char === '"') {
        if (input[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        current += char;
      }
      continue;
    }

    if (char === '"') {
      inQuotes = true;
    } else if (char === ',') {
      row.push(current.trim());
      current = '';
    } else if (char === '\n' || char === '\r') {
      if (char === '\r' && input[i + 1] === '\n') i++;
      row.push(current.trim());
      current = '';
      if (row.some((cell) => cell !== '')) rows.push(row);
      row = [];
    } else {
      current += char;
    }
  }

  row.push(current.trim());
  if (row.some((cell) => cell !== '')) rows.push(row);

  return rows;
}

type CsvRow = Record<string, string>;
const csvCache = new Map<string, CsvRow[]>();

function resolveCsvPath(fileName: string): string | null {
  const dir = path.resolve(process.cwd(), 'test-data');
  const exact = path.join(dir, fileName);
  if (fs.existsSync(exact)) return exact;

  if (!fs.existsSync(dir)) return null;
  const match = fs
    .readdirSync(dir)
    .find((file) => file.toLowerCase() === fileName.toLowerCase());
  return match ? path.join(dir, match) : null;
}

function readCsv(fileName: string, label: string): CsvRow[] {
  const cacheKey = fileName.toLowerCase();
  const cached = csvCache.get(cacheKey);
  if (cached) return cached;

  const csvPath = resolveCsvPath(fileName);
  if (!csvPath) {
    throw new Error(
      `${label} CSV file not found: ${path.resolve(process.cwd(), 'test-data', fileName)}`
    );
  }

  const table = parseCsv(fs.readFileSync(csvPath, 'utf8'));
  if (table.length < 2) {
    throw new Error(`${fileName} contains no ${label} rows.`);
  }

  const headers = table[0];
  const rows = table.slice(1).map((values) => {
    const row: CsvRow = {};
    headers.forEach((header, index) => {
      row[header] = values[index]?.trim() ?? '';
    });
    return row;
  });

  csvCache.set(cacheKey, rows);
  return rows;
}

type ContactCsvRecord = CsvRow;
type AccountCsvRecord = CsvRow;

const normalizeKey = (value: string | undefined) =>
  (value || '').trim().toLowerCase();

function readContactsForAccount(accountName: string): ContactCsvRecord[] {
  const contacts = readCsv(CONTACT_CSV, 'Contact').filter(
    (contact) => normalizeKey(contact['Account.Name']) === normalizeKey(accountName)
  );

  console.log(
    `Contact CSV rows found for "${accountName}": ${contacts.length}`
  );

  return contacts;
}

/** Account rows from salesfrocedataauto.csv, de-duplicated by Account name. */
function readAccountCsvRows(): AccountCsvRecord[] {
  const seen = new Set<string>();
  const rows: AccountCsvRecord[] = [];

  for (const row of readCsv(ACCOUNT_CSV, 'Account')) {
    const key = normalizeKey(row[ACCT_COL.name]);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    rows.push(row);
  }

  return rows;
}

/** Lower-cased names of every Account that has at least one Contact row in the contact CSV. */
function getMappedAccountNames(): Set<string> {
  return new Set(
    readCsv(CONTACT_CSV, 'Contact')
      .map((contact) => normalizeKey(contact['Account.Name']))
      .filter((name): name is string => Boolean(name))
  );
}

function shuffle<T>(items: T[]): T[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

/* ------------------------------------------------------------------ */
/* Shared page helpers                                                 */
/* ------------------------------------------------------------------ */

function accountHeading(page: Page, accountName: string): Locator {
  return page.getByRole('heading', {
    name: new RegExp(
      `^(?:Account\\s+)?${escapeRegExp(accountName)}$`,
      'i'
    ),
  });
}

async function waitForAccountPage(
  page: Page,
  accountName: string,
  timeout = 30000
): Promise<void> {
  await expect(accountHeading(page, accountName)).toBeVisible({ timeout });
}

/** From a related-list page, click the Account breadcrumb link and wait for the record. */
async function returnToAccount(
  page: Page,
  accountName: string
): Promise<void> {
  const link = page
    .getByRole('link', { name: accountName, exact: true })
    .first();

  await expect(link).toBeVisible({ timeout: 30000 });
  await link.click();
  await waitForAccountPage(page, accountName);
}

/** Click an Account action that may be a visible button or inside "Show more actions". */
async function clickAccountAction(page: Page, name: RegExp): Promise<void> {
  const showMore = page.getByRole('button', { name: /show more actions/i });

  await expect(showMore).toBeVisible({ timeout: 30000 });

  const action = page
    .getByRole('button', { name })
    .or(page.getByRole('menuitem', { name }))
    .or(page.locator('a').filter({ hasText: name }))
    .first();

  if (!(await isVisible(action))) {
    await showMore.click();
  }

  await expect(action).toBeVisible({ timeout: 30000 });
  await action.click();
}

function getVfFrame(page: Page): { element: Locator; frame: FrameLocator } {
  const element = page.locator(`${VF_FRAME}:visible`).last();
  return { element, frame: element.contentFrame() };
}

/* ------------------------------------------------------------------ */
/* Login                                                               */
/* ------------------------------------------------------------------ */

async function isSubscriberAccountPage(page: Page): Promise<boolean> {
  return /\/lightning\/(r|o)\/Account\//i.test(page.url());
}

async function loginToSalesforce(page: Page): Promise<Page> {
  console.log('Navigating to LMA...');

  await page.goto(env.baseUrl!, { waitUntil: 'domcontentloaded' });

  // Already inside the subscriber org - skip the complete LMA flow.
  if (await isSubscriberAccountPage(page)) {
    console.log('Subscriber org session already available.');
    return page;
  }

  const usernameField = page.locator('#username');

  if (await isVisible(usernameField)) {
    await usernameField.fill(env.username!);
    await page.locator('#Login').click();

    const passwordField = page.locator('#password');
    await expect(passwordField).toBeVisible({ timeout: 60000 });
    await passwordField.fill(env.password!);
    await page.locator('#Login').click();

    console.log('LMA login submitted.');

    const mfaVerificationPage = page.locator(
      'input[name="verificationCode"], input[name="otp"], button:has-text("Verify"), text=/Verify your identity/i'
    );

    if (
      await mfaVerificationPage
        .first()
        .isVisible({ timeout: 15000 })
        .catch(() => false)
    ) {
      console.log(
        'MFA verification page detected. Complete the verification code in the browser to continue.'
      );
      await page.waitForURL(
        (url) => !url.toString().includes('/_ui/identity/verification/'),
        { timeout: 180000 }
      );
      console.log('MFA verification completed.');
    }
  } else {
    console.log('Existing LMA session detected.');
  }

  // LMA opens in Salesforce Classic - do not wait for a /lightning/ URL here.
  const subscribersTab = page.getByRole('link', { name: /^Subscribers$/i });
  await expect(subscribersTab).toBeVisible({ timeout: 120000 });
  await subscribersTab.click();
  console.log('Subscribers tab opened.');

  await expect(
    page.getByText('Subscriber Organizations', { exact: true })
  ).toBeVisible({ timeout: 30000 });

  // First textbox = global search; last = Subscriber list search.
  const textboxes = page.getByRole('textbox');
  await expect
    .poll(() => textboxes.count(), { timeout: 30000, intervals: [250, 500] })
    .toBeGreaterThanOrEqual(2);

  const subscriberSearch = textboxes.last();
  await expect(subscriberSearch).toBeVisible({ timeout: 30000 });
  await subscriberSearch.fill(env.subscriberOrgId!);
  await subscriberSearch.press('Enter');
  console.log(`Subscriber Org searched: ${env.subscriberOrgId}`);

  const ascendionLink = page.getByRole('link', {
    name: /^Ascendion Engineering Private Limited$/i,
  });
  await expect(ascendionLink).toBeVisible({ timeout: 30000 });

  const [overviewPage] = await Promise.all([
    page.context().waitForEvent('page'),
    ascendionLink.click(),
  ]);
  await overviewPage.waitForLoadState('domcontentloaded');
  console.log('Overview URL:', overviewPage.url());

  await expect(overviewPage.locator('body')).toContainText(
    'Login Access Granted',
    { timeout: 30000 }
  );
  console.log('Ascendion Subscriber Overview opened.');

  // Pick the Login link for the intended subscriber username (if provided).
  const subscriberLoginUsername = process.env.SUBSCRIBER_LOGIN_USERNAME;
  let loginLink: Locator;

  if (subscriberLoginUsername) {
    const loginRow = overviewPage
      .getByRole('row')
      .filter({ hasText: subscriberLoginUsername });

    await expect(loginRow).toBeVisible({ timeout: 30000 });
    loginLink = loginRow.getByRole('link', { name: /^Login$/i });
  } else {
    const loginLinks = overviewPage.getByRole('link', { name: /^Login$/i });
    const count = await loginLinks.count();
    console.log(`Subscriber Login links found: ${count}`);

    if (count === 0) {
      throw new Error('No subscriber Login link was found.');
    }
    loginLink = loginLinks.first();
  }

  await expect(loginLink).toBeVisible({ timeout: 30000 });

  // Subscriber Login may open a new page or reuse the same one.
  const context = overviewPage.context();
  const pagesBeforeLogin = context.pages();
  const overviewUrlBeforeLogin = overviewPage.url();

  const outcome = waitForOutcome({
    newPage: () => context.waitForEvent('page', { timeout: 30000 }),
    sameTab: () =>
      overviewPage.waitForURL((url) => url.toString() !== overviewUrlBeforeLogin, {
        timeout: 30000,
      }),
  });

  await loginLink.click();
  await outcome;

  const subscriberPage =
    context.pages().find((candidate) => !pagesBeforeLogin.includes(candidate)) ||
    overviewPage;

  await subscriberPage.waitForLoadState('domcontentloaded');
  console.log('Subscriber URL after Login:', subscriberPage.url());

  // Subscriber login may open Classic - go straight to Lightning Accounts.
  const subscriberOrigin = new URL(subscriberPage.url()).origin;

  await subscriberPage.goto(
    `${subscriberOrigin}/lightning/o/Account/list?filterName=__Recent`,
    { waitUntil: 'domcontentloaded' }
  );

  await subscriberPage.waitForURL('**/lightning/o/Account/**', {
    timeout: 120000,
  });

  await expect(
    subscriberPage.getByRole('link', { name: /^Accounts$/i })
  ).toBeVisible({ timeout: 60000 });

  console.log('Subscriber Lightning Accounts page loaded:', subscriberPage.url());

  return subscriberPage;
}

/* ------------------------------------------------------------------ */
/* Generic form helpers                                                */
/* ------------------------------------------------------------------ */

async function selectComboboxValue(
  page: Page,
  input: Locator,
  value: string,
  label: string
): Promise<void> {
  if (!value) return;

  await expect(input).toBeVisible({ timeout: 30000 });
  await input.click();

  await input.press('Control+A').catch(() => undefined);
  await input.press('Backspace').catch(() => undefined);
  await input.pressSequentially(value, { delay: 30 });

  const listboxId = await input.getAttribute('aria-controls').catch(() => null);

  const listbox = listboxId
    ? page.locator(`#${listboxId}`)
    : page.locator('[role="listbox"]:visible').first();

  await expect(listbox).toBeVisible({ timeout: 15000 });

  const options = listbox.getByRole('option');
  const exactOption = options.filter({
    hasText: new RegExp(`^${escapeRegExp(value)}$`, 'i'),
  });

  const optionToSelect =
    (await exactOption.count()) > 0
      ? exactOption.first()
      : options
          .filter({ hasText: new RegExp(escapeRegExp(value), 'i') })
          .first();

  await expect(optionToSelect).toBeVisible({ timeout: 10000 });
  await optionToSelect.click();

  console.log(`${label} selected: ${value}`);
}

async function fillTextbox(
  dialog: Locator,
  name: RegExp,
  value: string,
  optional = false
): Promise<void> {
  if (!value) return;

  const field = dialog.getByRole('textbox', { name }).first();

  if (optional && !(await isVisible(field))) return;

  await field.fill(value, { timeout: 30000 });
}

/** Address picklists are comboboxes when State/Country picklists are enabled, plain textboxes otherwise. */
async function fillComboboxOrTextbox(
  page: Page,
  dialog: Locator,
  name: RegExp,
  value: string,
  label: string
): Promise<void> {
  if (!value) return;

  const combobox = dialog.getByRole('combobox', { name }).first();

  if (await isVisible(combobox)) {
    await selectComboboxValue(page, combobox, value, label);
  } else {
    await fillTextbox(dialog, name, value);
    console.log(`${label} entered: ${value}`);
  }
}

function normalizeCountry(country: string): string {
  const key = country.trim().toLowerCase().replace(/\./g, '');
  if (['us', 'usa', 'united states of america'].includes(key)) {
    return 'United States';
  }
  if (['uk', 'gb'].includes(key)) return 'United Kingdom';
  return country.trim();
}

async function cancelDialog(dialog: Locator, what: string): Promise<void> {
  const cancelButton = dialog.getByRole('button', { name: /^Cancel$/i }).first();

  if (await isVisible(cancelButton)) {
    await cancelButton.click();
    await expect(dialog).toBeHidden({ timeout: 30000 });
    return;
  }

  throw new Error(
    `Salesforce flagged the ${what} as a possible duplicate, but the dialog has no visible Cancel button.`
  );
}

/* ------------------------------------------------------------------ */
/* Accounts                                                            */
/* ------------------------------------------------------------------ */

function getAccountGrid(page: Page): Locator {
  return page
    .getByRole('grid', { name: /All Accounts/i })
    .filter({ visible: true })
    .last();
}

/**
 * Selects the "All Accounts" list view and sorts it by Created Date descending.
 * Returns false when the list view has no rows (so the caller can create an Account).
 */
async function waitForAccountsList(page: Page): Promise<boolean> {
  console.log('Waiting for Accounts list to load...');

  const listViewToggle = page
    .locator('button[title*="Select a List View"]')
    .or(page.getByRole('button', { name: /all accounts|list view/i }))
    .first();

  await expect(listViewToggle).toBeVisible({ timeout: 30000 });
  await listViewToggle.click();

  const allAccountsView = page.getByText('All Accounts', { exact: true }).last();
  const allAccountsViewVisible = await allAccountsView
    .waitFor({ state: 'visible', timeout: 15000 })
    .then(() => true)
    .catch(() => false);

  if (!allAccountsViewVisible) {
    throw new Error(
      'The All Accounts list view option was not available in the Accounts list.'
    );
  }

  await allAccountsView.click();
  console.log('All Accounts list view selected.');

  const accountGrid = getAccountGrid(page);
  await expect(accountGrid).toBeVisible({ timeout: 30000 });

  const hasRows = await accountGrid
    .getByRole('rowheader')
    .getByRole('link')
    .first()
    .waitFor({ state: 'visible', timeout: 15000 })
    .then(() => true)
    .catch(() => false);

  if (!hasRows) {
    console.log('The All Accounts list view has no rows.');
    return false;
  }

  const sortTarget = accountGrid
    .getByRole('button', { name: /Sort by:\s*Created Date/i })
    .last();
  await expect(sortTarget).toBeVisible({ timeout: 30000 });

  const createdDateHeader = sortTarget.locator(
    'xpath=ancestor::*[@role="columnheader"][1]'
  );
  const getSortState = async (): Promise<string> => {
    const [ariaSort, headerText] = await Promise.all([
      createdDateHeader.getAttribute('aria-sort').catch(() => null),
      createdDateHeader.innerText().catch(() => ''),
    ]);
    return `${ariaSort || ''} ${headerText}`.toLowerCase();
  };

  let sortState = await getSortState();
  console.log(`Created Date sort state: "${sortState.trim()}"`);

  for (
    let attempt = 0;
    attempt < 2 && !/descending/.test(sortState);
    attempt++
  ) {
    await sortTarget.click();
    await expect
      .poll(getSortState, { timeout: 10000, intervals: [250, 500] })
      .toMatch(/descending|ascending/);
    sortState = await getSortState();
  }

  await expect
    .poll(getSortState, { timeout: 10000, intervals: [250, 500] })
    .toMatch(/descending/);

  console.log('Accounts sorted by Created Date descending.');
  return true;
}

/**
 * Creates an Account from one salesfrocedataauto.csv row.
 * Returns 'created' or 'duplicate' (Salesforce reported a similar record; nothing was saved).
 */
async function createAccountFromCsv(
  page: Page,
  account: AccountCsvRecord
): Promise<'created' | 'duplicate'> {
  const accountName = account[ACCT_COL.name]?.trim() || '';
  if (!accountName) {
    throw new Error('Account Name is missing in the Account CSV row.');
  }

  console.log(`Creating Account from CSV: ${accountName}`);

  const newButton = page
    .getByRole('button', { name: /^New$/i })
    .or(page.getByRole('link', { name: /^New$/i }))
    .first();
  await expect(newButton).toBeVisible({ timeout: 30000 });
  await newButton.click();

  const dialog = page.getByRole('dialog', { name: /^New Account/i }).first();
  const nameField = dialog
    .getByRole('textbox', { name: /^\*?\s*Account Name$/i })
    .first();
  const nextButton = dialog.getByRole('button', { name: /^Next$/i }).first();

  // Some orgs show a record-type picker first, others open the form directly.
  const firstScreen = await waitForOutcome({
    form: () => nameField.waitFor({ state: 'visible', timeout: 30000 }),
    recordType: () => nextButton.waitFor({ state: 'visible', timeout: 30000 }),
  });

  if (firstScreen === 'recordType') {
    const recordType = process.env.ACCOUNT_RECORD_TYPE;
    if (recordType) {
      await dialog
        .getByRole('radio', { name: new RegExp(escapeRegExp(recordType), 'i') })
        .first()
        .check({ force: true });
    }
    await nextButton.click();
  } else if (firstScreen === null) {
    throw new Error('The New Account form did not open.');
  }

  await expect(nameField).toBeVisible({ timeout: 30000 });
  await nameField.fill(accountName);
  console.log(`Account Name entered: ${accountName}`);

  await fillTextbox(
    dialog,
    /^\*?\s*Phone$/i,
    account[ACCT_COL.phone]?.trim() || '',
    true
  );

  // Country first: the State picklist depends on it.
  await fillComboboxOrTextbox(
    page,
    dialog,
    /^Billing Country$/i,
    normalizeCountry(account[ACCT_COL.country] || ''),
    'Billing Country'
  );
  await fillTextbox(
    dialog,
    /^Billing Street$/i,
    account[ACCT_COL.street]?.trim() || ''
  );
  await fillTextbox(
    dialog,
    /^Billing City$/i,
    account[ACCT_COL.city]?.trim() || ''
  );
  await fillComboboxOrTextbox(
    page,
    dialog,
    /^Billing State\/Province$/i,
    account[ACCT_COL.state]?.trim() || '',
    'Billing State/Province'
  );
  await fillTextbox(
    dialog,
    /^Billing Zip\/Postal Code$/i,
    account[ACCT_COL.zip]?.trim() || ''
  );

  const saveButton = dialog.getByRole('button', { name: /^Save$/i }).first();
  await expect(saveButton).toBeEnabled({ timeout: 30000 });
  await saveButton.click();
  console.log(`Save clicked for Account: ${accountName}`);

  const duplicateWarning = page
    .getByText(/Similar Records Exist|This record looks like an existing record/i)
    .first();
  const errorBanner = dialog
    .getByText(
      /Review the errors on this page|Review the following fields|We hit a snag/i
    )
    .first();

  const saveOutcome = await waitForOutcome({
    duplicate: () =>
      duplicateWarning.waitFor({ state: 'visible', timeout: 60000 }),
    error: () => errorBanner.waitFor({ state: 'visible', timeout: 60000 }),
    saved: () => dialog.waitFor({ state: 'hidden', timeout: 60000 }),
  });

  if (saveOutcome === 'duplicate') {
    console.log(
      `Salesforce found a possible existing Account. Skipping: ${accountName}`
    );
    await cancelDialog(dialog, 'Account');
    return 'duplicate';
  }

  if (saveOutcome !== 'saved') {
    const dialogText = (await dialog.innerText().catch(() => ''))
      .replace(/\s+/g, ' ')
      .trim();
    throw new Error(
      `Salesforce did not save Account "${accountName}". Form: ${dialogText.slice(0, 800) || 'no form details available'}`
    );
  }

  // Saving a new Account lands on its record page.
  await page.waitForURL(ACCOUNT_VIEW_URL, { timeout: 60000 });
  await waitForAccountPage(page, accountName, 60000);
  console.log(`Account created: ${accountName}`);
  return 'created';
}

interface PreparedAccount {
  accountName: string;
  accountUrl: string;
  created: boolean;
}

/**
 * Requirement 1: pick a random Account from the Accounts list view (no searching).
 * Requirement 4/5: if no usable Account exists, create one from salesfrocedataauto.csv.
 * Contacts are handled afterwards by createContactsForAccount (requirements 3 and 6).
 */
async function prepareAccount(page: Page): Promise<PreparedAccount> {
  const forceCreate = /^(1|true|yes)$/i.test(
    process.env.FORCE_ACCOUNT_CREATION || ''
  );

  const hasRows = await waitForAccountsList(page);
  const mappedAccountNames = getMappedAccountNames();
  const visibleNames = new Set<string>();

  if (hasRows) {
    const accountLinks = getAccountGrid(page)
      .getByRole('rowheader')
      .getByRole('link');
    const accountNames: string[] = [];
    const eligibleIndexes: number[] = [];
    const linkCount = await accountLinks.count();

    for (let index = 0; index < linkCount; index++) {
      const name = (await accountLinks.nth(index).innerText()).trim();
      accountNames.push(name);
      visibleNames.add(name.toLowerCase());
      if (mappedAccountNames.has(name.toLowerCase())) {
        eligibleIndexes.push(index);
      }
    }

    if (forceCreate) {
      console.log('FORCE_ACCOUNT_CREATION is set. Skipping the random pick.');
    } else if (eligibleIndexes.length > 0) {
      // Optional: ACCOUNT_POOL_SIZE=N limits the pool to the N newest eligible accounts.
      const poolSize =
        Number(process.env.ACCOUNT_POOL_SIZE) || eligibleIndexes.length;
      const pool = eligibleIndexes.slice(0, poolSize);
      const selectedIndex = pool[Math.floor(Math.random() * pool.length)];
      const accountName = accountNames[selectedIndex];

      console.log(
        `Random Account selected from ${pool.length} eligible Account(s): ${accountName}`
      );

      await accountLinks.nth(selectedIndex).click();
      await waitForAccountPage(page, accountName);
      console.log(`Account opened from list view: ${accountName}`);

      return { accountName, accountUrl: page.url(), created: false };
    } else {
      console.log(
        `No visible Account has contact mappings in ${CONTACT_CSV}. Visible: ${accountNames.join(' | ')}. Falling back to Account creation.`
      );
    }
  }

  // ---- Account creation path ----
  const candidates = shuffle(
    readAccountCsvRows().filter((row) => {
      const key = normalizeKey(row[ACCT_COL.name]);
      return mappedAccountNames.has(key) && !visibleNames.has(key);
    })
  );

  if (candidates.length === 0) {
    throw new Error(
      `No Account can be created: ${ACCOUNT_CSV} has no Account that both has rows in ${CONTACT_CSV} and is missing from the list view.`
    );
  }

  const maxAttempts = Math.min(5, candidates.length);

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const row = candidates[attempt];
    const result = await createAccountFromCsv(page, row);

    if (result === 'created') {
      return {
        accountName: row[ACCT_COL.name].trim(),
        accountUrl: page.url(),
        created: true,
      };
    }
  }

  throw new Error(
    `Tried ${maxAttempts} Account(s) from ${ACCOUNT_CSV} but Salesforce flagged each as a duplicate.`
  );
}

/* ------------------------------------------------------------------ */
/* Contacts                                                            */
/* ------------------------------------------------------------------ */

function contactFullName(contact: ContactCsvRecord): string {
  return `${contact['FirstName']?.trim() || ''} ${contact['LastName']?.trim() || ''}`.trim();
}

function normalizeContactName(name: string): string {
  return name.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

async function getAccountContactCount(
  page: Page,
  accountName: string
): Promise<number> {
  const relatedTab = page
    .getByRole('tab', { name: /^Related$/i })
    .or(page.getByRole('button', { name: /^Related$/i }))
    .first();
  await expect(relatedTab).toBeVisible({ timeout: 30000 });
  await relatedTab.click();

  const contactsHeading = page
    .getByRole('heading', {
      name: /^(?:Related\s+)?Contacts(?:\s*\(\d+\+?\))?$/i,
    })
    .filter({ visible: true })
    .first();
  await expect(contactsHeading).toBeVisible({ timeout: 30000 });

  const contactsCard = contactsHeading.locator('xpath=ancestor::article[1]');
  await expect(contactsCard).toBeVisible({ timeout: 30000 });

  const contactLinks = contactsCard.locator(
    'a[href*="/lightning/r/Contact/"], a[href*="/lightning/r/003"]'
  );
  const emptyMessage = contactsCard
    .getByText(/no contacts found|no records found|no records to display/i)
    .filter({ visible: true })
    .first();

  let contactCount = 0;
  await expect
    .poll(
      async () => {
        const headingText = (await contactsHeading.innerText()).trim();
        const headingCount = headingText.match(/\((\d+)\+?\)\s*$/);
        const linkCount = await contactLinks.count();

        if (linkCount > 0) {
          contactCount = linkCount;
          return 'contacts';
        }
        if (headingCount) {
          contactCount = Number(headingCount[1]);
          return contactCount > 0 ? 'contacts' : 'empty';
        }
        if (await isVisible(emptyMessage)) return 'empty';
        return 'loading';
      },
      { timeout: 15000, intervals: [500, 1000] }
    )
    .not.toBe('loading');

  console.log(
    `Contacts found on Account page for "${accountName}": ${contactCount}`
  );
  return contactCount;
}

async function openContactsObjectPage(
  page: Page,
  accountUrl: string
): Promise<void> {
  const contactsUrl = new URL(accountUrl);
  contactsUrl.pathname = '/lightning/o/Contact/list';
  contactsUrl.search = '?filterName=Recent';
  contactsUrl.hash = '';

  await page.goto(contactsUrl.toString(), { waitUntil: 'domcontentloaded' });
  await page.waitForURL(/\/lightning\/o\/Contact\/list/i, { timeout: 60000 });
  await expect(
    page.getByRole('heading', { name: /^Contacts\b/i }).first()
  ).toBeVisible({ timeout: 60000 });
  await expect(
    page
      .getByRole('button', { name: /^New$/i })
      .or(page.getByRole('link', { name: /^New$/i }))
      .first()
  ).toBeVisible({ timeout: 30000 });

  console.log('Salesforce Contacts object page opened for contact creation.');
}

async function createSingleContact(
  page: Page,
  contact: ContactCsvRecord
): Promise<void> {
  const firstName = contact['FirstName']?.trim() || '';
  const lastName = contact['LastName']?.trim() || '';
  const accountName = contact['Account.Name']?.trim() || '';
  const fullName = contactFullName(contact);

  if (!lastName) {
    throw new Error(
      `Last Name is missing in the Contact CSV row for Account "${accountName}".`
    );
  }

  const newButton = page
    .getByRole('button', { name: /^New$/i })
    .or(page.getByRole('link', { name: /^New$/i }))
    .first();

  await expect(newButton).toBeVisible({ timeout: 30000 });
  await newButton.click();

  const contactDialog = page
    .getByRole('dialog', { name: /^New Contact$/i })
    .first();

  await expect(contactDialog).toBeVisible({ timeout: 30000 });

  await fillTextbox(contactDialog, /^First Name$/i, firstName);
  await fillTextbox(contactDialog, /^Last Name$/i, lastName);
  console.log(`Contact Name entered: ${fullName}`);

  await selectComboboxValue(
    page,
    contactDialog.getByRole('combobox', { name: /^Account Name$/i }).first(),
    accountName,
    'Account Name'
  );

  await selectComboboxValue(
    page,
    contactDialog.getByRole('combobox', { name: /^Mailing Country$/i }).first(),
    contact['MailingCountry']?.trim() || '',
    'Mailing Country'
  );

  await fillTextbox(contactDialog, /^Mailing Street$/i, contact['MailingStreet']?.trim() || '');
  await fillTextbox(contactDialog, /^Mailing City$/i, contact['MailingCity']?.trim() || '');

  await selectComboboxValue(
    page,
    contactDialog
      .getByRole('combobox', { name: /^Mailing State\/Province$/i })
      .first(),
    contact['MailingState']?.trim() || '',
    'Mailing State/Province'
  );

  await fillTextbox(
    contactDialog,
    /^Mailing Zip\/Postal Code$/i,
    contact['MailingPostalCode']?.trim() || ''
  );

  await fillTextbox(
    contactDialog,
    /^SSN$/i,
    contact['SSN__c']?.trim() || contact['SSN']?.trim() || ''
  );

  // Optional fields - skipped silently if the layout does not show them.
  await fillTextbox(contactDialog, /^Phone$/i, contact['Phone']?.trim() || '', true);
  await fillTextbox(contactDialog, /^Mobile$/i, contact['MobilePhone']?.trim() || '', true);
  await fillTextbox(contactDialog, /^Email$/i, contact['Email']?.trim() || '', true);
  await fillTextbox(contactDialog, /^Title$/i, contact['Title']?.trim() || '', true);
  await fillTextbox(contactDialog, /^Department$/i, contact['Department']?.trim() || '', true);

  const saveButton = contactDialog.getByRole('button', { name: /^Save$/i }).first();
  await expect(saveButton).toBeEnabled({ timeout: 30000 });
  await saveButton.click();
  console.log(`Save clicked for Contact: ${fullName}`);

  // Salesforce displays this warning inside the New Contact form, not as a separate dialog.
  const duplicateWarning = page
    .getByText(/Similar Records Exist|This record looks like an existing record/i)
    .first();

  const saveOutcome = await waitForOutcome({
    duplicate: () => duplicateWarning.waitFor({ state: 'visible', timeout: 60000 }),
    saved: () => contactDialog.waitFor({ state: 'hidden', timeout: 60000 }),
  });

  if (saveOutcome === 'duplicate') {
    console.log(
      `Salesforce found a possible existing Contact. Skipping duplicate: ${fullName} | Account: ${accountName}`
    );
    await cancelDialog(contactDialog, 'Contact');
    return;
  }

  if (saveOutcome === 'saved') {
    console.log(`Contact created: ${fullName} | Account: ${accountName}`);
    return;
  }

  const dialogText = (await contactDialog.innerText().catch(() => ''))
    .replace(/\s+/g, ' ')
    .trim();
  throw new Error(
    `Salesforce did not complete saving Contact "${fullName}" and no duplicate warning appeared. Form: ${dialogText || 'no form details available'}`
  );
}

async function createContactsForAccount(
  page: Page,
  accountName: string,
  accountUrl: string
): Promise<void> {
  const existingContactCount = await getAccountContactCount(page, accountName);

  if (existingContactCount > 0) {
    console.log(
      `Account "${accountName}" already has ${existingContactCount} contact(s). Skipping Contacts-page lookup and creation.`
    );
    return;
  }

  console.log(
    `No contacts found on Account "${accountName}". Creating contacts from CSV.`
  );

  const contacts = readContactsForAccount(accountName);

  if (contacts.length === 0) {
    throw new Error(
      `No Contact CSV rows found for Account "${accountName}". Add contact data to ${CONTACT_CSV} for this Account before running the regression test.`
    );
  }

  const uniqueContacts: ContactCsvRecord[] = [];
  const seen = new Set<string>();

  for (const contact of contacts) {
    const fullName = contactFullName(contact);
    const key = normalizeContactName(fullName);

    if (seen.has(key)) {
      console.log(`Contact already exists. Skipping: ${fullName}`);
      continue;
    }
    seen.add(key);
    uniqueContacts.push(contact);
  }

  // Each contact: go back to the Contacts list page, then click New.
  // Saving a contact navigates away, so the list must be reopened every time.
  for (const contact of uniqueContacts) {
    await openContactsObjectPage(page, accountUrl);
    await createSingleContact(page, contact);
  }

  // Return to the Account so the Review Credit flow can continue.
  await page.goto(accountUrl, { waitUntil: 'domcontentloaded' });
  await waitForAccountPage(page, accountName, 60000);

  // Confirm the contacts actually landed on the Account.
  // This also selects the Related tab, which the report steps need.
  let createdCount = 0;
  try {
    await expect
      .poll(
        async () => {
          createdCount = await getAccountContactCount(page, accountName);
          if (createdCount === 0) {
            await page.reload({ waitUntil: 'domcontentloaded' });
          }
          return createdCount;
        },
        { timeout: 60000, intervals: [2000, 3000, 5000] }
      )
      .toBeGreaterThan(0);
  } catch {
    throw new Error(
      `Contact creation finished but Account "${accountName}" still shows no contacts. ` +
        `All contacts may have been skipped as duplicates linked to another Account.`
    );
  }

  console.log(
    `Contact creation/check completed for Account: ${accountName} (${createdCount} contact(s))`
  );
}

/* ------------------------------------------------------------------ */
/* Reports                                                             */
/* ------------------------------------------------------------------ */

async function waitForCreditReportPage(frame: FrameLocator): Promise<void> {
  const heading = frame
    .getByRole('heading', { name: /request .*credit reports/i })
    .or(frame.getByText(/request .*credit reports/i))
    .or(frame.getByRole('button', { name: /request reports/i }))
    .first();

  await expect(heading).toBeVisible({ timeout: 45000 });
}

async function openReportViewAll(
  page: Page,
  reportLabel: RegExp
): Promise<void> {
  console.log(`Opening ${reportLabel} View All...`);

  const reportLink = page.getByRole('link', { name: reportLabel }).first();

  // Related lists are lazy rendered - scroll until the link appears.
  for (let i = 0; i < 24; i++) {
    if (await isVisible(reportLink)) break;
    await page.keyboard.press('PageDown');
    await page.waitForTimeout(250);
  }

  await expect(reportLink).toBeVisible({ timeout: 30000 });
  await reportLink.scrollIntoViewIfNeeded();
  await reportLink.click();

  await page.waitForURL('**/related/**/view', { timeout: 30000 });

  await expect(page.getByRole('heading', { name: reportLabel })).toBeVisible({
    timeout: 30000,
  });

  console.log(`${reportLabel} View All page loaded.`);
}

const REPORT_NAME_PATTERN = {
  Consumer: /^EfxConsumer-\d+$/i,
  Commercial: /Equifax CC-/i,
} as const;

/** Makes sure the given grid is sorted by Created Date, newest first. */
async function sortByCreatedDateDescending(grid: Locator): Promise<void> {
  const sortTarget = grid
    .getByRole('button', { name: /Sort by:\s*Created Date/i })
    .last();
  await expect(sortTarget).toBeVisible({ timeout: 30000 });

  const createdDateHeader = sortTarget.locator(
    'xpath=ancestor::*[@role="columnheader"][1]'
  );
  const getSortState = async (): Promise<string> => {
    const [ariaSort, headerText] = await Promise.all([
      createdDateHeader.getAttribute('aria-sort').catch(() => null),
      createdDateHeader.innerText().catch(() => ''),
    ]);
    return `${ariaSort || ''} ${headerText}`.toLowerCase();
  };

  let sortState = await getSortState();
  for (
    let attempt = 0;
    attempt < 2 && !/descending/.test(sortState);
    attempt++
  ) {
    await sortTarget.click();
    await expect
      .poll(getSortState, { timeout: 10000, intervals: [250, 500] })
      .toMatch(/descending|ascending/);
    sortState = await getSortState();
  }

  await expect
    .poll(getSortState, { timeout: 10000, intervals: [250, 500] })
    .toMatch(/descending/);
}

/** Report record names currently listed (newest first) on a "View All" related list page. */
async function getReportNames(
  page: Page,
  reportType: 'Consumer' | 'Commercial'
): Promise<string[]> {
  const grid = page.getByRole('grid').filter({ visible: true }).last();
  const gridVisible = await grid
    .waitFor({ state: 'visible', timeout: 15000 })
    .then(() => true)
    .catch(() => false);

  // An empty related list may not render a grid at all.
  if (!gridVisible) return [];

  await sortByCreatedDateDescending(grid).catch(() =>
    console.log(`Could not confirm Created Date sort for ${reportType} reports.`)
  );

  const names = await grid
    .getByRole('link', { name: REPORT_NAME_PATTERN[reportType] })
    .allInnerTexts();

  return names.map((name) => name.trim()).filter(Boolean);
}

function nameTokens(name: string): string[] {
  return name
    .toLowerCase()
    .split(/[^\p{L}\p{N}]+/u)
    .filter(Boolean);
}

/** True when every word of the contact name appears on the page ("LAST, FIRST" or "First Last"). */
function textContainsName(pageText: string, contactName: string): boolean {
  const tokens = nameTokens(contactName);
  if (tokens.length === 0) return false;
  const pageTokens = new Set(nameTokens(pageText));
  return tokens.every((token) => pageTokens.has(token));
}

/**
 * Screenshots a report record that is already open.
 * `skipIf` can veto the screenshot (returns a reason) once the details have loaded.
 */
async function captureOpenedReportDetail(
  page: Page,
  testInfo: TestInfo,
  reportType: 'Consumer' | 'Commercial',
  reportName: string,
  skipIf?: (pageText: string) => string | null
): Promise<boolean> {
  await page.waitForLoadState('domcontentloaded');
  await expect(page.locator('body')).toContainText(reportName, {
    timeout: 60000,
  });

  const detailsTab = page
    .getByRole('tab', { name: /^Details$/i })
    .or(page.getByRole('button', { name: /^Details$/i }))
    .first();
  await expect(detailsTab).toBeVisible({ timeout: 60000 });
  await detailsTab.click();

  const reportIdLabel = page
    .getByText(new RegExp(`^Equifax ${reportType} Report ID$`, 'i'))
    .filter({ visible: true })
    .first();
  await expect(reportIdLabel).toBeVisible({ timeout: 60000 });
  await expect
    .poll(
      async () => {
        const reportDetails = await captureReportDetails(page, reportType);
        return reportDetails['Equifax Report ID'] || '';
      },
      { timeout: 60000, intervals: [500, 1000, 2000] }
    )
    .toBeTruthy();

  if (skipIf) {
    const details = await captureReportDetails(page, reportType);
    const reason = skipIf(details.pageText || '');
    if (reason) {
      console.log(`Skipping screenshot for ${reportName}: ${reason}`);
      return false;
    }
  }

  await reportIdLabel.scrollIntoViewIfNeeded();

  // Wait for spinners to clear and the PDF preview to render before the screenshot.
  await waitForReportToFinishLoading(
    page,
    reportType === 'Commercial'
      ? COMMERCIAL_REPORT_RENDER_WAIT_MS
      : REPORT_RENDER_WAIT_MS,
    reportType === 'Commercial'
  );

  const screenshotLabel = `${reportType.toLowerCase()}-report-${reportName
    .replace(/[^a-z0-9-]+/gi, '-')
    .replace(/^-|-$/g, '')}-detail`;
  await captureScreenshot(page, testInfo, screenshotLabel);
  console.log(`${reportType} report detail captured: ${reportName}`);
  return true;
}

/** Opens the newest report of the given type (by Created Date) and screenshots it. */
async function captureReportDetailScreenshots(
  page: Page,
  testInfo: TestInfo,
  reportType: 'Consumer' | 'Commercial'
): Promise<void> {
  const headingName =
    reportType === 'Consumer'
      ? /Equifax Consumer Reports/i
      : /Equifax Commercial Reports/i;

  await expect(page.getByRole('heading', { name: headingName })).toBeVisible({
    timeout: 30000,
  });

  const reportGrid = page.getByRole('grid').filter({ visible: true }).last();
  await expect(reportGrid).toBeVisible({ timeout: 30000 });
  await sortByCreatedDateDescending(reportGrid);

  const latestReportLink = reportGrid
    .getByRole('link', { name: REPORT_NAME_PATTERN[reportType] })
    .first();
  await expect(latestReportLink).toBeVisible({ timeout: 30000 });

  const href = await latestReportLink.getAttribute('href');
  const reportName = (await latestReportLink.innerText()).trim();
  if (!href?.includes('/lightning/r/') || !reportName) {
    throw new Error(
      `The newest ${reportType} report link was missing its record URL or name.`
    );
  }

  console.log(
    `Opening newest ${reportType} report by Created Date descending: ${reportName}`
  );
  await latestReportLink.click();
  await page.waitForURL('**/lightning/r/**/view', { timeout: 30000 });
  await captureOpenedReportDetail(page, testInfo, reportType, reportName);
}

/**
 * Screenshots ONLY the Consumer reports created by the request that just ran.
 * - Reports that already existed before the request are never opened (no stale screenshots).
 * - Reports that belong to a NO-HIT contact are skipped.
 * Must be called from the Consumer Reports "View All" page.
 */
async function captureNewConsumerReportScreenshots(
  page: Page,
  testInfo: TestInfo,
  reportNamesBefore: string[],
  results: ConsumerRequestResults
): Promise<number> {
  const before = new Set(reportNamesBefore.map((name) => name.toLowerCase()));
  const afterNames = await getReportNames(page, 'Consumer');
  const newReportNames = afterNames.filter(
    (name) => !before.has(name.toLowerCase())
  );

  console.log(
    `New Consumer report(s) from this request: ${newReportNames.join(', ') || 'none'}`
  );

  if (newReportNames.length !== results.expectedReportCount) {
    throw new Error(
      `Expected ${results.expectedReportCount} new Consumer report(s) (one per HIT contact, NO-HIT excluded) but found ${newReportNames.length}: ${newReportNames.join(', ') || 'none'}.`
    );
  }

  const noHitNames = results.noHitContacts.map((contact) => contact.name);
  let captured = 0;

  for (const reportName of newReportNames) {
    const grid = page.getByRole('grid').filter({ visible: true }).last();
    const link = grid
      .getByRole('link', { name: reportName, exact: true })
      .first();

    await expect(link).toBeVisible({ timeout: 30000 });
    await link.click();
    await page.waitForURL('**/lightning/r/**/view', { timeout: 30000 });

    const wasCaptured = await captureOpenedReportDetail(
      page,
      testInfo,
      'Consumer',
      reportName,
      (pageText) => {
        const matchesNoHit = noHitNames.some((name) =>
          textContainsName(pageText, name)
        );
        const matchesHit = results.hitContacts.some((name) =>
          textContainsName(pageText, name)
        );
        return matchesNoHit && !matchesHit
          ? 'report belongs to a NO-HIT contact'
          : null;
      }
    );
    if (wasCaptured) captured++;

    // Back to the Consumer Reports list for the next report.
    await page.goBack({ waitUntil: 'domcontentloaded' });
    await expect(
      page.getByRole('heading', { name: /Equifax Consumer Reports/i })
    ).toBeVisible({ timeout: 30000 });
  }

  if (captured !== results.expectedReportCount) {
    throw new Error(
      `Expected ${results.expectedReportCount} Consumer report screenshot(s) for HIT contacts but captured ${captured}. A report may have been created for a NO-HIT contact.`
    );
  }

  console.log(
    `Consumer report screenshots captured: ${captured} (HIT contacts: ${results.hitContacts.length})`
  );
  return captured;
}

async function getReportCount(
  page: Page,
  reportType: 'Consumer' | 'Commercial'
): Promise<number> {
  const reportStatus = page.getByRole('status', {
    name:
      reportType === 'Consumer'
        ? 'Equifax Consumer Reports'
        : 'Equifax Commercial Reports',
  });

  await expect(reportStatus).toBeVisible({ timeout: 30000 });

  const statusText = (await reportStatus.textContent())?.trim() || '';
  const countMatch = statusText.match(/(\d+)\s+items?/i);

  if (!countMatch) {
    throw new Error(
      `Unable to extract ${reportType} report count from: "${statusText}"`
    );
  }

  return Number(countMatch[1]);
}

/** Reload the related list until the report count reaches `expected`. */
async function waitForReportCount(
  page: Page,
  reportType: 'Consumer' | 'Commercial',
  before: number,
  expected: number,
  exactMatch = false
): Promise<number> {
  let current = before;

  const reportCount = expect.poll(
    async () => {
      await page.reload({ waitUntil: 'domcontentloaded' });
      current = await getReportCount(page, reportType);

      console.log(
        `${reportType} Reports: before=${before}, current=${current}, expected${exactMatch ? '' : ' minimum'}=${expected}`
      );

      return current;
    },
    { timeout: 180000, intervals: [2000, 3000, 5000] }
  );

  if (exactMatch) {
    await reportCount.toBe(expected);
  } else {
    await reportCount.toBeGreaterThanOrEqual(expected);
  }

  return current;
}

async function getAvailableConsumerContactCount(
  frame: FrameLocator
): Promise<number> {
  // One round trip instead of one per cell.
  const texts = await frame
    .locator('table tbody tr td:nth-child(2)')
    .allTextContents();

  const validNameCount = texts.filter((text) => {
    const trimmed = text.trim();
    return trimmed && trimmed.toUpperCase() !== 'NAME';
  }).length;

  console.log(`Available Consumer contacts: ${validNameCount}`);
  return validNameCount;
}

async function selectConsumerContacts(frame: FrameLocator): Promise<number> {
  const checkboxes = frame.locator('input[type="checkbox"]');

  await expect
    .poll(() => checkboxes.count(), { timeout: 30000, intervals: [500, 1000] })
    .toBeGreaterThan(1);

  console.log(`Checkbox inputs found: ${await checkboxes.count()}`);

  // First checkbox is "Select All".
  const selectAll = checkboxes.first();
  await expect(selectAll).toBeVisible({ timeout: 30000 });
  await expect(selectAll).toBeEnabled({ timeout: 30000 });

  if (!(await selectAll.isChecked())) {
    await selectAll.check({ force: true });
  }

  // Counts evaluated in the browser in one call (visible + enabled rows only).
  const countChecked = () =>
    checkboxes.evaluateAll(
      (els) =>
        (els as HTMLInputElement[])
          .slice(1)
          .filter((el) => !el.disabled && el.offsetParent !== null && el.checked)
          .length
    );

  await expect
    .poll(countChecked, { timeout: 30000, intervals: [250, 500, 1000] })
    .toBeGreaterThan(0);

  // Pick up any row that Select All did not tick.
  const uncheckedIndexes = await checkboxes.evaluateAll((els) =>
    (els as HTMLInputElement[])
      .map((el, index) => ({ el, index }))
      .filter(
        ({ el, index }) =>
          index > 0 && !el.disabled && el.offsetParent !== null && !el.checked
      )
      .map(({ index }) => index)
  );

  for (const index of uncheckedIndexes) {
    await checkboxes.nth(index).check({ force: true, timeout: 5000 });
  }

  const selectedCount = await countChecked();
  console.log(`Total Consumer contacts selected: ${selectedCount}`);

  return selectedCount;
}

interface ConsumerRequestResults {
  hitContacts: string[];
  noHitContacts: { name: string; detail: string }[];
  /** Reports that must exist after this request = number of HIT contacts (NO-HIT contacts are excluded). */
  expectedReportCount: number;
}

/**
 * Reads the per-contact result table after "Request Reports".
 * Each row is classified as HIT or NO-HIT so that only HIT contacts are treated as reports.
 */
async function getConsumerRequestResults(
  frame: FrameLocator,
  expectedContactCount: number
): Promise<ConsumerRequestResults> {
  // One round trip: direct child cells of every row.
  const rows: string[][] = await frame
    .locator('table tbody tr')
    .evaluateAll((trs) =>
      (trs as HTMLElement[]).map((tr) =>
        Array.from(tr.querySelectorAll(':scope > td')).map((td) =>
          (td as HTMLElement).innerText.replace(/\s+/g, ' ').trim()
        )
      )
    );

  const hitContacts: string[] = [];
  const noHitContacts: { name: string; detail: string }[] = [];

  for (const cells of rows) {
    const statusIndex = cells.findIndex(
      (cell) => /^Hit$/i.test(cell) || /^No[\s-]*Hit\b/i.test(cell)
    );
    if (statusIndex < 1) continue;

    const name = cells[statusIndex - 1];
    const status = cells[statusIndex];

    if (/^Hit$/i.test(status)) {
      hitContacts.push(name);
    } else {
      noHitContacts.push({ name, detail: status });
    }
  }

  const classifiedCount = hitContacts.length + noHitContacts.length;
  if (classifiedCount !== expectedContactCount) {
    throw new Error(
      `Consumer request status classification incomplete. Expected=${expectedContactCount}, classified=${classifiedCount}, Hit=${hitContacts.length}, No Hit=${noHitContacts.length}.`
    );
  }

  console.log(
    `Consumer request results: Hit=${hitContacts.length}, No Hit=${noHitContacts.length}; only HIT results count as reports.`
  );
  for (const noHit of noHitContacts) {
    console.log(`NO-HIT contact: ${noHit.name} -> ${noHit.detail}`);
  }

  return {
    hitContacts,
    noHitContacts,
    expectedReportCount: hitContacts.length,
  };
}

async function clickDoneAfterRequest(
  page: Page,
  testInfo: TestInfo,
  expectedContactCount: number
): Promise<ConsumerRequestResults> {
  console.log('Waiting for Consumer report processing to complete');

  let stableDoneChecks = 0;

  await expect
    .poll(
      async () => {
        const frame = page.locator(VF_FRAME).first().contentFrame();

        const [doneVisible, requestReportsVisible] = await Promise.all([
          isVisible(frame.getByRole('button', { name: /^Done$/i })),
          isVisible(frame.getByRole('button', { name: /request reports/i })),
        ]);

        stableDoneChecks =
          doneVisible && !requestReportsVisible ? stableDoneChecks + 1 : 0;

        console.log(
          `Done=${doneVisible}, RequestReports=${requestReportsVisible}, stableChecks=${stableDoneChecks}`
        );

        // Completed state must survive multiple Visualforce refresh cycles.
        return stableDoneChecks >= 2;
      },
      { timeout: 120000, intervals: [1000, 2000, 2000] }
    )
    .toBe(true);

  const completedFrame = page.locator(VF_FRAME).first().contentFrame();
  const doneButton = completedFrame.getByRole('button', { name: /^Done$/i });

  await expect(doneButton).toBeVisible({ timeout: 30000 });
  const results = await getConsumerRequestResults(
    completedFrame,
    expectedContactCount
  );

  // Condition before Done: only HIT contacts count towards the report pull.
  // Example: 3 contacts, 1 NO-HIT + 2 HIT -> exactly 2 reports are expected.
  if (results.hitContacts.length > 0) {
    console.log(
      `HIT contact(s) (${results.hitContacts.length}): ${results.hitContacts.join(' | ')}`
    );
    console.log(
      `Report count will be validated for ${results.expectedReportCount} of ${expectedContactCount} contact(s).`
    );
  } else {
    console.log(
      'No contact returned HIT. No report is expected for this request.'
    );
  }
  if (results.noHitContacts.length > 0) {
    console.log(
      `NO-HIT contact(s) excluded from the report count (${results.noHitContacts.length}): ${results.noHitContacts
        .map((contact) => contact.name)
        .join(' | ')}`
    );
  }

  await doneButton.scrollIntoViewIfNeeded();

  // The result table (HIT / NO-HIT per contact) is the evidence for NO-HIT scenarios.
  const screenshotLabel =
    results.noHitContacts.length > 0
      ? 'consumer-no-hit-result'
      : 'consumer-processing-complete';
  await captureScreenshot(page, testInfo, screenshotLabel);

  for (const noHit of results.noHitContacts) {
    testInfo.annotations.push({
      type: 'consumer-no-hit',
      description: `${noHit.name} - ${noHit.detail}`,
    });
  }

  await doneButton.click();

  console.log('Processing completed. Done button clicked.');
  return results;
}

async function captureReportDetails(
  page: Page,
  reportType: 'Consumer' | 'Commercial'
): Promise<Record<string, string>> {
  const bodyText = (await page.locator('body').innerText())
    .replace(/\s+/g, ' ')
    .trim();

  const patterns: Record<string, RegExp> = {
    'Equifax Report ID': new RegExp(
      `Equifax ${reportType} Report ID\\s+([A-Za-z0-9-]+)`,
      'i'
    ),
    Contact: /Contact\s+([A-Z0-9\s\-.,]+)/i,
    Account: /Account\s+([A-Z0-9\s\-.,/&()]+)/i,
    'Beacon Score': /Beacon Score\s+([0-9]+)/i,
    'Credit Quality Rating': /Credit Quality Rating\s+([A-Za-z0-9\s\-.,]+)/i,
  };

  const extracted: Record<string, string> = { pageText: bodyText };

  for (const [key, pattern] of Object.entries(patterns)) {
    const match = bodyText.match(pattern);
    if (match) extracted[key] = match[1].trim();
  }

  if (
    /(Error|Exception|Unable|Failed|Invalid|404|Not Found|No content|No records|No data)/i.test(
      bodyText
    )
  ) {
    extracted.pageError = bodyText.slice(0, 1500);
  }

  return extracted;
}

/* ------------------------------------------------------------------ */
/* Test                                                                */
/* ------------------------------------------------------------------ */

test(
  'One click: login -> random/created account -> contacts from CSV -> credit review -> validate reports',
  async ({ page: initialPage }, testInfo) => {
    test.setTimeout(600000);

    /* STEP 1 - Login */
    const page = await loginToSalesforce(initialPage);
    await captureScreenshot(page, testInfo, 'login-successful');

    /* STEP 2 - Account (random from list, or created from CSV) + Contacts */
    const { accountName, accountUrl, created } = await prepareAccount(page);
    const selectedAccountUrl = accountUrl;

    testInfo.annotations.push({
      type: 'account',
      description: `${accountName} (${created ? 'created from CSV' : 'picked from list view'})`,
    });

    console.log(
      `Processing mapped contacts for Account: ${accountName} (${created ? 'newly created' : 'existing'})`
    );

    await createContactsForAccount(page, accountName, selectedAccountUrl);
    await captureScreenshot(page, testInfo, 'account-contacts-ready');

    /* STEP 3 - Commercial Report count before Review Credit */
    await openReportViewAll(page, /Equifax Commercial Reports/i);

    const commercialReportCountBefore = await getReportCount(page, 'Commercial');
    console.log(
      `Commercial Reports before Review Credit: ${commercialReportCountBefore}`
    );
    await captureScreenshot(page, testInfo, 'commercial-reports-before');

    /* STEP 4 - Return to Account */
    await returnToAccount(page, accountName);

    /* STEP 5 - Open Review Credit */
    await clickAccountAction(page, /^Review Credit$/i);
    console.log('Review Credit button clicked.');

    /* STEP 6 - Review Credit iframe */
    const { element: reviewFrameElement, frame } = getVfFrame(page);
    await expect(reviewFrameElement).toBeVisible({ timeout: 60000 });
    console.log('Review Credit iframe loaded.');
    await captureScreenshot(page, testInfo, 'review-credit-start');

    /* STEP 7 - Initial Go */
    const goButton = frame
      .getByRole('button', { name: /^Go$/i })
      .or(frame.locator('input[value="Go"]'))
      .first();

    await expect(goButton).toBeVisible({ timeout: 30000 });
    await goButton.click();
    console.log('Initial Review Credit Go button clicked.');

    /* STEP 8 - Optional Consumer contact selection */
    const consumerReportHeading = frame
      .getByRole('heading', { name: /request consumer credit reports/i })
      .or(frame.getByText(/request consumer credit reports/i))
      .first();

    const creditReviewHeading = frame
      .getByRole('heading', { name: /credit review/i })
      .first();
    const requiredFieldsError = frame
      .getByText(/required fields are missing/i)
      .first();
    const databaseUpdateError = frame
      .getByText(/error occurred updating the salesforce database/i)
      .first();

    // Whichever shows first: consumer selection page, or a final response/error.
    const firstScreen = await waitForOutcome({
      consumerSelection: () =>
        consumerReportHeading.waitFor({ state: 'visible', timeout: 15000 }),
      response: () =>
        creditReviewHeading
          .or(requiredFieldsError)
          .or(databaseUpdateError)
          .first()
          .waitFor({ state: 'visible', timeout: 15000 }),
    });

    if (firstScreen === 'consumerSelection') {
      console.log('Review Credit displayed Consumer contact selection.');

      const availableContactCount =
        await getAvailableConsumerContactCount(frame);

      if (availableContactCount === 0) {
        const cancelButton = frame
          .getByRole('button', { name: /^Cancel$/i })
          .first();

        if (await isVisible(cancelButton)) await cancelButton.click();

        throw new Error(
          `No Consumer contacts are available for Review Credit on account "${accountName}".`
        );
      }

      const selectedContactCount = await selectConsumerContacts(frame);

      if (selectedContactCount === 0) {
        throw new Error(
          'No Consumer contacts could be selected during Review Credit.'
        );
      }

      console.log(
        `${selectedContactCount} Consumer contact(s) selected during Review Credit.`
      );

      const consumerGoButton = frame
        .getByRole('button', { name: /^Go$/i })
        .or(frame.locator('input[value="Go"]'))
        .first();

      await expect(consumerGoButton).toBeVisible({ timeout: 30000 });
      await consumerGoButton.click();
      console.log('Consumer contact selection Go button clicked.');
    }

    /* STEP 9 - Wait for response page or application error */
    await expect(
      creditReviewHeading.or(requiredFieldsError).or(databaseUpdateError).first()
    ).toBeVisible({ timeout: 120000 });

    console.log('Review Credit response page loaded.');
    await captureScreenshot(page, testInfo, 'review-credit-response');

    /* STEP 10 - Read the response */
    const reviewPageText = (
      await frame.locator('body').innerText().catch(() => '')
    )
      .replace(/\s+/g, ' ')
      .trim();

    console.log('Review Credit response:', reviewPageText.slice(0, 1500));

    const requiredFieldsMatch = reviewPageText.match(
      /Required fields are missing:\s*\[([^\]]+)\]/i
    );

    if (requiredFieldsMatch) {
      // Mark the run as skipped (not passed) so a skipped account is visible in the report.
      test.skip(
        true,
        `Account "${accountName}" skipped. Missing field(s): ${requiredFieldsMatch[1]}`
      );
      return;
    }

    if (/error occurred updating the salesforce database/i.test(reviewPageText)) {
      throw new Error('Review Credit failed while updating the Salesforce database.');
    }

    if (/error|exception|unable|failed|invalid/i.test(reviewPageText)) {
      throw new Error(
        `Review Credit failed. Response: ${reviewPageText.slice(0, 1500)}`
      );
    }

    /* STEP 11 - Return to Account */
    const returnToAccountButton = frame
      .getByRole('button', { name: /return to account detail/i })
      .or(frame.getByRole('link', { name: /return to account detail/i }))
      .first();

    await expect(returnToAccountButton).toBeVisible({ timeout: 60000 });
    await returnToAccountButton.scrollIntoViewIfNeeded();
    await returnToAccountButton.click();
    console.log('Return to Account Detail clicked.');

    /* STEP 12 - Confirm return */
    await page.waitForURL(ACCOUNT_VIEW_URL, { timeout: 30000 });
    await waitForAccountPage(page, accountName);
    console.log('Review Credit completed and returned to Account.');

    /* STEP 13-15 - Validate Commercial Report was created */
    await openReportViewAll(page, /Equifax Commercial Reports/i);

    const expectedCommercialReportCount = commercialReportCountBefore + 1;
    console.log(
      `Commercial Reports expected minimum count: ${expectedCommercialReportCount}`
    );

    const commercialReportCountAfter = await waitForReportCount(
      page,
      'Commercial',
      commercialReportCountBefore,
      expectedCommercialReportCount
    );

    console.log(
      `Review Credit completed. Commercial Reports changed from ${commercialReportCountBefore} to ${commercialReportCountAfter}.`
    );
    await captureScreenshot(page, testInfo, 'commercial-reports-after');

    /* ============ PART 2 - CONSUMER CREDIT REVIEW ============ */

    /* STEP 16 - Back to Account */
    await returnToAccount(page, accountName);
    console.log('Returned to Account after Commercial Report validation.');

    /* STEP 17 - Consumer Report count before */
    await openReportViewAll(page, /Equifax Consumer Reports/i);

    const consumerReportCountBefore = await getReportCount(page, 'Consumer');
    console.log(
      `Consumer Reports before Consumer Credit Review: ${consumerReportCountBefore}`
    );
    // Remember the existing reports so only newly created ones are screenshotted later.
    const consumerReportNamesBefore = await getReportNames(page, 'Consumer');
    await captureScreenshot(page, testInfo, 'consumer-reports-before');

    /* STEP 18 - Back to Account */
    await returnToAccount(page, accountName);
    console.log('Returned to Account before Consumer Credit Review.');

    /* STEP 19 - Click Consumer Credit Review (direct or via Show More Actions) */
    await clickAccountAction(page, /^Consumer Credit Review$/i);
    console.log('Consumer Credit Review clicked.');

    /* STEP 20 - Consumer iframe */
    const { element: consumerFrameElement, frame: consumerFrame } =
      getVfFrame(page);

    await expect(consumerFrameElement).toBeVisible({ timeout: 60000 });
    await waitForCreditReportPage(consumerFrame);
    console.log('Request Consumer Credit Reports page loaded.');
    await captureScreenshot(page, testInfo, 'consumer-request-page');

    /* STEP 21 - Count available contacts */
    const availableConsumerContactCount =
      await getAvailableConsumerContactCount(consumerFrame);

    if (availableConsumerContactCount === 0) {
      const cancelButton = consumerFrame
        .getByRole('button', { name: /^Cancel$/i })
        .first();

      if (await isVisible(cancelButton)) await cancelButton.click();

      throw new Error(
        `No Consumer contacts are available for account "${accountName}".`
      );
    }

    /* STEP 22 - Select all contacts */
    const selectedConsumerContactCount =
      await selectConsumerContacts(consumerFrame);

    if (selectedConsumerContactCount === 0) {
      throw new Error('No Consumer contact checkboxes could be selected.');
    }

    if (selectedConsumerContactCount !== availableConsumerContactCount) {
      throw new Error(
        `Contact/checkbox mismatch. Contacts=${availableConsumerContactCount}, selected=${selectedConsumerContactCount}`
      );
    }

    console.log(
      `${selectedConsumerContactCount} Consumer contact(s) selected.`
    );
    await captureScreenshot(page, testInfo, 'consumer-contacts-selected');

    /* STEP 23 - Request Reports */
    const requestReportsButton = consumerFrame
      .getByRole('button', { name: /request reports/i })
      .or(consumerFrame.locator('input[value*="Request Reports" i]'))
      .first();

    await expect(requestReportsButton).toBeVisible({ timeout: 30000 });
    await expect(requestReportsButton).toBeEnabled({ timeout: 30000 });
    await requestReportsButton.click();
    console.log('Request Reports clicked.');
    await captureScreenshot(page, testInfo, 'consumer-request-submitted');

    /* STEP 24 - Wait for processing, click Done */
    const consumerResults = await clickDoneAfterRequest(
      page,
      testInfo,
      selectedConsumerContactCount
    );
    const consumerHitCount = consumerResults.expectedReportCount;

    /* STEP 25 - Confirm return */
    await page.waitForURL(ACCOUNT_VIEW_URL, { timeout: 60000 });
    await waitForAccountPage(page, accountName);
    console.log('Returned to Account after Consumer Credit Review.');

    /* STEP 26-27 - Validate Consumer Reports persisted */
    await openReportViewAll(page, /Equifax Consumer Reports/i);

    const expectedConsumerReportCount =
      consumerReportCountBefore + consumerHitCount;

    console.log(
      `Consumer Reports expected count: ${expectedConsumerReportCount} (${consumerHitCount} HIT counted, ${consumerResults.noHitContacts.length} NO-HIT excluded, of ${selectedConsumerContactCount} selected)`
    );

    const consumerReportCountAfter = await waitForReportCount(
      page,
      'Consumer',
      consumerReportCountBefore,
      expectedConsumerReportCount,
      true
    );

    console.log(
      `Consumer Credit Review completed. Consumer Reports changed from ${consumerReportCountBefore} to ${consumerReportCountAfter}.`
    );
    await captureScreenshot(page, testInfo, 'consumer-reports-after');

    /* STEP 28 - Screenshot only the NEW Consumer reports of HIT contacts */
    if (consumerHitCount > 0) {
      await captureNewConsumerReportScreenshots(
        page,
        testInfo,
        consumerReportNamesBefore,
        consumerResults
      );
    } else {
      console.log(
        'All Consumer contacts returned NO-HIT. The NO-HIT result screenshot was captured; no Consumer report screenshot is taken.'
      );
    }

    /* STEP 29 - Capture the newest Commercial report (waits for PDF to render) */
    await returnToAccount(page, accountName);
    await openReportViewAll(page, /Equifax Commercial Reports/i);
    await captureReportDetailScreenshots(page, testInfo, 'Commercial');

    console.log('Consumer Credit Review validation completed.');

    return;
  }
);