import { test, expect } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { routes } from '../../config/routes';

test.use({
  storageState: 'auth.json'
});

const contactExists = async (
  page: import('@playwright/test').Page,
  contact: Record<string, string>
): Promise<boolean> => {
  const fullName = `${contact['FirstName']} ${contact['LastName']}`.trim();
  const accountName =
    contact['Account.Name']?.trim();

  // await page.goto(
  //   'https://orgfarm-c213ad92bb-dev-ed.develop.lightning.force.com/lightning/o/Contact/list?filterName=Recent',
  //   { waitUntil: 'domcontentloaded' }
  // );

  const searchBox = page.locator(
    'input[placeholder="Search this list..."]'
  );

  await searchBox.waitFor({
    state: 'visible',
    timeout: 30000
  });

  await searchBox.fill(fullName);
  await searchBox.press('Enter');
  await page.waitForTimeout(2000);

// Find a row containing both Contact and Account
const matchingRow = page
.getByRole('row')
.filter({
has: page.getByRole('link', {
name: fullName,
exact: true
})
})
.filter({
has: page.getByRole('link', {
name: accountName,
exact: true
})
});
const exists = await matchingRow
.count()
.then(count => count > 0)
.catch(() => false);
console.log(
`Contact check: ${fullName} | Account: ${accountName} | Exists: ${exists}`
);
    console.log(
    `Contact check: ${fullName} | Account: ${accountName} | Exists: ${exists} | Rows: ${await matchingRow.count()}`
    );

  return exists;
};

const parseCsvLine = (line: string): string[] => {
  const values: string[] = [];
  let currentValue = '';
  let insideQuotes = false; 

  for (let i = 0; i < line.length; i++) {
    const char = line[i];

    if (char === '"') {
      insideQuotes = !insideQuotes;
    } else if (char === ',' && !insideQuotes) {
      values.push(currentValue.trim());
      currentValue = '';
    } else {
      currentValue += char;
    }
  }

  values.push(currentValue.trim());

  return values;
};

const readCsvContacts = async (
  filePath: string,
  accountName: string
): Promise<Record<string, string>[]> => {
  const fileContent = await fs.promises.readFile(filePath, 'utf8');

  const lines = fileContent
    .split(/\r?\n/)
    .filter(line => line.trim());

  if (lines.length === 0) {
    return [];
  }

  const headers = parseCsvLine(lines[0]);
  const contacts: Record<string, string>[] = [];

  for (const line of lines.slice(1)) {
    const values = parseCsvLine(line);
    const row: Record<string, string> = {};

    headers.forEach((header, index) => {
      row[header] = values[index] || '';
    });

    contacts.push(row);
  }

  return contacts;
};

/**
 * Salesforce Lightning comboboxes (Account Name lookup, Mailing Country,
 * Mailing State, etc.) are all driven by JS keyboard/click handlers rather
 * than the underlying <input>'s literal value. Some of these inputs carry
 * readonly/aria-readonly="true" (e.g. Mailing Country), which makes
 * Playwright's fill() fail outright ("element is not editable") because
 * fill() enforces an editability check before writing.
 *
 * pressSequentially() (real keydown/keyup events) and press() sidestep that
 * check entirely and work the same way a real user typing/selecting would,
 * regardless of whether the input is readonly — so we use those instead of
 * fill() for every combobox-style field, then verify the selection actually
 * registered afterward.
 */
const selectComboboxValue = async (
  page: import('@playwright/test').Page,
  locator: import('@playwright/test').Locator,
  value: string,
  label: string,
  attempts = 2
): Promise<void> => {
  if (!value) {
    return;
  }

  for (let attempt = 1; attempt <= attempts; attempt++) {
    await locator.waitFor({ state: 'visible', timeout: 30000 });
    await locator.click();

    // Clear any existing text via keyboard rather than fill().
    await locator.press('Control+A').catch(() => {});
    await locator.press('Backspace').catch(() => {});

    // Type the value with real key events — works even on readonly inputs.
    await locator.pressSequentially(value, { delay: 40 });

    console.log(`${label} Typed (attempt ${attempt}): ${value}`);

    // The listbox id is exposed via aria-controls once the dropdown opens.
    const listboxId = await locator.getAttribute('aria-controls').catch(() => null);
    const listbox = listboxId
      ? page.locator(`#${listboxId}`)
      : page.locator('[role="listbox"]:visible').first();

    const listboxAppeared = await listbox
      .waitFor({ state: 'visible', timeout: 30000 })
      .then(() => true)
      .catch(() => false);

    if (listboxAppeared) {
      const options = listbox.getByRole('option');

      // Prefer an exact match; fall back to a partial (contains) match;
      // fall back to the first available option as a last resort.
      let target = options.filter({ hasText: new RegExp(`^${escapeRegExp(value)}$`, 'i') });

      if ((await target.count()) === 0) {
        target = options.filter({ hasText: new RegExp(escapeRegExp(value), 'i') });
      }

      const optionToClick = (await target.count()) > 0 ? target.first() : options.first();

      await optionToClick.scrollIntoViewIfNeeded().catch(() => {});
      await optionToClick.click({ timeout: 5000 }).catch(async () => {
        // If the click didn't land, fall back to keyboard selection.
        await locator.press('ArrowDown');
        await locator.press('Enter');
      });
    } else {
      // No popup rendered — fall back to keyboard selection.
      await locator.press('ArrowDown');
      await locator.press('Enter');
      
    }

    // Give Salesforce a moment to commit the selection, then verify.
    await page.waitForTimeout(500);
    const currentValue = (await locator.inputValue().catch(() => '')).trim();

    if (currentValue.toLowerCase() === value.trim().toLowerCase()) {
      console.log(`${label} Selected and verified: ${value}`);
      return;
    }

    console.log(
      `${label} did not verify after attempt ${attempt} (found "${currentValue}", expected "${value}").`
    );
  }

  console.log(
    ` ${label} could not be confirmed as selected after ${attempts} attempt(s): ${value}. Continuing anyway.`
  );
};

const escapeRegExp = (str: string): string => str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const handleDuplicateContactPopup = async (
  page: import('@playwright/test').Page,
  contact: Record<string, string>
): Promise<boolean> => {
  const similarRecordsPopup = page.getByText(/Similar Records Exist/i);

  const popupVisible = await similarRecordsPopup
    .isVisible({ timeout: 3000 })
    .catch(() => false);

  if (!popupVisible) {
    return false;
  }

  console.log(
    `Similar Records Exist popup detected for ${contact['FirstName']} ${contact['LastName']}. Skipping duplicate.`
  );

  const closePopupButton = page.locator(
    'button[title="Close"], button[aria-label="Close"]'
  );

  const closeVisible = await closePopupButton
    .first()
    .isVisible()
    .catch(() => false);

  if (closeVisible) {
    await closePopupButton.first().click();
  }

  const cancelButton = page.getByRole('button', {
    name: /^Cancel$/i
  });

  if (await cancelButton.isVisible().catch(() => false)) {
    await cancelButton.click();
  }

  return true;
};

test('Create Contacts from CSV', async ({ page }) => {
  const accountName = 'MASONRY-CNCRT SANTO-N TWOPOUNDBAG CRGN D-I';

  const csvFilePath = path.resolve(
    process.cwd(),
    'test-data',
    'salesfrocedataauto2.csv'
  );

  console.log('CSV File Path:', csvFilePath);

  if (!fs.existsSync(csvFilePath)) {
    throw new Error(`CSV file not found: ${csvFilePath}`);
  }

  const contacts = await readCsvContacts(csvFilePath, accountName);

  console.log(`Contacts Found: ${contacts.length}`);

  if (contacts.length === 0) {
    throw new Error(`No contacts found for account: ${accountName}`);
  }

  // Hard limit: never create more contacts than the CSV has for this account.
  const maxContactsToCreate = contacts.length;
  let createdCount = 0;
const createdPerAccount = new Map<string, number>();

  // Open Contacts Object
 await page.goto(routes.contactList('filterName=__Recent'), {
    waitUntil: 'domcontentloaded'
  });
  console.log('Current URL:', page.url());

if (page.url().includes('login')) {
  throw new Error(
    'Salesforce session expired. Regenerate auth.json.'
  );
}

  console.log(' Contacts Page Opened');

  // Select All Contacts View
  const listViewDropdown = page.locator('button[title*="Select a List View"]');

  await listViewDropdown.waitFor({ state: 'visible', timeout: 30000 });
  await listViewDropdown.click();

  const allContacts = page.getByText('All Contacts', { exact: true });

  if (await allContacts.isVisible().catch(() => false)) {
    await allContacts.click();
  }

  for (const contact of contacts) {

    const currentAccount = contact['Account.Name']?.trim();
    const accountCreatedCount =
      createdPerAccount.get(currentAccount) || 0;

    // if (accountCreatedCount >= 2) {
    //   console.log(
    //     `Already created 2 contacts for account: ${currentAccount}. Skipping remaining rows.`
    //   );
    //   continue;
    // }
    // Stop immediately if we've already hit the limit for this account.
    // if (createdCount >= maxContactsToCreate) {
    //   console.log(
    //     `Reached limit of ${maxContactsToCreate} contact(s) for account "${accountName}". Stopping.`
    //   );
    //   break;
    // }

    console.log(
      `Creating Contact ${createdCount + 1}/${maxContactsToCreate}: ${contact['FirstName']} ${contact['LastName']}`
    );

    await page.goto(routes.contactList('filterName=__Recent'));

    await page.getByRole('button', {
      name: /^New$/i
    }).waitFor({
      state: 'visible'
    });

    const alreadyExists = await contactExists(page, contact);

    console.log(
  `Contact check result: ${contact['FirstName']} ${contact['LastName']} = ${alreadyExists}`
   );

    if (alreadyExists) {
    console.log(
    `Contact already exists under account. Skipping: ${contact['FirstName']} ${contact['LastName']}`
    );
    continue;
    }

    // Click New
    // contactExists already leaves the browser on Contact List
    const newButton = page.getByRole('button', { name: /^New$/i });

    await newButton.waitFor({ state: 'visible', timeout: 30000 });
    await newButton.click();

    await page.getByLabel('First Name').fill(
      contact['FirstName'] || ''
    );

    await page.getByLabel('Last Name').fill(
      contact['LastName'] || ''
    );

    // Account Name Lookup
    const accountLookup = page.locator('input[aria-label="Account Name"]');
    await selectComboboxValue(page, accountLookup, contact['Account.Name'] || '', 'Account');

    // Mailing Country
    const mailingCountry = page.locator('input[aria-label="Mailing Country"]');
    await selectComboboxValue(page, mailingCountry, contact['MailingCountry'] || '', 'Country');

    // Mailing Street
    const street = page.getByLabel('Mailing Street');

    if (await street.isVisible().catch(() => false)) {
      await street.fill(contact['MailingStreet'] || '');
    }

    // Mailing City
    const city = page.getByLabel('Mailing City');

    if (await city.isVisible().catch(() => false)) {
      await city.fill(contact['MailingCity'] || '');
    }
    // Mailing State
    const mailingState = page.locator('input[aria-label="Mailing State/Province"]');
    await selectComboboxValue(page, mailingState, contact['MailingState'] || '', 'State');

    // Mailing Postal Code
    const postalCode = page.getByLabel('Mailing Zip/Postal Code');

    if (await postalCode.isVisible().catch(() => false)) {
      await postalCode.fill(contact['MailingPostalCode'] || '');
    }

    // Save


console.log(
  `Save clicked for ${contact['FirstName']} ${contact['LastName']}`
);


// ===================================================
// NO DUPLICATE POPUP -> CONTACT CREATED SUCCESSFULLY
// ===================================================
// Save Contact
const saveButton = page.getByRole('button', {
  name: /^Save$/i
});

await saveButton.waitFor({
  state: 'visible',
  timeout: 30000
});

await saveButton.click();

const duplicateDetected = await handleDuplicateContactPopup(page, contact);

if (duplicateDetected) {
  console.log(
    `Duplicate contact skipped. Moving to next record.`
  );
  continue;
}

await expect(page)
  .toHaveURL(/\/lightning\/r\/Contact\//, {
    timeout: 30000
  })
  .catch(() => {});

createdCount++;

  createdPerAccount.set(
  currentAccount,
  accountCreatedCount + 1
);

console.log(
  `Contact Created: ${contact['FirstName']} ${contact['LastName']} | Account: ${currentAccount} | Account Count: ${accountCreatedCount + 1}/2`
);
console.log(
  `Contact Created (${createdCount}/${maxContactsToCreate}): ${contact['FirstName']} ${contact['LastName']}`
);
  }

  console.log(
    `Finished processing. Created/attempted ${createdCount} of ${maxContactsToCreate} contact(s) for account "${accountName}".`
  );
});