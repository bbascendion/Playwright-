import {
  test,
  expect,
  type Page,
  type FrameLocator
} from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { env } from '../../config/env';
import { getRandomAccountName } from '../../utils/account';

const ACCOUNT_NAME = getRandomAccountName();

async function getCommercialReportCount(
  page: Page
): Promise<number> {
  const reportStatus = page.getByRole('status', {
    name: 'Equifax Commercial Reports'
  });

  await expect(reportStatus).toBeVisible({
    timeout: 30000
  });

  const statusText =
    (await reportStatus.textContent())?.trim() || '';

  console.log(
    `Equifax Commercial Reports status: ${statusText}`
  );

  const countMatch = statusText.match(
    /(\d+)\s+items?/i
  );

  if (!countMatch) {
    throw new Error(
      `Unable to extract the report count from: "${statusText}"`
    );
  }

  return Number(countMatch[1]);
}

async function openCommercialReportsViewAll(
  page: Page
): Promise<void> {
  const commercialReportsLink = page
    .getByRole('link', {
      name: /Equifax Commercial Reports/i
    })
    .first();

  // Trigger Salesforce lazy loading
  for (let i = 0; i < 12; i++) {
    const isVisible = await commercialReportsLink
      .isVisible()
      .catch(() => false);

    if (isVisible) {
      break;
    }

    await page.keyboard.press('PageDown');
    await page.waitForTimeout(500);
  }

  await expect(commercialReportsLink).toBeVisible({
    timeout: 30000
  });

  await commercialReportsLink.scrollIntoViewIfNeeded();
  await commercialReportsLink.click();

  await page.waitForURL(
    '**/related/**/view',
    {
      timeout: 30000
    }
  );

  await expect(
    page.getByRole('heading', {
      name: /^Equifax Commercial Reports$/i
    })
  ).toBeVisible({
    timeout: 30000
  });

  console.log(
    'Equifax Commercial Reports View All opened'
  );
}

async function getReturnToAccountButton(
  frame: FrameLocator
) {
  return frame
    .getByRole('button', {
      name: /return to account detail/i
    })
    .or(
      frame.getByRole('link', {
        name: /return to account detail/i
      })
    )
    .first();
}
async function getConsumerReportCount(
  page: Page
): Promise<number> {
  const reportStatus = page.getByRole('status', {
    name: 'Equifax Consumer Reports'
  });

  await expect(reportStatus).toBeVisible({
    timeout: 30000
  });

  const statusText =
    (await reportStatus.textContent())?.trim() || '';

  console.log(
    `Equifax Consumer Reports status: ${statusText}`
  );

  const countMatch = statusText.match(
    /(\d+)\s+items?/i
  );

  if (!countMatch) {
    throw new Error(
      `Unable to extract Consumer Report count from: "${statusText}"`
    );
  }

  return Number(countMatch[1]);
}

async function openConsumerReportsViewAll(
  page: Page
): Promise<void> {
  const consumerReportsLink = page
    .getByRole('link', {
      name: /Equifax Consumer Reports/i
    })
    .first();

  // Trigger Salesforce lazy loading
  for (let i = 0; i < 12; i++) {
    const linkVisible = await consumerReportsLink
      .isVisible()
      .catch(() => false);

    if (linkVisible) {
      break;
    }

    await page.keyboard.press('PageDown');
    await page.waitForTimeout(500);
  }

  await expect(consumerReportsLink).toBeVisible({
    timeout: 30000
  });

  await consumerReportsLink.scrollIntoViewIfNeeded();
  await consumerReportsLink.click();

  await page.waitForURL(
    '**/related/**/view',
    {
      timeout: 30000
    }
  );

  await expect(
    page.getByRole('heading', {
      name: /^Equifax Consumer Reports$/i
    })
  ).toBeVisible({
    timeout: 30000
  });

  console.log(
    'Equifax Consumer Reports View All opened'
  );
}
test.describe(
  'Account - Credit Review Custom Buttons',
  () => {
    test.beforeEach(async ({ page }) => {
      test.setTimeout(240000);

      console.log('Navigating to:', env.baseUrl);

      await page.goto(env.baseUrl!, {
        waitUntil: 'domcontentloaded'
      });

      await page.waitForURL(
        '**/lightning/**',
        {
          timeout: 60000
        }
      );

      console.log(
        'Lightning URL loaded:',
        page.url()
      );

      const searchBox = page
        .getByRole('searchbox')
        .or(
          page.getByPlaceholder(/search/i)
        )
        .first();

      const searchBoxVisible = await searchBox
        .waitFor({
          state: 'visible',
          timeout: 20000
        })
        .then(() => true)
        .catch(() => false);

      if (!searchBoxVisible) {
        await page.screenshot({
          path: 'debug-search-box-not-found.png',
          fullPage: true
        });

        throw new Error(
          'Global search box was not visible.'
        );
      }

      console.log('Search box is visible');
      console.log(
        `Searching for account: ${ACCOUNT_NAME}`
      );

      await searchBox.click();
      await searchBox.fill(ACCOUNT_NAME);
      await page.keyboard.press('Enter');

      const accountResult = page.getByRole(
        'link',
        {
          name: `${ACCOUNT_NAME}`,
          exact: true
        }
      );

      await expect(accountResult).toBeVisible({
        timeout: 30000
      });

      console.log('Account found in list');

      await accountResult.click();

      await page.waitForURL(
        '**/lightning/r/Account/**/view',
        {
          timeout: 30000
        }
      );

      await expect(
        page.getByRole('heading', {
          name: new RegExp(
            `Account ${ACCOUNT_NAME}`,
            'i'
          )
        })
      ).toBeVisible({
        timeout: 30000
      });

      console.log(
        'Account record page loaded:',
        page.url()
      );

      const showMoreActionsButton =
        page.getByRole('button', {
          name: /show more actions/i
        });

      await expect(
        showMoreActionsButton
      ).toBeVisible({
        timeout: 30000
      });

      await showMoreActionsButton.click();

      console.log(
        'Show more actions button clicked'
      );
    });

    test(
      'Review Credit button is present and clickable',
      async ({ page }) => {
        const reviewCreditButton = page
          .getByRole('menuitem', {
            name: /^Review Credit$/i
          })
          .or(
            page.locator('a', {
              hasText: /^Review Credit$/i
            })
          )
          .first();

        await expect(
          reviewCreditButton
        ).toBeVisible({
          timeout: 15000
        });

        console.log(
          'Review Credit button found'
        );

        // Close the actions dropdown before
        // opening the related-list page.
        await page.keyboard.press('Escape');

        // Capture count before Review Credit.
        await openCommercialReportsViewAll(page);

        const reportCountBefore =
          await getCommercialReportCount(page);

        console.log(
          `Commercial reports before Review Credit: ${reportCountBefore}`
        );

        // Return to Account.
        await page.goBack({
          waitUntil: 'domcontentloaded'
        });

        await expect(
          page.getByRole('heading', {
            name: new RegExp(
              `Account ${ACCOUNT_NAME}`,
              'i'
            )
          })
        ).toBeVisible({
          timeout: 30000
        });

        // Reopen actions dropdown.
        const showMoreActionsButton =
          page.getByRole('button', {
            name: /show more actions/i
          });

        await expect(
          showMoreActionsButton
        ).toBeVisible({
          timeout: 30000
        });

        await showMoreActionsButton.click();

        const reviewCreditAction = page
          .getByRole('menuitem', {
            name: /^Review Credit$/i
          })
          .or(
            page.locator('a', {
              hasText: /^Review Credit$/i
            })
          )
          .first();

        await expect(
          reviewCreditAction
        ).toBeVisible({
          timeout: 15000
        });

        await reviewCreditAction.click();

        console.log(
          'Review Credit button clicked'
        );

        // Wait for the Review Credit iframe.
        const reviewIframe = page
          .locator(
            'iframe[name^="vfFrameId_"]'
          )
          .first();

        await expect(reviewIframe).toBeVisible({
          timeout: 30000
        });

        const frame =
          reviewIframe.contentFrame();

        // Click initial Go.
        const goButton = frame.getByRole(
          'button',
          {
            name: /^Go$/i
          }
        );

        await expect(goButton).toBeVisible({
          timeout: 30000
        });

        await goButton.click();

        console.log('Go button clicked');

        // Optional Consumer Credit Reports page.
        const consumerReportPage =
          frame.getByRole('heading', {
            name: /request consumer credit reports/i
          });

        const consumerPageDisplayed =
          await consumerReportPage
            .waitFor({
              state: 'visible',
              timeout: 10000
            })
            .then(() => true)
            .catch(() => false);

        if (consumerPageDisplayed) {
          console.log(
            'Request Consumer Credit Reports page detected'
          );

          const nameCells = frame.locator(
            'table tbody tr td:nth-child(2)'
          );

          const nameCellCount =
            await nameCells.count();

          let validNameCount = 0;

          for (
            let i = 0;
            i < nameCellCount;
            i++
          ) {
            const text = (
              await nameCells
                .nth(i)
                .textContent()
            )?.trim();

            if (
              text &&
              text.toUpperCase() !== 'NAME'
            ) {
              validNameCount++;
            }
          }

          console.log(
            `Consumer report names found: ${validNameCount}`
          );

          if (validNameCount === 0) {
            const cancelButton =
              frame.getByRole('button', {
                name: /^Cancel$/i
              });

            await expect(
              cancelButton
            ).toBeVisible({
              timeout: 10000
            });

            await cancelButton.click();

            await page.waitForURL(
              '**/lightning/r/Account/**/view',
              {
                timeout: 30000
              }
            );

            console.log(
              'No consumer names found. Cancel clicked.'
            );

            return;
          }

          const checkboxes = frame.locator(
            'input[type="checkbox"]'
          );

          const checkboxCount =
            await checkboxes.count();

          for (
            let i = 0;
            i < checkboxCount;
            i++
          ) {
            const checkbox =
              checkboxes.nth(i);

            const checkboxVisible =
              await checkbox
                .isVisible()
                .catch(() => false);

            const checkboxEnabled =
              await checkbox
                .isEnabled()
                .catch(() => false);

            if (
              checkboxVisible &&
              checkboxEnabled &&
              !(await checkbox.isChecked())
            ) {
              await checkbox.check();

              console.log(
                `Consumer checkbox ${i + 1} selected`
              );
            }
          }

          const consumerGoButton =
            frame.getByRole('button', {
              name: /^Go$/i
            });

          await expect(
            consumerGoButton
          ).toBeVisible({
            timeout: 10000
          });

          await consumerGoButton.click();

          console.log(
            'Consumer Credit Report Go button clicked'
          );
        }

        // Wait for Review Credit response.
        await expect(
          frame.getByRole('heading', {
            name: /credit review/i
          })
        ).toBeVisible({
          timeout: 60000
        });

        const errorMessage = frame
          .getByText(
            /error|exception|unable|failed|invalid/i
          )
          .first();

        const hasError = await errorMessage
          .waitFor({
            state: 'visible',
            timeout: 10000
          })
          .then(() => true)
          .catch(() => false);

        const returnButton =
          await getReturnToAccountButton(
            frame
          );

        await expect(returnButton).toBeVisible({
          timeout: 60000
        });

        if (hasError) {
          console.log(
            `Review Credit error: ${(
              await errorMessage.textContent()
            )?.trim() || 'Unknown error'
            }`
          );

          await returnButton
            .scrollIntoViewIfNeeded();

          await returnButton.click();

          await page.waitForURL(
            '**/lightning/r/Account/**/view',
            {
              timeout: 30000
            }
          );

          console.log(
            'Error detected. Returned to Account Detail. Report validation skipped.'
          );

          return;
        }

        console.log(
          'No error detected. Returning to Account Detail.'
        );

        await returnButton
          .scrollIntoViewIfNeeded();

        await returnButton.click();

        await page.waitForURL(
          '**/lightning/r/Account/**/view',
          {
            timeout: 30000
          }
        );

        await expect(
          page.getByRole('heading', {
            name: new RegExp(
              `Account ${ACCOUNT_NAME}`,
              'i'
            )
          })
        ).toBeVisible({
          timeout: 30000
        });

        // Open View All again after Review Credit.
        await openCommercialReportsViewAll(page);

        let reportCountAfter =
          reportCountBefore;

        await expect.poll(
          async () => {
            await page.reload({
              waitUntil: 'domcontentloaded'
            });

            reportCountAfter =
              await getCommercialReportCount(
                page
              );

            console.log(
              `Commercial reports: before=${reportCountBefore}, current=${reportCountAfter}`
            );

            return reportCountAfter;
          },
          {
            timeout: 180000,
            intervals: [
              5000,
              10000,
              15000
            ]
          }
        ).toBeGreaterThan(
          reportCountBefore
        );

        console.log(
          `New Commercial Report generated. Count changed from ${reportCountBefore} to ${reportCountAfter}.`
        );

        console.log(
          'Review Credit action completed successfully'
        );
      }
    );

    test(
      'Consumer Credit Review button is present and clickable',
      async ({ page }) => {
        /*
         * Step 1:
         * Close the action dropdown opened by beforeEach.
         */
        await page.keyboard.press('Escape');

        /*
         * Step 2:
         * Capture the Consumer Report count before requesting reports.
         */
        await openConsumerReportsViewAll(page);

        const consumerReportCountBefore =
          await getConsumerReportCount(page);

        console.log(
          `Consumer Reports before request: ${consumerReportCountBefore}`
        );

        /*
     * Step 3:
     * Return to the Account page.
     */
        await page.getByRole('link', {
          name: ACCOUNT_NAME
        }).click();

        await expect(
          page.getByRole('heading', {
            name: new RegExp(
              `Account ${ACCOUNT_NAME}`,
              'i'
            )
          })
        ).toBeVisible({
          timeout: 30000
        });

        console.log(
          'Returned to Account after capturing initial Consumer Report count'
        );

        /*
         * Step 4:
         * Open Show More Actions and click Consumer Credit Review.
         */
        const showMoreActionsButton =
          page.getByRole('button', {
            name: /show more actions/i
          });

        await expect(
          showMoreActionsButton
        ).toBeVisible({
          timeout: 30000
        });

        await showMoreActionsButton.click();

        console.log(
          'Show more actions button clicked'
        );

        const consumerCreditReviewButton = page
          .getByRole('menuitem', {
            name: /^Consumer Credit Review$/i
          })
          .or(
            page.locator('a', {
              hasText: /^Consumer Credit Review$/i
            })
          )
          .first();

        await expect(
          consumerCreditReviewButton
        ).toBeVisible({
          timeout: 15000
        });

        console.log(
          'Consumer Credit Review button found'
        );

        await consumerCreditReviewButton.click();

        console.log(
          'Consumer Credit Review button clicked'
        );


        /*
         * Step 5:
         * Wait for the Consumer Credit Review iframe.
         */
        const consumerFrame = page
          .locator(
            'iframe[name^="vfFrameId_"]'
          )
          .first();

        await expect(
          consumerFrame
        ).toBeVisible({
          timeout: 30000
        });

        const frame =
          consumerFrame.contentFrame();

        console.log(
          'Consumer Credit Review iframe loaded'
        );

        await expect(
          frame.getByRole('heading', {
            level: 1,
            name: /request consumer credit reports/i
          })
        ).toBeVisible({
          timeout: 30000
        });

        console.log(
          'Request Consumer Credit Reports page loaded'
        );

        /*
         * Step 6:
         * Select all available contact rows.
         *
         * Checkbox 0 is the header checkbox.
         * Checkboxes from index 1 are contact records.
         */
        const checkboxes =
          frame.getByRole('checkbox');

        const checkboxCount =
          await checkboxes.count();

        const availableContactCount =
          Math.max(checkboxCount - 1, 0);

        console.log(
          `Available Consumer contacts: ${availableContactCount}`
        );

        if (availableContactCount === 0) {
          throw new Error(
            'No Consumer contacts were available for report generation.'
          );
        }

        for (
          let i = 1;
          i < checkboxCount;
          i++
        ) {
          const contactCheckbox =
            checkboxes.nth(i);

          await expect(
            contactCheckbox
          ).toBeVisible({
            timeout: 10000
          });

          if (
            !(await contactCheckbox.isChecked())
          ) {
            await contactCheckbox.check({
              force: true
            });
          }

          await expect(
            contactCheckbox
          ).toBeChecked();
        }

        console.log(
          `${availableContactCount} Consumer contact(s) selected`
        );

        /*
         * Step 7:
         * Click Request Reports.
         */
        const requestReportsButton =
          frame.getByRole('button', {
            name: /request reports/i
          });

        await expect(
          requestReportsButton
        ).toBeVisible({
          timeout: 30000
        });

        await requestReportsButton.click();

        console.log(
          'Request Reports button clicked'
        );

        /*
         * Step 8:
         * Reacquire the iframe after the Visualforce page rerenders.
         */
        const updatedFrame = page
          .locator(
            'iframe[name^="vfFrameId_"]'
          )
          .first()
          .contentFrame();

        const doneButton =
          updatedFrame.getByRole('button', {
            name: /^Done$/i
          });

        await page.waitForTimeout(
          availableContactCount > 1
            ? 15000
            : 5000
        );
        console.log(
          'Consumer report processing completed'
        );
        await doneButton.scrollIntoViewIfNeeded();
        await doneButton.click();

        console.log(
          'Done button clicked'
        );

        /*
         * Step 9:
         * Confirm return to the Account page.
         */
        await page.waitForURL(
          '**/lightning/r/Account/**/view',
          {
            timeout: 30000
          }
        );

        await expect(
          page.getByRole('heading', {
            name: new RegExp(
              `Account ${ACCOUNT_NAME}`,
              'i'
            )
          })
        ).toBeVisible({
          timeout: 30000
        });

        console.log(
          'Returned to Account after Consumer Credit Review'
        );

        /*
         * Step 10:
         * Open Consumer Reports View All again.
         */
        await openConsumerReportsViewAll(page);

        const expectedConsumerReportCount =
          consumerReportCountBefore +
          availableContactCount;

        let consumerReportCountAfter =
          consumerReportCountBefore;

        /*
         * Step 11:
         * Refresh until one report per available contact is generated.
         * Maximum polling time is one minute.
         */
        await expect.poll(
          async () => {
            await page.reload({
              waitUntil: 'domcontentloaded'
            });

            consumerReportCountAfter =
              await getConsumerReportCount(page);

            console.log(
              `Consumer Reports: before=${consumerReportCountBefore}, current=${consumerReportCountAfter}, expected=${expectedConsumerReportCount}`
            );

            return consumerReportCountAfter;
          },
          {
            timeout: 60000,
            intervals: [
              5000,
              10000,
              15000
            ]
          }
        ).toBeGreaterThanOrEqual(
          expectedConsumerReportCount
        );

        /*
         * Step 12:
         * Capture the newest report ID.
         */
        const newestConsumerReport = page
          .getByRole('link', {
            name: /^EfxConsumer-\d+$/i
          })
          .first();

        await expect(
          newestConsumerReport
        ).toBeVisible({
          timeout: 30000
        });

        const newestConsumerReportId =
          (
            await newestConsumerReport.textContent()
          )?.trim();

        console.log(
          `Consumer Credit Review completed successfully. Count changed from ${consumerReportCountBefore} to ${consumerReportCountAfter}. Expected increase: ${availableContactCount}. Latest report: ${newestConsumerReportId}`
        );
      }
    );
  }
)
