import { test, expect } from '@playwright/test';
import { routes } from '../../config/routes';

test.use({
  storageState: 'auth.json'
});

test('Verify Duplicate Account Does Not Exist', async ({ page }) => {

  const accountName = 'WEAVNG';

  await page.goto(routes.accountList('filterName=__Recent'));

  // Wait for page load
  await page.waitForLoadState('domcontentloaded');

  console.log('Accounts Page Opened');

  // Click List View Dropdown Arrow
  await page.locator(
    'button[title*="Select a List View"]'
  ).click();

  console.log('List View Dropdown Opened');

  // Select All Accounts
  await page.getByText(
    'All Accounts',
    { exact: true }
  ).click();

  console.log('All Accounts Selected');

  // Allow Account List Refresh
    await page.waitForLoadState('domcontentloaded');

  // Search This List
  const searchBox = page.locator(
    'input[placeholder="Search this list..."]'
  );

  await searchBox.waitFor({
    state: 'visible',
    timeout: 30000
  });

  await searchBox.fill(accountName);

  console.log(
    `Searching Account: ${accountName}`
  );

  // Wait for search results
  await page.waitForTimeout(3000);

  // Find account links in grid
  const matchingAccounts = page.getByRole('link', {
    name: accountName,
    exact: true
  });

  const count = await matchingAccounts.count();

  console.log(
    `Matching Account Count: ${count}`
  );

  // Negative Validation
  expect(count).toBe(0);

  console.log(
    'Duplicate Account Not Found'
  );
});