import {
  test,
  expect,
  Page,
  FrameLocator,
  Locator,
  TestInfo,
} from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { env } from '../../config/env';
import { captureScreenshot } from '../../utils/captureScreenshot';

/* ------------------------------------------------------------------ */
/* Config / small utilities                                            */
/* ------------------------------------------------------------------ */
/*
 * Optional environment variables:
 *   REPORT_RENDER_WAIT_MS            final paint buffer for reports (default 300)
 *   COMMERCIAL_REPORT_RENDER_WAIT_MS final paint buffer for commercial reports (default 500)
 *   REPORT_PDF_WAIT_MS               extra wait while a Commercial PDF report is pulled (default 800)
 *   SUBSCRIBER_LOGIN_USERNAME        pick a specific subscriber Login link
 *   ACCOUNT_POOL_SIZE                limit the random pool to the N newest eligible accounts
 *   FORCE_ACCOUNT_CREATION=true      skip the random pick and always create an Account from CSV
 *   ACCOUNT_RECORD_TYPE              record type label to choose if the New Account
 *                                    record-type picker is shown (otherwise the default is used)
 *
 * Consumer HIT / NO-HIT rules enforced by this test:
 *   - Only HIT contacts produce a Consumer report. Example: 3 contacts, 2 HIT + 1 NO-HIT
 *     -> exactly 2 new reports are expected and only those 2 are opened / screenshotted.
 *   - A NO-HIT contact must never have a new report.
 *   - If EVERY selected contact is NO-HIT (e.g. the account has a single NO-HIT contact),
 *     the test verifies the NO-HIT result (no new report) and then ENDS. No further steps run.
 */

const REPORT_RENDER_WAIT_MS =
  Number(process.env.REPORT_RENDER_WAIT_MS) || 300;

const COMMERCIAL_REPORT_RENDER_WAIT_MS =
  Number(process.env.COMMERCIAL_REPORT_RENDER_WAIT_MS) || 500;

// Small render buffer after the PDF viewer becomes available.
const PDF_PULL_WAIT_MS =
  Number(process.env.REPORT_PDF_WAIT_MS) || 800;

/*
 * TESTING ONLY: put an Account name here to run the test against that exact Account.
 * Leave it as '' for the normal run (random Account from the list / created from CSV).
 * The env var TEST_ACCOUNT_NAME overrides this value when set.
 */
const HARDCODED_ACCOUNT_NAME = 'KOSIA\'S MENEGMENT NEURODEVELOPMENTAL'; // <-- change me, or set to '' for the normal run

const TEST_ACCOUNT_NAME = (
  process.env.TEST_ACCOUNT_NAME ?? HARDCODED_ACCOUNT_NAME
).trim();

const ACCOUNT_VIEW_URL = '**/lightning/r/Account/**/view';
const VF_FRAME = 'iframe[name^="vfFrameId_"]';

// CSV files live in <project root>/test-data. Lookup is case-insensitive,
// so ".CSV" vs ".csv" does not matter on Linux/CI.
const ACCOUNT_CSV = 'salesfrocedataauto.csv';
const CONTACT_CSV = 'salesfrocedataauto2.csv';

// Column headers of salesfrocedataauto.csv (Account creation data).
const ACCT_COL = {
  name: 'forseva1__Account__r.Name',
  street: 'forseva1__Address1__c',
  city: 'forseva1__Account__r.BillingCity',
  state: 'forseva1__Account__r.BillingState',
  zip: 'forseva1__Account__r.BillingPostalCode',
  country: 'forseva1__Account__r.BillingCountry',
  phone: 'forseva1__Phone__c',
} as const;

type ReportType = 'Consumer' | 'Commercial';

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

const isVisible = (locator: Locator) =>
  locator.isVisible().catch(() => false);

/** Resolves with the key of the first condition that succeeds, or null if all fail. */
function waitForOutcome<K extends string>(
  conditions: Record<K, () => Promise<unknown>>
): Promise<K | null> {
  const entries = Object.entries(conditions) as [K, () => Promise<unknown>][];
  return new Promise((resolve) => {
    let pending = entries.length;
    for (const [key, run] of entries) {
      run()
        .then(() => resolve(key))
        .catch(() => {
          if (--pending === 0) resolve(null);
        });
    }
  });
}

const PROCESSING_TEXT = /Processing\s+Please\s+Wait/i;
const PDF_VIEWER_SELECTOR =
  'iframe[src*=".pdf" i], iframe[src*="pdf" i], embed[type="application/pdf"], object[type="application/pdf"], canvas';

/** "Processing Please Wait.." can be shown by the page itself or by a Visualforce iframe. */
async function isProcessingVisible(page: Page): Promise<boolean> {
  for (const frame of page.frames()) {
    const visible = await frame
      .getByText(PROCESSING_TEXT)
      .first()
      .isVisible()
      .catch(() => false);
    if (visible) return true;
  }
  return false;
}

async function isPdfViewerVisible(page: Page): Promise<boolean> {
  for (const frame of page.frames()) {
    const viewer = frame.locator(PDF_VIEWER_SELECTOR).first();
    if (await viewer.isVisible().catch(() => false)) return true;
  }
  return false;
}

/** Waits until "Processing Please Wait.." is gone and stays gone for two consecutive checks. */
async function waitForProcessingToClear(
  page: Page,
  timeout = 30000
): Promise<void> {
  let clearChecks = 0;

  await expect
    .poll(
      async () => {
        const processingVisible = await isProcessingVisible(page);
        clearChecks = processingVisible ? 0 : clearChecks + 1;
        return clearChecks >= 2;
      },
      {
        timeout,
        intervals: [250, 500],
      }
    )
    .toBe(true);

  console.log('Processing message cleared successfully.');
}

/**
 * Waits for spinners and the "Processing Please Wait.." message to disappear.
 * For PDF reports it also waits for the viewer, then gives the PDF extra time to render.
 */
async function waitForReportToFinishLoading(
  page: Page,
  settleMs: number = REPORT_RENDER_WAIT_MS,
  expectPdf = false
): Promise<void> {
  console.log('Waiting for report/PDF content to finish loading...');

  const spinners = page.locator(
    'lightning-spinner, .slds-spinner, .slds-spinner_container, [role="progressbar"]'
  );
  try {
    await expect
      .poll(
        () =>
          spinners.evaluateAll((els) =>
            (els as HTMLElement[]).every((el) => el.offsetParent === null)
          ),
        { timeout: 5000, intervals: [250, 500] }
      )
      .toBe(true);
  } catch {
    console.log('Spinner still present after 5s, continuing.');
  }

  await waitForProcessingToClear(page);

  if (expectPdf) {
    const pdfFound = await expect
      .poll(() => isPdfViewerVisible(page), {
        timeout: 8000,
        intervals: [250, 500, 1000],
      })
      .toBe(true)
      .then(() => true)
      .catch(() => false);

    if (!pdfFound) console.log('PDF viewer did not become visible in 8s.');

    console.log(`Waiting ${PDF_PULL_WAIT_MS}ms for the PDF report to render...`);
    await page.waitForTimeout(PDF_PULL_WAIT_MS);

    // The processing message can reappear while the PDF is being pulled.
    await waitForProcessingToClear(page);
  }

  await page.waitForTimeout(settleMs);
}

/* ------------------------------------------------------------------ */
/* CSV helpers (parsed once, cached)                                   */
/* ------------------------------------------------------------------ */

/** RFC-4180 style parser: handles quoted fields, escaped quotes and line breaks inside quotes. */
function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let current = '';
  let inQuotes = false;

  const input = text.replace(/^\uFEFF/, '');

  for (let i = 0; i < input.length; i++) {
    const char = input[i];

    if (inQuotes) {
      if (char === '"') {
        if (input[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        current += char;
      }
      continue;
    }

    if (char === '"') {
      inQuotes = true;
    } else if (char === ',') {
      row.push(current.trim());
      current = '';
    } else if (char === '\n' || char === '\r') {
      if (char === '\r' && input[i + 1] === '\n') i++;
      row.push(current.trim());
      current = '';
      if (row.some((cell) => cell !== '')) rows.push(row);
      row = [];
    } else {
      current += char;
    }
  }

  row.push(current.trim());
  if (row.some((cell) => cell !== '')) rows.push(row);

  return rows;
}

type CsvRow = Record<string, string>;
const csvCache = new Map<string, CsvRow[]>();

function resolveCsvPath(fileName: string): string | null {
  const dir = path.resolve(process.cwd(), 'test-data');
  const exact = path.join(dir, fileName);
  if (fs.existsSync(exact)) return exact;

  if (!fs.existsSync(dir)) return null;
  const match = fs
    .readdirSync(dir)
    .find((file) => file.toLowerCase() === fileName.toLowerCase());
  return match ? path.join(dir, match) : null;
}

function readCsv(fileName: string, label: string): CsvRow[] {
  const cacheKey = fileName.toLowerCase();
  const cached = csvCache.get(cacheKey);
  if (cached) return cached;

  const csvPath = resolveCsvPath(fileName);
  if (!csvPath) {
    throw new Error(
      `${label} CSV file not found: ${path.resolve(process.cwd(), 'test-data', fileName)}`
    );
  }

  const table = parseCsv(fs.readFileSync(csvPath, 'utf8'));
  if (table.length < 2) {
    throw new Error(`${fileName} contains no ${label} rows.`);
  }

  const headers = table[0];
  const rows = table.slice(1).map((values) => {
    const row: CsvRow = {};
    headers.forEach((header, index) => {
      row[header] = values[index]?.trim() ?? '';
    });
    return row;
  });

  csvCache.set(cacheKey, rows);
  return rows;
}

type ContactCsvRecord = CsvRow;
type AccountCsvRecord = CsvRow;

const normalizeKey = (value: string | undefined) =>
  (value || '').trim().toLowerCase();

function readContactsForAccount(accountName: string): ContactCsvRecord[] {
  const contacts = readCsv(CONTACT_CSV, 'Contact').filter(
    (contact) => normalizeKey(contact['Account.Name']) === normalizeKey(accountName)
  );

  console.log(
    `Contact CSV rows found for "${accountName}": ${contacts.length}`
  );

  return contacts;
}

/** Account rows from salesfrocedataauto.csv, de-duplicated by Account name. */
function readAccountCsvRows(): AccountCsvRecord[] {
  const seen = new Set<string>();
  const rows: AccountCsvRecord[] = [];

  for (const row of readCsv(ACCOUNT_CSV, 'Account')) {
    const key = normalizeKey(row[ACCT_COL.name]);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    rows.push(row);
  }

  return rows;
}

/** Lower-cased names of every Account that has at least one Contact row in the contact CSV. */
function getMappedAccountNames(): Set<string> {
  return new Set(
    readCsv(CONTACT_CSV, 'Contact')
      .map((contact) => normalizeKey(contact['Account.Name']))
      .filter((name): name is string => Boolean(name))
  );
}

function shuffle<T>(items: T[]): T[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

/* ------------------------------------------------------------------ */
/* Shared page helpers                                                 */
/* ------------------------------------------------------------------ */

function accountHeading(page: Page, accountName: string): Locator {
  return page.getByRole('heading', {
    name: new RegExp(
      `^(?:Account\\s+)?${escapeRegExp(accountName)}$`,
      'i'
    ),
  });
}

async function waitForAccountPage(
  page: Page,
  accountName: string,
  timeout = 30000
): Promise<void> {
  await expect(accountHeading(page, accountName)).toBeVisible({ timeout });
}

/** From a related-list page, click the Account breadcrumb link and wait for the record. */
async function returnToAccount(
  page: Page,
  accountName: string
): Promise<void> {
  const link = page
    .getByRole('link', { name: accountName, exact: true })
    .first();

  await expect(link).toBeVisible({ timeout: 30000 });
  await link.click();
  await waitForAccountPage(page, accountName);
}

/** Click an Account action that may be a visible button or inside "Show more actions". */
async function clickAccountAction(
  page: Page,
  name: RegExp
): Promise<void> {
  // First check whether Salesforce exposes the action directly.
  const directButton = page
    .getByRole('button', { name })
    .filter({ visible: true })
    .first();

  if (await isVisible(directButton)) {
    await directButton.click();
    return;
  }

  const directLink = page
    .getByRole('link', { name })
    .filter({ visible: true })
    .first();

  if (await isVisible(directLink)) {
    await directLink.click();
    return;
  }

  // Action isn't directly visible: open "Show more actions".
  const showMore = page
    .getByRole('button', { name: /show more actions/i })
    .first();

  await expect(showMore).toBeVisible({ timeout: 30000 });
  await showMore.click();

  const menuAction = page
    .getByRole('menuitem', { name })
    .filter({ visible: true })
    .first();

  await expect(menuAction).toBeVisible({ timeout: 15000 });
  await menuAction.click();
}

function getVfFrame(page: Page): { element: Locator; frame: FrameLocator } {
  const element = page.locator(`${VF_FRAME}:visible`).last();
  return { element, frame: element.contentFrame() };
}

/* ------------------------------------------------------------------ */
/* Login                                                               */
/* ------------------------------------------------------------------ */

async function isSubscriberAccountPage(page: Page): Promise<boolean> {
  return /\/lightning\/(r|o)\/Account\//i.test(page.url());
}

async function loginToSalesforce(
  page: Page,
  testInfo: TestInfo
): Promise<Page> {
  console.log('Navigating to LMA...');

  await page.goto(env.baseUrl!, { waitUntil: 'domcontentloaded' });

  // Already inside the subscriber org - skip the complete LMA flow.
  if (await isSubscriberAccountPage(page)) {
    console.log('Subscriber org session already available.');
    return page;
  }

  const usernameField = page.locator('#username');

  if (await isVisible(usernameField)) {
    await usernameField.fill(env.username!);
    await page.locator('#Login').click();

    const passwordField = page.locator('#password');
    await expect(passwordField).toBeVisible({ timeout: 60000 });
    await passwordField.fill(env.password!);
    await page.locator('#Login').click();

    console.log('LMA login submitted.');

    const mfaVerificationPage = page.locator(
      'input[name="verificationCode"], input[name="otp"], button:has-text("Verify"), text=/Verify your identity/i'
    );

    if (
      await mfaVerificationPage
        .first()
        .isVisible({ timeout: 15000 })
        .catch(() => false)
    ) {
      console.log(
        'MFA verification page detected. Complete the verification code in the browser to continue.'
      );
      await page.waitForURL(
        (url) => !url.toString().includes('/_ui/identity/verification/'),
        { timeout: 180000 }
      );
      console.log('MFA verification completed.');
    }
  } else {
    console.log('Existing LMA session detected.');
  }

  // LMA opens in Salesforce Classic - do not wait for a /lightning/ URL here.
  const subscribersTab = page.getByRole('link', { name: /^Subscribers$/i });
  await expect(subscribersTab).toBeVisible({ timeout: 90000 });
  await subscribersTab.click();
  console.log('Subscribers tab opened.');

  await expect(
    page.getByText('Subscriber Organizations', { exact: true })
  ).toBeVisible({ timeout: 30000 });

  // First textbox = global search; last = Subscriber list search.
  const textboxes = page.getByRole('textbox');
  await expect
    .poll(() => textboxes.count(), { timeout: 30000, intervals: [250, 500] })
    .toBeGreaterThanOrEqual(2);

  const subscriberSearch = textboxes.last();
  await expect(subscriberSearch).toBeVisible({ timeout: 30000 });
  await subscriberSearch.fill(env.subscriberOrgId!);
  await subscriberSearch.press('Enter');
  console.log(`Subscriber Org searched: ${env.subscriberOrgId}`);

  const ascendionLink = page.getByRole('link', {
    name: /^Ascendion Engineering Private Limited$/i,
  });
  await expect(ascendionLink).toBeVisible({ timeout: 30000 });
  await captureScreenshot(page, testInfo, 'org-subscribers');

  const [overviewPage] = await Promise.all([
    page.context().waitForEvent('page'),
    ascendionLink.click(),
  ]);
  await overviewPage.waitForLoadState('domcontentloaded');
  console.log('Overview URL:', overviewPage.url());

  await expect(overviewPage.locator('body')).toContainText(
    'Login Access Granted',
    { timeout: 30000 }
  );
  console.log('Ascendion Subscriber Overview opened.');

  // Pick the Login link for the intended subscriber username (if provided).
  const subscriberLoginUsername = process.env.SUBSCRIBER_LOGIN_USERNAME;
  let loginLink: Locator;

  if (subscriberLoginUsername) {
    const loginRow = overviewPage
      .getByRole('row')
      .filter({ hasText: subscriberLoginUsername });

    await expect(loginRow).toBeVisible({ timeout: 30000 });
    loginLink = loginRow.getByRole('link', { name: /^Login$/i });
  } else {
    const loginLinks = overviewPage.getByRole('link', { name: /^Login$/i });
    const count = await loginLinks.count();
    console.log(`Subscriber Login links found: ${count}`);

    if (count === 0) {
      throw new Error('No subscriber Login link was found.');
    }
    loginLink = loginLinks.first();
  }

  await expect(loginLink).toBeVisible({ timeout: 30000 });

  // Subscriber Login may open a new page or reuse the same one.
  const context = overviewPage.context();
  const pagesBeforeLogin = context.pages();
  const overviewUrlBeforeLogin = overviewPage.url();

  const outcome = waitForOutcome({
    newPage: () => context.waitForEvent('page', { timeout: 30000 }),
    sameTab: () =>
      overviewPage.waitForURL((url) => url.toString() !== overviewUrlBeforeLogin, {
        timeout: 30000,
      }),
  });

  await loginLink.click();
  await outcome;

  const subscriberPage =
    context.pages().find((candidate) => !pagesBeforeLogin.includes(candidate)) ||
    overviewPage;

  await subscriberPage.waitForLoadState('domcontentloaded');
  console.log('Subscriber URL after Login:', subscriberPage.url());

  // Subscriber login may open Classic - go straight to Lightning Accounts.
  const subscriberOrigin = new URL(subscriberPage.url()).origin;

  await subscriberPage.goto(
    `${subscriberOrigin}/lightning/o/Account/list?filterName=__Recent`,
    { waitUntil: 'domcontentloaded' }
  );

  await subscriberPage.waitForURL('**/lightning/o/Account/**', {
    timeout: 90000,
  });

  await expect(
    subscriberPage.getByRole('link', { name: /^Accounts$/i })
  ).toBeVisible({ timeout: 60000 });

  console.log('Subscriber Lightning Accounts page loaded:', subscriberPage.url());

  return subscriberPage;
}

/* ------------------------------------------------------------------ */
/* Generic form helpers                                                */
/* ------------------------------------------------------------------ */

async function selectComboboxValue(
  page: Page,
  input: Locator,
  value: string,
  label: string
): Promise<void> {
  if (!value) return;

  await expect(input).toBeVisible({ timeout: 30000 });
  await input.click();

  await input.press('Control+A').catch(() => undefined);
  await input.press('Backspace').catch(() => undefined);
  await input.pressSequentially(value, { delay: 10 });

  const listboxId = await input.getAttribute('aria-controls').catch(() => null);

  const listbox = listboxId
    ? page.locator(`#${listboxId}`)
    : page.locator('[role="listbox"]:visible').first();

  await expect(listbox).toBeVisible({ timeout: 15000 });

  const options = listbox.getByRole('option');
  const exactOption = options.filter({
    hasText: new RegExp(`^${escapeRegExp(value)}$`, 'i'),
  });

  const optionToSelect =
    (await exactOption.count()) > 0
      ? exactOption.first()
      : options
          .filter({ hasText: new RegExp(escapeRegExp(value), 'i') })
          .first();

  await expect(optionToSelect).toBeVisible({ timeout: 10000 });
  await optionToSelect.click();

  console.log(`${label} selected: ${value}`);
}

async function fillTextbox(
  dialog: Locator,
  name: RegExp,
  value: string,
  optional = false
): Promise<void> {
  if (!value) return;

  const field = dialog.getByRole('textbox', { name }).first();

  if (optional && !(await isVisible(field))) return;

  await field.fill(value, { timeout: 30000 });
}

/** Address picklists are comboboxes when State/Country picklists are enabled, plain textboxes otherwise. */
async function fillComboboxOrTextbox(
  page: Page,
  dialog: Locator,
  name: RegExp,
  value: string,
  label: string
): Promise<void> {
  if (!value) return;

  const combobox = dialog.getByRole('combobox', { name }).first();

  if (await isVisible(combobox)) {
    await selectComboboxValue(page, combobox, value, label);
  } else {
    await fillTextbox(dialog, name, value);
    console.log(`${label} entered: ${value}`);
  }
}

function normalizeCountry(country: string): string {
  const key = country.trim().toLowerCase().replace(/\./g, '');
  if (['us', 'usa', 'united states of america'].includes(key)) {
    return 'United States';
  }
  if (['uk', 'gb'].includes(key)) return 'United Kingdom';
  return country.trim();
}

async function cancelDialog(dialog: Locator, what: string): Promise<void> {
  const cancelButton = dialog.getByRole('button', { name: /^Cancel$/i }).first();

  if (await isVisible(cancelButton)) {
    await cancelButton.click();
    await expect(dialog).toBeHidden({ timeout: 30000 });
    return;
  }

  throw new Error(
    `Salesforce flagged the ${what} as a possible duplicate, but the dialog has no visible Cancel button.`
  );
}

/* ------------------------------------------------------------------ */
/* Accounts                                                            */
/* ------------------------------------------------------------------ */

function getAccountGrid(page: Page): Locator {
  return page
    .getByRole('grid', { name: /All Accounts/i })
    .filter({ visible: true })
    .last();
}

/** Makes sure the given grid is sorted by Created Date, newest first. */
async function sortByCreatedDateDescending(grid: Locator): Promise<void> {
  const sortTarget = grid
    .getByRole('button', { name: /Sort by:\s*Created Date/i })
    .last();
  await expect(sortTarget).toBeVisible({ timeout: 30000 });

  const createdDateHeader = sortTarget.locator(
    'xpath=ancestor::*[@role="columnheader"][1]'
  );
  const getSortState = async (): Promise<string> => {
    const [ariaSort, headerText] = await Promise.all([
      createdDateHeader.getAttribute('aria-sort').catch(() => null),
      createdDateHeader.innerText().catch(() => ''),
    ]);
    return `${ariaSort || ''} ${headerText}`.toLowerCase();
  };

  let sortState = await getSortState();
  for (
    let attempt = 0;
    attempt < 2 && !/descending/.test(sortState);
    attempt++
  ) {
    await sortTarget.click();
    await expect
      .poll(getSortState, { timeout: 10000, intervals: [250, 500] })
      .toMatch(/descending|ascending/);
    sortState = await getSortState();
  }

  await expect
    .poll(getSortState, { timeout: 10000, intervals: [250, 500] })
    .toMatch(/descending/);
}

/**
 * Selects the "All Accounts" list view and sorts it by Created Date descending.
 * Returns false when the list view has no rows (so the caller can create an Account).
 */
async function waitForAccountsList(page: Page): Promise<boolean> {
  console.log('Waiting for Accounts list to load...');

  const listViewToggle = page
    .locator('button[title*="Select a List View"]')
    .or(page.getByRole('button', { name: /all accounts|list view/i }))
    .first();

  await expect(listViewToggle).toBeVisible({ timeout: 30000 });
  await listViewToggle.click();

  const allAccountsView = page.getByText('All Accounts', { exact: true }).last();
  const allAccountsViewVisible = await allAccountsView
    .waitFor({ state: 'visible', timeout: 15000 })
    .then(() => true)
    .catch(() => false);

  if (!allAccountsViewVisible) {
    throw new Error(
      'The All Accounts list view option was not available in the Accounts list.'
    );
  }

  await allAccountsView.click();
  console.log('All Accounts list view selected.');

  const accountGrid = getAccountGrid(page);
  await expect(accountGrid).toBeVisible({ timeout: 30000 });

  const hasRows = await accountGrid
    .getByRole('rowheader')
    .getByRole('link')
    .first()
    .waitFor({ state: 'visible', timeout: 15000 })
    .then(() => true)
    .catch(() => false);

  if (!hasRows) {
    console.log('The All Accounts list view has no rows.');
    return false;
  }

  await sortByCreatedDateDescending(accountGrid);
  console.log('Accounts sorted by Created Date descending.');
  return true;
}

/**
 * Creates an Account from one salesfrocedataauto.csv row.
 * Returns 'created' or 'duplicate' (Salesforce reported a similar record; nothing was saved).
 */
async function createAccountFromCsv(
  page: Page,
  account: AccountCsvRecord
): Promise<'created' | 'duplicate'> {
  const accountName = account[ACCT_COL.name]?.trim() || '';
  if (!accountName) {
    throw new Error('Account Name is missing in the Account CSV row.');
  }

  console.log(`Creating Account from CSV: ${accountName}`);

  const newButton = page
    .getByRole('button', { name: /^New$/i })
    .or(page.getByRole('link', { name: /^New$/i }))
    .first();
  await expect(newButton).toBeVisible({ timeout: 30000 });
  await newButton.click();

  const dialog = page.getByRole('dialog', { name: /^New Account/i }).first();
  const nameField = dialog
    .getByRole('textbox', { name: /^\*?\s*Account Name$/i })
    .first();
  const nextButton = dialog.getByRole('button', { name: /^Next$/i }).first();

  // Some orgs show a record-type picker first, others open the form directly.
  const firstScreen = await waitForOutcome({
    form: () => nameField.waitFor({ state: 'visible', timeout: 30000 }),
    recordType: () => nextButton.waitFor({ state: 'visible', timeout: 30000 }),
  });

  if (firstScreen === 'recordType') {
    const recordType = process.env.ACCOUNT_RECORD_TYPE;
    if (recordType) {
      await dialog
        .getByRole('radio', { name: new RegExp(escapeRegExp(recordType), 'i') })
        .first()
        .check({ force: true });
    }
    await nextButton.click();
  } else if (firstScreen === null) {
    throw new Error('The New Account form did not open.');
  }

  await expect(nameField).toBeVisible({ timeout: 30000 });
  await nameField.fill(accountName);
  console.log(`Account Name entered: ${accountName}`);

  await fillTextbox(
    dialog,
    /^\*?\s*Phone$/i,
    account[ACCT_COL.phone]?.trim() || '',
    true
  );

  // Country first: the State picklist depends on it.
  await fillComboboxOrTextbox(
    page,
    dialog,
    /^Billing Country$/i,
    normalizeCountry(account[ACCT_COL.country] || ''),
    'Billing Country'
  );
  await fillTextbox(
    dialog,
    /^Billing Street$/i,
    account[ACCT_COL.street]?.trim() || ''
  );
  await fillTextbox(
    dialog,
    /^Billing City$/i,
    account[ACCT_COL.city]?.trim() || ''
  );
  await fillComboboxOrTextbox(
    page,
    dialog,
    /^Billing State\/Province$/i,
    account[ACCT_COL.state]?.trim() || '',
    'Billing State/Province'
  );
  await fillTextbox(
    dialog,
    /^Billing Zip\/Postal Code$/i,
    account[ACCT_COL.zip]?.trim() || ''
  );

  const saveButton = dialog.getByRole('button', { name: /^Save$/i }).first();
  await expect(saveButton).toBeEnabled({ timeout: 30000 });
  await saveButton.click();
  console.log(`Save clicked for Account: ${accountName}`);

  const duplicateWarning = page
    .getByText(/Similar Records Exist|This record looks like an existing record/i)
    .first();
  const errorBanner = dialog
    .getByText(
      /Review the errors on this page|Review the following fields|We hit a snag/i
    )
    .first();

  const saveOutcome = await waitForOutcome({
    duplicate: () =>
      duplicateWarning.waitFor({ state: 'visible', timeout: 60000 }),
    error: () => errorBanner.waitFor({ state: 'visible', timeout: 60000 }),
    saved: () => dialog.waitFor({ state: 'hidden', timeout: 60000 }),
  });

  if (saveOutcome === 'duplicate') {
    console.log(
      `Salesforce found a possible existing Account. Skipping: ${accountName}`
    );
    await cancelDialog(dialog, 'Account');
    return 'duplicate';
  }

  if (saveOutcome !== 'saved') {
    const dialogText = (await dialog.innerText().catch(() => ''))
      .replace(/\s+/g, ' ')
      .trim();
    throw new Error(
      `Salesforce did not save Account "${accountName}". Form: ${dialogText.slice(0, 800) || 'no form details available'}`
    );
  }

  // Saving a new Account lands on its record page.
  await page.waitForURL(ACCOUNT_VIEW_URL, { timeout: 60000 });
  await waitForAccountPage(page, accountName, 60000);
  console.log(`Account created: ${accountName}`);
  return 'created';
}

interface PreparedAccount {
  accountName: string;
  accountUrl: string;
  created: boolean;
}

/**
 * TESTING: opens a specific Account by name from the All Accounts list
 * (uses "Search this list..." when it is not in the loaded rows).
 * Returns null when the Account cannot be found.
 */
async function openAccountByName(
  page: Page,
  accountName: string
): Promise<PreparedAccount | null> {
  const findLink = () =>
    getAccountGrid(page)
      .getByRole('rowheader')
      .getByRole('link', { name: accountName, exact: true })
      .first();

  if (!(await isVisible(findLink()))) {
    const search = page
      .getByRole('searchbox', { name: /search this list/i })
      .or(page.getByPlaceholder(/search this list/i))
      .first();

    if (await isVisible(search)) {
      await search.fill(accountName);
      await search.press('Enter');
      await page.waitForTimeout(1500);
    }
  }

  const link = findLink();
  const found = await link
    .waitFor({ state: 'visible', timeout: 15000 })
    .then(() => true)
    .catch(() => false);

  if (!found) return null;

  await link.click();
  await waitForAccountPage(page, accountName);
  console.log(`Hardcoded test Account opened: ${accountName}`);

  return { accountName, accountUrl: page.url(), created: false };
}

/**
 * Pick a random Account from the Accounts list view (no searching).
 * If no usable Account exists, create one from salesfrocedataauto.csv.
 * Contacts are handled afterwards by createContactsForAccount.
 */
async function prepareAccount(
  page: Page,
  testInfo: TestInfo
): Promise<PreparedAccount> {
  const forceCreate = /^(1|true|yes)$/i.test(
    process.env.FORCE_ACCOUNT_CREATION || ''
  );

  const hasRows = await waitForAccountsList(page);
  await captureScreenshot(page, testInfo, 'login-successful');

  // TESTING: run against a specific Account instead of a random one.
  if (TEST_ACCOUNT_NAME && TEST_ACCOUNT_NAME !== 'Your Account Name Here') {
    console.log(`TEST_ACCOUNT_NAME is set: using "${TEST_ACCOUNT_NAME}"`);

    const opened = await openAccountByName(page, TEST_ACCOUNT_NAME);
    if (opened) return opened;

    // Not in the org yet: create it if it exists in the Account CSV.
    const csvRow = readAccountCsvRows().find(
      (row) => normalizeKey(row[ACCT_COL.name]) === normalizeKey(TEST_ACCOUNT_NAME)
    );

    if (!csvRow) {
      throw new Error(
        `Test Account "${TEST_ACCOUNT_NAME}" was not found in Salesforce and has no row in ${ACCOUNT_CSV}.`
      );
    }

    console.log(`"${TEST_ACCOUNT_NAME}" not found in Salesforce. Creating it from CSV.`);
    const result = await createAccountFromCsv(page, csvRow);
    if (result !== 'created') {
      throw new Error(
        `Salesforce flagged "${TEST_ACCOUNT_NAME}" as a possible duplicate, so it could not be created.`
      );
    }

    return {
      accountName: csvRow[ACCT_COL.name].trim(),
      accountUrl: page.url(),
      created: true,
    };
  }

  const mappedAccountNames = getMappedAccountNames();
  const visibleNames = new Set<string>();

  if (hasRows) {
    const accountLinks = getAccountGrid(page)
      .getByRole('rowheader')
      .getByRole('link');
    const accountNames: string[] = [];
    const eligibleIndexes: number[] = [];
    const linkCount = await accountLinks.count();

    for (let index = 0; index < linkCount; index++) {
      const name = (await accountLinks.nth(index).innerText()).trim();
      accountNames.push(name);
      visibleNames.add(name.toLowerCase());
      if (mappedAccountNames.has(name.toLowerCase())) {
        eligibleIndexes.push(index);
      }
    }

    if (forceCreate) {
      console.log('FORCE_ACCOUNT_CREATION is set. Skipping the random pick.');
    } else if (eligibleIndexes.length > 0) {
      // Optional: ACCOUNT_POOL_SIZE=N limits the pool to the N newest eligible accounts.
      const poolSize =
        Number(process.env.ACCOUNT_POOL_SIZE) || eligibleIndexes.length;
      const pool = eligibleIndexes.slice(0, poolSize);
      const selectedIndex = pool[Math.floor(Math.random() * pool.length)];
      const accountName = accountNames[selectedIndex];

      console.log(
        `Random Account selected from ${pool.length} eligible Account(s): ${accountName}`
      );

      await accountLinks.nth(selectedIndex).click();
      await waitForAccountPage(page, accountName);
      console.log(`Account opened from list view: ${accountName}`);

      return { accountName, accountUrl: page.url(), created: false };
    } else {
      console.log(
        `No visible Account has contact mappings in ${CONTACT_CSV}. Visible: ${accountNames.join(' | ')}. Falling back to Account creation.`
      );
    }
  }

  // ---- Account creation path ----
  const candidates = shuffle(
    readAccountCsvRows().filter((row) => {
      const key = normalizeKey(row[ACCT_COL.name]);
      return mappedAccountNames.has(key) && !visibleNames.has(key);
    })
  );

  if (candidates.length === 0) {
    throw new Error(
      `No Account can be created: ${ACCOUNT_CSV} has no Account that both has rows in ${CONTACT_CSV} and is missing from the list view.`
    );
  }

  const maxAttempts = Math.min(5, candidates.length);

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const row = candidates[attempt];
    const result = await createAccountFromCsv(page, row);

    if (result === 'created') {
      return {
        accountName: row[ACCT_COL.name].trim(),
        accountUrl: page.url(),
        created: true,
      };
    }
  }

  throw new Error(
    `Tried ${maxAttempts} Account(s) from ${ACCOUNT_CSV} but Salesforce flagged each as a duplicate.`
  );
}

/* ------------------------------------------------------------------ */
/* Contacts                                                            */
/* ------------------------------------------------------------------ */

function contactFullName(contact: ContactCsvRecord): string {
  return `${contact['FirstName']?.trim() || ''} ${contact['LastName']?.trim() || ''}`.trim();
}

function normalizeContactName(name: string): string {
  return name.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

async function getAccountContactCount(
  page: Page,
  accountName: string
): Promise<number> {
  const relatedTab = page
    .getByRole('tab', { name: /^Related$/i })
    .or(page.getByRole('button', { name: /^Related$/i }))
    .first();
  await expect(relatedTab).toBeVisible({ timeout: 30000 });
  await relatedTab.click();

  const contactsHeading = page
    .getByRole('heading', {
      name: /^(?:Related\s+)?Contacts(?:\s*\(\d+\+?\))?$/i,
    })
    .filter({ visible: true })
    .first();
  await expect(contactsHeading).toBeVisible({ timeout: 30000 });

  const contactsCard = contactsHeading.locator('xpath=ancestor::article[1]');
  await expect(contactsCard).toBeVisible({ timeout: 30000 });

  const contactLinks = contactsCard.locator(
    'a[href*="/lightning/r/Contact/"], a[href*="/lightning/r/003"]'
  );
  const emptyMessage = contactsCard
    .getByText(/no contacts found|no records found|no records to display/i)
    .filter({ visible: true })
    .first();

  let contactCount = 0;
  await expect
    .poll(
      async () => {
        const headingText = (await contactsHeading.innerText()).trim();
        const headingCount = headingText.match(/\((\d+)\+?\)\s*$/);
        const linkCount = await contactLinks.count();

        if (linkCount > 0) {
          contactCount = linkCount;
          return 'contacts';
        }
        if (headingCount) {
          contactCount = Number(headingCount[1]);
          return contactCount > 0 ? 'contacts' : 'empty';
        }
        if (await isVisible(emptyMessage)) return 'empty';
        return 'loading';
      },
      { timeout: 15000, intervals: [500, 1000] }
    )
    .not.toBe('loading');

  console.log(
    `Contacts found on Account page for "${accountName}": ${contactCount}`
  );
  return contactCount;
}

async function openContactsObjectPage(
  page: Page,
  accountUrl: string
): Promise<void> {
  const contactsUrl = new URL(accountUrl);
  contactsUrl.pathname = '/lightning/o/Contact/list';
  contactsUrl.search = '?filterName=Recent';
  contactsUrl.hash = '';

  await page.goto(contactsUrl.toString(), { waitUntil: 'domcontentloaded' });
  await page.waitForURL(/\/lightning\/o\/Contact\/list/i, { timeout: 60000 });
  await expect(
    page.getByRole('heading', { name: /^Contacts\b/i }).first()
  ).toBeVisible({ timeout: 60000 });
  await expect(
    page
      .getByRole('button', { name: /^New$/i })
      .or(page.getByRole('link', { name: /^New$/i }))
      .first()
  ).toBeVisible({ timeout: 30000 });

  console.log('Salesforce Contacts object page opened for contact creation.');
}

async function createSingleContact(
  page: Page,
  contact: ContactCsvRecord
): Promise<void> {
  const firstName = contact['FirstName']?.trim() || '';
  const lastName = contact['LastName']?.trim() || '';
  const accountName = contact['Account.Name']?.trim() || '';
  const fullName = contactFullName(contact);

  if (!lastName) {
    throw new Error(
      `Last Name is missing in the Contact CSV row for Account "${accountName}".`
    );
  }

  const newButton = page
    .getByRole('button', { name: /^New$/i })
    .or(page.getByRole('link', { name: /^New$/i }))
    .first();

  await expect(newButton).toBeVisible({ timeout: 30000 });
  await newButton.click();

  const contactDialog = page
    .getByRole('dialog', { name: /^New Contact$/i })
    .first();

  await expect(contactDialog).toBeVisible({ timeout: 30000 });

  await fillTextbox(contactDialog, /^First Name$/i, firstName);
  await fillTextbox(contactDialog, /^Last Name$/i, lastName);
  console.log(`Contact Name entered: ${fullName}`);

  await selectComboboxValue(
    page,
    contactDialog.getByRole('combobox', { name: /^Account Name$/i }).first(),
    accountName,
    'Account Name'
  );

  await selectComboboxValue(
    page,
    contactDialog.getByRole('combobox', { name: /^Mailing Country$/i }).first(),
    contact['MailingCountry']?.trim() || '',
    'Mailing Country'
  );

  await fillTextbox(contactDialog, /^Mailing Street$/i, contact['MailingStreet']?.trim() || '');
  await fillTextbox(contactDialog, /^Mailing City$/i, contact['MailingCity']?.trim() || '');

  await selectComboboxValue(
    page,
    contactDialog
      .getByRole('combobox', { name: /^Mailing State\/Province$/i })
      .first(),
    contact['MailingState']?.trim() || '',
    'Mailing State/Province'
  );

  await fillTextbox(
    contactDialog,
    /^Mailing Zip\/Postal Code$/i,
    contact['MailingPostalCode']?.trim() || ''
  );

  await fillTextbox(
    contactDialog,
    /^SSN$/i,
    contact['SSN__c']?.trim() || contact['SSN']?.trim() || ''
  );

  // Optional fields - skipped silently if the layout does not show them.
  await fillTextbox(contactDialog, /^Phone$/i, contact['Phone']?.trim() || '', true);
  await fillTextbox(contactDialog, /^Mobile$/i, contact['MobilePhone']?.trim() || '', true);
  await fillTextbox(contactDialog, /^Email$/i, contact['Email']?.trim() || '', true);
  await fillTextbox(contactDialog, /^Title$/i, contact['Title']?.trim() || '', true);
  await fillTextbox(contactDialog, /^Department$/i, contact['Department']?.trim() || '', true);

  const saveButton = contactDialog.getByRole('button', { name: /^Save$/i }).first();
  await expect(saveButton).toBeEnabled({ timeout: 30000 });
  await saveButton.click();
  console.log(`Save clicked for Contact: ${fullName}`);

  // Salesforce displays this warning inside the New Contact form, not as a separate dialog.
  const duplicateWarning = page
    .getByText(/Similar Records Exist|This record looks like an existing record/i)
    .first();

  const saveOutcome = await waitForOutcome({
    duplicate: () => duplicateWarning.waitFor({ state: 'visible', timeout: 60000 }),
    saved: () => contactDialog.waitFor({ state: 'hidden', timeout: 60000 }),
  });

  if (saveOutcome === 'duplicate') {
    console.log(
      `Salesforce found a possible existing Contact. Skipping duplicate: ${fullName} | Account: ${accountName}`
    );
    await cancelDialog(contactDialog, 'Contact');
    return;
  }

  if (saveOutcome === 'saved') {
    console.log(`Contact created: ${fullName} | Account: ${accountName}`);
    return;
  }

  const dialogText = (await contactDialog.innerText().catch(() => ''))
    .replace(/\s+/g, ' ')
    .trim();
  throw new Error(
    `Salesforce did not complete saving Contact "${fullName}" and no duplicate warning appeared. Form: ${dialogText || 'no form details available'}`
  );
}

async function createContactsForAccount(
  page: Page,
  accountName: string,
  accountUrl: string
): Promise<void> {
  const existingContactCount = await getAccountContactCount(page, accountName);

  if (existingContactCount > 0) {
    console.log(
      `Account "${accountName}" already has ${existingContactCount} contact(s). Skipping Contacts-page lookup and creation.`
    );
    return;
  }

  console.log(
    `No contacts found on Account "${accountName}". Creating contacts from CSV.`
  );

  const contacts = readContactsForAccount(accountName);

  if (contacts.length === 0) {
    throw new Error(
      `No Contact CSV rows found for Account "${accountName}". Add contact data to ${CONTACT_CSV} for this Account before running the regression test.`
    );
  }

  const uniqueContacts: ContactCsvRecord[] = [];
  const seen = new Set<string>();

  for (const contact of contacts) {
    const fullName = contactFullName(contact);
    const key = normalizeContactName(fullName);

    if (seen.has(key)) {
      console.log(`Contact already exists. Skipping: ${fullName}`);
      continue;
    }
    seen.add(key);
    uniqueContacts.push(contact);
  }

  // Each contact: go back to the Contacts list page, then click New.
  // Saving a contact navigates away, so the list must be reopened every time.
  for (const contact of uniqueContacts) {
    await openContactsObjectPage(page, accountUrl);
    await createSingleContact(page, contact);
  }

  // Return to the Account so the Review Credit flow can continue.
  await page.goto(accountUrl, { waitUntil: 'domcontentloaded' });
  await waitForAccountPage(page, accountName, 60000);

  // Confirm the contacts actually landed on the Account.
  // This also selects the Related tab, which the report steps need.
  let createdCount = 0;
  try {
    await expect
      .poll(
        async () => {
          createdCount = await getAccountContactCount(page, accountName);
          if (createdCount === 0) {
            await page.reload({ waitUntil: 'domcontentloaded' });
          }
          return createdCount;
        },
        { timeout: 60000, intervals: [2000, 3000, 5000] }
      )
      .toBeGreaterThan(0);
  } catch {
    throw new Error(
      `Contact creation finished but Account "${accountName}" still shows no contacts. ` +
        `All contacts may have been skipped as duplicates linked to another Account.`
    );
  }

  console.log(
    `Contact creation/check completed for Account: ${accountName} (${createdCount} contact(s))`
  );
}

/* ------------------------------------------------------------------ */
/* Reports                                                             */
/* ------------------------------------------------------------------ */

async function waitForCreditReportPage(frame: FrameLocator): Promise<void> {
  const heading = frame
    .getByRole('heading', { name: /request .*credit reports/i })
    .or(frame.getByText(/request .*credit reports/i))
    .or(frame.getByRole('button', { name: /request reports/i }))
    .first();

  await expect(heading).toBeVisible({ timeout: 45000 });
}

async function openReportViewAll(
  page: Page,
  reportLabel: RegExp
): Promise<void> {
  console.log(`Opening ${reportLabel} View All...`);

  const reportLink = page.getByRole('link', { name: reportLabel }).first();

  // Related lists are lazy rendered - scroll until the link appears.
  for (let i = 0; i < 40; i++) {
    if (await isVisible(reportLink)) break;
    await page.keyboard.press('PageDown');
    await page.waitForTimeout(100);
  }

  await expect(reportLink).toBeVisible({ timeout: 30000 });
  await reportLink.scrollIntoViewIfNeeded();
  await reportLink.click();

  await page.waitForURL('**/related/**/view', { timeout: 30000 });

  await expect(page.getByRole('heading', { name: reportLabel })).toBeVisible({
    timeout: 30000,
  });

  console.log(`${reportLabel} View All page loaded.`);
}

const REPORT_NAME_PATTERN = {
  Consumer: /^EfxConsumer-\d+$/i,
  Commercial: /Equifax CC-/i,
} as const;

/** Report record names currently listed (newest first) on a "View All" related list page. */
async function getReportNames(
  page: Page,
  reportType: ReportType
): Promise<string[]> {
  const grid = page.getByRole('grid').filter({ visible: true }).last();
  const gridVisible = await grid
    .waitFor({ state: 'visible', timeout: 15000 })
    .then(() => true)
    .catch(() => false);

  // An empty related list may not render a grid at all.
  if (!gridVisible) return [];

  await sortByCreatedDateDescending(grid).catch(() =>
    console.log(`Could not confirm Created Date sort for ${reportType} reports.`)
  );

  const names = await grid
    .getByRole('link', { name: REPORT_NAME_PATTERN[reportType] })
    .allInnerTexts();

  return names.map((name) => name.trim()).filter(Boolean);
}

function nameTokens(name: string): string[] {
  return name
    .toLocaleLowerCase()
    .split(/[^\p{L}\p{N}]+/u)
    .filter(Boolean);
}

/**
 * Match a full contact name as a contiguous token sequence, not merely as
 * unrelated words anywhere on the page.
 *
 * Supports "First Last", "First Middle Last" and Salesforce's "Last, First [Middle]"
 * by trying every rotation of the name tokens
 * (e.g. "KGIPD V HJDBJ" also matches "HJDBJ, KGIPD V").
 */
function textContainsName(pageText: string, contactName: string): boolean {
  const pageTokens = nameTokens(pageText);
  const tokens = nameTokens(contactName);
  if (tokens.length === 0 || pageTokens.length < tokens.length) return false;

  const variants: string[][] = [];
  for (let shift = 0; shift < tokens.length; shift++) {
    variants.push([...tokens.slice(shift), ...tokens.slice(0, shift)]);
  }
  if (tokens.length > 1) variants.push([...tokens].reverse());

  return variants.some((variant) => {
    for (let start = 0; start <= pageTokens.length - variant.length; start++) {
      if (variant.every((token, offset) => pageTokens[start + offset] === token)) {
        return true;
      }
    }
    return false;
  });
}

/**
 * Reads the value of the "Contact" field from a Lightning record detail page
 * (label/value pair). Returns '' when the layout does not expose it.
 */
async function getContactFieldValue(page: Page): Promise<string> {
  const label = page
    .locator('.test-id__field-label')
    .filter({ hasText: /^\s*Contact\s*$/i })
    .filter({ visible: true })
    .first();

  if (!(await isVisible(label))) return '';

  const container = label.locator(
    'xpath=ancestor::*[contains(@class,"slds-form-element")][1]'
  );

  const text = (await container.innerText().catch(() => ''))
    .replace(/\s+/g, ' ')
    .replace(/^\s*Contact\s*/i, '')
    .trim();

  return text;
}

/**
 * Screenshots a report record that is already open.
 * `verify` runs once the details have loaded and BEFORE the screenshot.
 * It may throw to fail the run (used for HIT / NO-HIT identity checks).
 */
async function captureOpenedReportDetail(
  page: Page,
  testInfo: TestInfo,
  reportType: ReportType,
  reportName: string,
  verify?: (details: Record<string, string>) => void
): Promise<boolean> {
  await page.waitForLoadState('domcontentloaded');
  await expect(page.locator('body')).toContainText(reportName, {
    timeout: 60000,
  });

  const detailsTab = page
    .getByRole('tab', { name: /^Details$/i })
    .or(page.getByRole('button', { name: /^Details$/i }))
    .first();
  await expect(detailsTab).toBeVisible({ timeout: 60000 });
  await detailsTab.click();

  const reportIdLabel = page
    .getByText(new RegExp(`^Equifax ${reportType} Report ID$`, 'i'))
    .filter({ visible: true })
    .first();
  await expect(reportIdLabel).toBeVisible({ timeout: 60000 });
  await expect
    .poll(
      async () => {
        const reportDetails = await captureReportDetails(page, reportType);
        return reportDetails['Equifax Report ID'] || '';
      },
      { timeout: 60000, intervals: [500, 1000, 2000] }
    )
    .toBeTruthy();

  if (verify) {
    const details = await captureReportDetails(page, reportType);
    verify(details);
  }

  await reportIdLabel.scrollIntoViewIfNeeded();

  // Wait for spinners to clear and the PDF preview to render before the screenshot.
  await waitForReportToFinishLoading(
    page,
    reportType === 'Commercial'
      ? COMMERCIAL_REPORT_RENDER_WAIT_MS
      : REPORT_RENDER_WAIT_MS,
    reportType === 'Commercial'
  );

  const screenshotLabel = `${reportType.toLowerCase()}-report-${reportName
    .replace(/[^a-z0-9-]+/gi, '-')
    .replace(/^-|-$/g, '')}-detail`;
  await captureScreenshot(page, testInfo, screenshotLabel);
  console.log(`${reportType} report detail captured: ${reportName}`);
  return true;
}

/**
 * Opens and screenshots ONLY a report that did not exist before this run.
 * Reports already present in `namesBefore` are never opened, so a stale
 * (previously generated) report can never be captured.
 * Must be called from the report type's "View All" page.
 * Returns false (and takes no screenshot) when no new report exists.
 */
async function captureNewReportScreenshot(
  page: Page,
  testInfo: TestInfo,
  reportType: ReportType,
  namesBefore: string[]
): Promise<boolean> {
  const headingName =
    reportType === 'Consumer'
      ? /Equifax Consumer Reports/i
      : /Equifax Commercial Reports/i;

  await expect(page.getByRole('heading', { name: headingName })).toBeVisible({
    timeout: 30000,
  });

  const before = new Set(namesBefore.map((name) => name.toLowerCase()));
  const afterNames = await getReportNames(page, reportType); // newest first
  const newNames = afterNames.filter((name) => !before.has(name.toLowerCase()));

  if (newNames.length === 0) {
    console.log(
      `No new ${reportType} report was created by this run. Skipping screenshot (existing reports are never captured).`
    );
    return false;
  }

  const reportName = newNames[0]; // newest of the newly created reports
  console.log(
    `New ${reportType} report(s) from this run: ${newNames.join(', ')}. Capturing: ${reportName}`
  );

  const grid = page.getByRole('grid').filter({ visible: true }).last();
  const link = grid.getByRole('link', { name: reportName, exact: true }).first();

  await expect(link).toBeVisible({ timeout: 30000 });
  const href = await link.getAttribute('href');
  if (!href?.includes('/lightning/r/')) {
    throw new Error(
      `The new ${reportType} report "${reportName}" has no valid Salesforce record link.`
    );
  }

  await link.click();
  await page.waitForURL('**/lightning/r/**/view', { timeout: 30000 });
  return captureOpenedReportDetail(page, testInfo, reportType, reportName);
}

/**
 * Screenshots ONLY the Consumer reports created by the request that just ran.
 * - Reports that already existed before the request are never opened (no stale screenshots).
 * - Reports that belong to a NO-HIT contact are never accepted.
 * - Example: 3 contacts (2 HIT + 1 NO-HIT) -> exactly 2 reports are opened, one per HIT contact.
 * Must be called from the Consumer Reports "View All" page.
 */
async function captureNewConsumerReportScreenshots(
  page: Page,
  testInfo: TestInfo,
  reportNamesBefore: string[],
  results: ConsumerRequestResults
): Promise<number> {
  const before = new Set(reportNamesBefore.map((name) => name.toLowerCase()));
  const afterNames = await getReportNames(page, 'Consumer');
  const newReportNames = afterNames.filter(
    (name) => !before.has(name.toLowerCase())
  );

  console.log(
    `New Consumer report(s) from this request: ${newReportNames.join(', ') || 'none'}`
  );

  // Count is the authoritative first check: one new report per HIT contact,
  // and no new report for a NO-HIT contact.
  if (newReportNames.length !== results.expectedReportCount) {
    throw new Error(
      `Expected ${results.expectedReportCount} new Consumer report(s) (one per HIT contact, NO-HIT excluded) but found ${newReportNames.length}: ${newReportNames.join(', ') || 'none'}.`
    );
  }

  const noHitNames = results.noHitContacts.map((contact) => contact.name);
  const hitNamesNotMatched = new Set(results.hitContacts);
  let captured = 0;

  for (const reportName of newReportNames) {
    const grid = page.getByRole('grid').filter({ visible: true }).last();
    const link = grid
      .getByRole('link', { name: reportName, exact: true })
      .first();

    await expect(link).toBeVisible({ timeout: 30000 });
    const href = await link.getAttribute('href');
    if (!href || !href.includes('/lightning/r/')) {
      throw new Error(`Consumer report "${reportName}" has no valid Salesforce record link.`);
    }

    await link.click();
    await page.waitForURL('**/lightning/r/**/view', { timeout: 30000 });

    // Identity validation runs inside captureOpenedReportDetail, after the
    // details have loaded and before the screenshot is taken.
    const verifyIdentity = (details: Record<string, string>): void => {
      const pageText = details.pageText || '';
      // Prefer the Contact field when Salesforce exposes it; otherwise inspect
      // the rendered details text because some layouts have no separate field.
      const identityText = details.ContactField || pageText;

      const matchedNoHits = noHitNames.filter((name) =>
        textContainsName(identityText, name)
      );
      const matchedHits = results.hitContacts.filter((name) =>
        textContainsName(identityText, name)
      );

      if (matchedNoHits.length > 0) {
        throw new Error(
          `NO-HIT validation failed: newly created Consumer report "${reportName}" contains NO-HIT contact name(s): ${matchedNoHits.join(', ')}.`
        );
      }

      if (matchedHits.length > 1) {
        throw new Error(
          `Consumer report "${reportName}" ambiguously matches multiple HIT contacts: ${matchedHits.join(', ')}.`
        );
      }

      if (matchedHits.length === 1) {
        const matchedHit = matchedHits[0];
        if (!hitNamesNotMatched.has(matchedHit)) {
          throw new Error(
            `Multiple new Consumer reports appear to map to HIT contact "${matchedHit}". Report: ${reportName}.`
          );
        }
        hitNamesNotMatched.delete(matchedHit);
        console.log(
          `Verified Consumer report mapping: ${reportName} -> HIT contact "${matchedHit}"`
        );
        return;
      }

      // No recognisable contact identity on the page.
      if (results.noHitContacts.length > 0) {
        // Mixed HIT / NO-HIT run: without identity we cannot prove this report is
        // not the NO-HIT contact's (or a stale one), so fail instead of screenshotting.
        throw new Error(
          `NO-HIT contact(s) exist (${noHitNames.join(', ')}) but the identity of new Consumer report "${reportName}" could not be verified. ` +
            `Cannot prove the screenshot is not a stale/NO-HIT report.`
        );
      }

      // All contacts were HIT: the count check is already strict, so just record the limitation.
      console.warn(
        `Contact identity is not exposed in the visible details for ${reportName}. ` +
          `The report count is valid, but one-to-one contact mapping cannot be proven from this page layout.`
      );
      testInfo.annotations.push({
        type: 'consumer-report-identity-unverified',
        description: `${reportName}: visible Salesforce details did not expose a uniquely identifiable Contact.`,
      });
    };

    const wasCaptured = await captureOpenedReportDetail(
      page,
      testInfo,
      'Consumer',
      reportName,
      verifyIdentity
    );
    if (!wasCaptured) {
      throw new Error(`Consumer report "${reportName}" was not captured.`);
    }
    captured++;

    await page.goBack({ waitUntil: 'domcontentloaded' });
    await expect(
      page.getByRole('heading', { name: /Equifax Consumer Reports/i })
    ).toBeVisible({ timeout: 30000 });
  }

  // Enforce exact one-to-one mapping when identities were exposed.
  const unmatchedHits = Array.from(hitNamesNotMatched);
  if (unmatchedHits.length > 0 && results.noHitContacts.length === 0) {
    // Identity may be hidden by the layout; already warned above. Count check stays authoritative.
    console.log(
      `HIT contact(s) not individually matched by name: ${unmatchedHits.join(', ')}`
    );
  } else if (unmatchedHits.length > 0) {
    throw new Error(
      `Missing Consumer report(s) for HIT contact(s): ${unmatchedHits.join(', ')}. ` +
        `Expected one report per HIT contact and zero reports for NO-HIT contacts.`
    );
  }

  if (captured !== results.expectedReportCount) {
    throw new Error(
      `Expected ${results.expectedReportCount} Consumer report screenshot(s) but captured ${captured}.`
    );
  }

  console.log(
    `Consumer report screenshots captured: ${captured} (HIT contacts: ${results.hitContacts.length}, NO-HIT contacts: ${results.noHitContacts.length})`
  );
  return captured;
}

interface ReportCountInfo {
  count: number;
  /** True when Salesforce shows "50+ items": the number is only a lower bound. */
  capped: boolean;
}

async function getReportCountInfo(
  page: Page,
  reportType: ReportType
): Promise<ReportCountInfo> {
  const reportStatus = page.getByRole('status', {
    name:
      reportType === 'Consumer'
        ? 'Equifax Consumer Reports'
        : 'Equifax Commercial Reports',
  });

  await expect(reportStatus).toBeVisible({ timeout: 30000 });

  const statusText = (await reportStatus.textContent())?.trim() || '';
  // Handles "5 items", "1 item" and the capped form "50+ items".
  const countMatch = statusText.match(/(\d+)(\+)?\s*items?/i);

  if (!countMatch) {
    throw new Error(
      `Unable to extract ${reportType} report count from: "${statusText}"`
    );
  }

  return { count: Number(countMatch[1]), capped: Boolean(countMatch[2]) };
}

async function getReportCount(
  page: Page,
  reportType: ReportType
): Promise<number> {
  return (await getReportCountInfo(page, reportType)).count;
}

/** Reload the related list until the report count reaches `expected`. */
async function waitForReportCount(
  page: Page,
  reportType: ReportType,
  before: number,
  expected: number,
  exactMatch = false,
  namesBefore: string[] = []
): Promise<number> {
  let current = before;
  // The page was just opened, so the first check needs no reload.
  let firstPoll = true;
  const beforeNames = new Set(namesBefore.map((name) => name.toLowerCase()));

  const reportCount = expect.poll(
    async () => {
      if (!firstPoll) await page.reload({ waitUntil: 'domcontentloaded' });
      firstPoll = false;

      const info = await getReportCountInfo(page, reportType);
      current = info.count;

      if (info.capped) {
        // "50+ items": the number no longer changes, so count NEW report
        // names (list is sorted newest first) and derive the effective count.
        const names = await getReportNames(page, reportType);
        const newCount = names.filter(
          (name) => !beforeNames.has(name.toLowerCase())
        ).length;
        current = before + newCount;
        console.log(
          `${reportType} Reports list is capped (${info.count}+). New report names detected: ${newCount}`
        );
      }

      console.log(
        `${reportType} Reports: before=${before}, current=${current}, expected${exactMatch ? '' : ' minimum'}=${expected}`
      );

      return current;
    },
    { timeout: 180000, intervals: [1000, 2000, 3000] }
  );

  if (exactMatch) {
    await reportCount.toBe(expected);
  } else {
    await reportCount.toBeGreaterThanOrEqual(expected);
  }

  return current;
}

async function getAvailableConsumerContactCount(
  frame: FrameLocator
): Promise<number> {
  // One round trip instead of one per cell.
  const texts = await frame
    .locator('table tbody tr td:nth-child(2)')
    .allTextContents();

  const validNameCount = texts.filter((text) => {
    const trimmed = text.trim();
    return trimmed && trimmed.toUpperCase() !== 'NAME';
  }).length;

  console.log(`Available Consumer contacts: ${validNameCount}`);
  return validNameCount;
}

async function selectConsumerContacts(frame: FrameLocator): Promise<number> {
  const checkboxes = frame.locator('input[type="checkbox"]');

  await expect
    .poll(() => checkboxes.count(), { timeout: 30000, intervals: [500, 1000] })
    .toBeGreaterThan(1);

  console.log(`Checkbox inputs found: ${await checkboxes.count()}`);

  // First checkbox is "Select All".
  const selectAll = checkboxes.first();
  await expect(selectAll).toBeVisible({ timeout: 30000 });
  await expect(selectAll).toBeEnabled({ timeout: 30000 });

  if (!(await selectAll.isChecked())) {
    await selectAll.check({ force: true });
  }

  // Counts evaluated in the browser in one call (visible + enabled rows only).
  const countChecked = () =>
    checkboxes.evaluateAll(
      (els) =>
        (els as HTMLInputElement[])
          .slice(1)
          .filter((el) => !el.disabled && el.offsetParent !== null && el.checked)
          .length
    );

  await expect
    .poll(countChecked, { timeout: 30000, intervals: [250, 500, 1000] })
    .toBeGreaterThan(0);

  // Pick up any row that Select All did not tick.
  const uncheckedIndexes = await checkboxes.evaluateAll((els) =>
    (els as HTMLInputElement[])
      .map((el, index) => ({ el, index }))
      .filter(
        ({ el, index }) =>
          index > 0 && !el.disabled && el.offsetParent !== null && !el.checked
      )
      .map(({ index }) => index)
  );

  for (const index of uncheckedIndexes) {
    await checkboxes.nth(index).check({ force: true, timeout: 5000 });
  }

  const selectedCount = await countChecked();
  console.log(`Total Consumer contacts selected: ${selectedCount}`);

  return selectedCount;
}

interface ConsumerRequestResults {
  hitContacts: string[];
  noHitContacts: { name: string; detail: string }[];
  /** Reports that must exist after this request = number of HIT contacts (NO-HIT contacts are excluded). */
  expectedReportCount: number;
}

/**
 * Reads the per-contact result table after "Request Reports".
 * Each row is classified as HIT or NO-HIT so that only HIT contacts are treated as reports.
 */
async function getConsumerRequestResults(
  frame: FrameLocator,
  expectedContactCount: number
): Promise<ConsumerRequestResults> {
  // One round trip: direct child cells of every row.
  const rows: string[][] = await frame
    .locator('table tbody tr')
    .evaluateAll((trs) =>
      (trs as HTMLElement[]).map((tr) =>
        Array.from(tr.querySelectorAll(':scope > td')).map((td) =>
          (td as HTMLElement).innerText.replace(/\s+/g, ' ').trim()
        )
      )
    );

  const hitContacts: string[] = [];
  const noHitContacts: { name: string; detail: string }[] = [];

  for (const cells of rows) {
    // Classify NO-HIT first so it can never be mistaken for a HIT by a loose match.
    const statusIndex = cells.findIndex(
      (cell) => /^No[\s-]*Hit\b/i.test(cell) || /^Hit\b/i.test(cell)
    );
    if (statusIndex < 1) continue;

    const name = cells[statusIndex - 1].trim();
    const status = cells[statusIndex].trim();
    if (!name) {
      throw new Error(
        `Consumer result row has status "${status}" but no contact name immediately before it: ${cells.join(' | ')}`
      );
    }

    if (/^No[\s-]*Hit\b/i.test(status)) {
      noHitContacts.push({ name, detail: status });
    } else if (/^Hit\b/i.test(status)) {
      hitContacts.push(name);
    }
  }

  const allClassifiedNames = [
    ...hitContacts,
    ...noHitContacts.map((contact) => contact.name),
  ];
  const uniqueClassifiedNames = new Set(
    allClassifiedNames.map((name) => normalizeContactName(name))
  );
  if (uniqueClassifiedNames.size !== allClassifiedNames.length) {
    throw new Error(
      `Consumer request results contain duplicate contact classifications. HIT=[${hitContacts.join(', ')}], NO-HIT=[${noHitContacts.map((contact) => contact.name).join(', ')}].`
    );
  }

  const classifiedCount = hitContacts.length + noHitContacts.length;
  if (classifiedCount !== expectedContactCount) {
    throw new Error(
      `Consumer request status classification incomplete. Expected=${expectedContactCount}, classified=${classifiedCount}, Hit=${hitContacts.length}, No Hit=${noHitContacts.length}.`
    );
  }

  console.log(
    `Consumer request results: Hit=${hitContacts.length}, No Hit=${noHitContacts.length}; only HIT results count as reports.`
  );
  for (const noHit of noHitContacts) {
    console.log(`NO-HIT contact: ${noHit.name} -> ${noHit.detail}`);
  }

  return {
    hitContacts,
    noHitContacts,
    expectedReportCount: hitContacts.length,
  };
}

async function clickDoneAfterRequest(
  page: Page,
  testInfo: TestInfo,
  expectedContactCount: number
): Promise<ConsumerRequestResults> {
  console.log('Waiting for Consumer report processing to complete');

  let stableDoneChecks = 0;

  await expect
    .poll(
      async () => {
        const { frame } = getVfFrame(page);

        const [doneVisible, requestReportsVisible] = await Promise.all([
          isVisible(frame.getByRole('button', { name: /^Done$/i })),
          isVisible(frame.getByRole('button', { name: /request reports/i })),
        ]);

        stableDoneChecks =
          doneVisible && !requestReportsVisible ? stableDoneChecks + 1 : 0;

        console.log(
          `Done=${doneVisible}, RequestReports=${requestReportsVisible}, stableChecks=${stableDoneChecks}`
        );

        // Completed state must survive multiple Visualforce refresh cycles.
        return stableDoneChecks >= 2;
      },
      { timeout: 90000, intervals: [500, 1000] }
    )
    .toBe(true);

  const { frame: completedFrame } = getVfFrame(page);
  const doneButton = completedFrame.getByRole('button', { name: /^Done$/i });

  await expect(doneButton).toBeVisible({ timeout: 30000 });
  const results = await getConsumerRequestResults(
    completedFrame,
    expectedContactCount
  );

  // Only HIT contacts count towards the report pull.
  // Example: 3 contacts, 1 NO-HIT + 2 HIT -> exactly 2 reports are expected.
  if (results.hitContacts.length > 0) {
    console.log(
      `HIT contact(s) (${results.hitContacts.length}): ${results.hitContacts.join(' | ')}`
    );
    console.log(
      `Report count will be validated for ${results.expectedReportCount} of ${expectedContactCount} contact(s).`
    );
  } else {
    console.log(
      'No contact returned HIT. No report is expected for this request.'
    );
  }
  if (results.noHitContacts.length > 0) {
    console.log(
      `NO-HIT contact(s) excluded from the report count (${results.noHitContacts.length}): ${results.noHitContacts
        .map((contact) => contact.name)
        .join(' | ')}`
    );
  }

  await doneButton.scrollIntoViewIfNeeded();

  // The result table (HIT / NO-HIT per contact) is the evidence for NO-HIT scenarios.
  const screenshotLabel =
    results.noHitContacts.length > 0
      ? 'consumer-no-hit-result'
      : 'consumer-processing-complete';
  await captureScreenshot(page, testInfo, screenshotLabel);

  for (const noHit of results.noHitContacts) {
    testInfo.annotations.push({
      type: 'consumer-no-hit',
      description: `${noHit.name} - ${noHit.detail}`,
    });
  }

  await doneButton.click();

  console.log('Processing completed. Done button clicked.');
  return results;
}

async function captureReportDetails(
  page: Page,
  reportType: ReportType
): Promise<Record<string, string>> {
  const bodyText = (await page.locator('body').innerText())
    .replace(/\s+/g, ' ')
    .trim();

  const patterns: Record<string, RegExp> = {
    'Equifax Report ID': new RegExp(
      `Equifax ${reportType} Report ID\\s+([A-Za-z0-9-]+)`,
      'i'
    ),
    Contact: /Contact\s+([A-Z0-9\s\-.,]+)/i,
    Account: /Account\s+([A-Z0-9\s\-.,/&()]+)/i,
    'Beacon Score': /Beacon Score\s+([0-9]+)/i,
    'Credit Quality Rating': /Credit Quality Rating\s+([A-Za-z0-9\s\-.,]+)/i,
  };

  const extracted: Record<string, string> = { pageText: bodyText };

  for (const [key, pattern] of Object.entries(patterns)) {
    const match = bodyText.match(pattern);
    if (match) extracted[key] = match[1].trim();
  }

  // Precise Contact value taken from the record's own field label (preferred
  // for identity checks; the regex above is a loose, informational fallback).
  const contactField = await getContactFieldValue(page).catch(() => '');
  if (contactField) extracted.ContactField = contactField;

  if (
    /(Error|Exception|Unable|Failed|Invalid|404|Not Found|No content|No records|No data)/i.test(
      bodyText
    )
  ) {
    extracted.pageError = bodyText.slice(0, 1500);
  }

  return extracted;
}

/**
 * Used when EVERY selected Consumer contact returned NO-HIT
 * (e.g. the account has only 1 contact and it is NO-HIT).
 * Verifies that the NO-HIT outcome produced no Consumer report, records the
 * evidence, and lets the caller end the test.
 * Must be called from the Account page.
 */
async function validateAllNoHitOutcome(
  page: Page,
  testInfo: TestInfo,
  accountName: string,
  reportCountBefore: number,
  reportNamesBefore: string[],
  results: ConsumerRequestResults,
  selectedContactCount: number
): Promise<void> {
  // Result table must classify every selected contact as NO-HIT.
  expect(
    results.hitContacts,
    `Expected all contacts to be NO-HIT but HIT contact(s) were returned: ${results.hitContacts.join(', ')}`
  ).toHaveLength(0);
  expect(
    results.noHitContacts,
    'Every selected Consumer contact must be classified as NO-HIT.'
  ).toHaveLength(selectedContactCount);

  console.log(
    `All ${selectedContactCount} Consumer contact(s) are NO-HIT: ${results.noHitContacts
      .map((contact) => contact.name)
      .join(' | ')}`
  );

  // No report may have been created for a NO-HIT contact.
  await openReportViewAll(page, /Equifax Consumer Reports/i);
  await page.waitForTimeout(1000);
  await page.reload({ waitUntil: 'domcontentloaded' });

  const countAfter = await getReportCount(page, 'Consumer');
  expect(
    countAfter,
    `NO-HIT validation failed: Consumer report count changed from ${reportCountBefore} to ${countAfter}.`
  ).toBe(reportCountBefore);

  const afterNames = await getReportNames(page, 'Consumer');
  const beforeSet = new Set(reportNamesBefore.map((name) => name.toLowerCase()));
  const unexpected = afterNames.filter(
    (name) => !beforeSet.has(name.toLowerCase())
  );
  expect(
    unexpected,
    `All contacts were NO-HIT but new Consumer report(s) appeared: ${unexpected.join(', ')}`
  ).toHaveLength(0);

  await captureScreenshot(page, testInfo, 'consumer-reports-after-no-hit');

  testInfo.annotations.push({
    type: 'consumer-all-no-hit',
    description: `${accountName}: ${results.noHitContacts
      .map((contact) => contact.name)
      .join(', ')} - NO-HIT verified, no Consumer report created. Test ended.`,
  });

  console.log(
    `NO-HIT validated for "${accountName}": Consumer reports unchanged at ${countAfter}. Ending test.`
  );
}

/* ------------------------------------------------------------------ */
/* Test                                                                */
/* ------------------------------------------------------------------ */

/*
 * The evidence sheet should only contain the screenshots this test takes on
 * purpose (captureScreenshot calls). Playwright's automatic end-of-test
 * "screenshot" attachments (one per open page) are the unnamed "screenshot"
 * rows in the evidence workbook, so they are switched off for passing runs.
 * Failure screenshots are kept for debugging.
 */
test.use({ screenshot: 'only-on-failure' });

test(
  'One click: login -> random/created account -> contacts from CSV -> credit review -> validate reports',
  async ({ page: initialPage }, testInfo) => {
    test.setTimeout(240000);
    const runStart = Date.now();
    const lap = (label: string) =>
      console.log(`[timing] ${label}: ${((Date.now() - runStart) / 1000).toFixed(1)}s`);

    /* STEP 1 - Login */
    const page = await loginToSalesforce(initialPage, testInfo);

    /* STEP 2 - Account (random from list, or created from CSV) + Contacts */
    const { accountName, accountUrl, created } = await prepareAccount(
      page,
      testInfo
    );
    const selectedAccountUrl = accountUrl;

    testInfo.annotations.push({
      type: 'account',
      description: `${accountName} (${created ? 'created from CSV' : 'picked from list view'})`,
    });

    console.log(
      `Processing mapped contacts for Account: ${accountName} (${created ? 'newly created' : 'existing'})`
    );

    await createContactsForAccount(page, accountName, selectedAccountUrl);
    await captureScreenshot(page, testInfo, 'account-contacts-ready');

    lap('start STEP 3 (commercial before)');
    /* STEP 3 - Commercial Report count + names before Review Credit */
    await openReportViewAll(page, /Equifax Commercial Reports/i);

    const commercialReportCountBefore = await getReportCount(page, 'Commercial');
    // Remember existing reports so only newly created ones are screenshotted later.
    const commercialReportNamesBefore = await getReportNames(page, 'Commercial');
    console.log(
      `Commercial Reports before Review Credit: ${commercialReportCountBefore} (${commercialReportNamesBefore.length} named)`
    );
    await captureScreenshot(page, testInfo, 'commercial-reports-before');

    /* STEP 4 - Return to Account */
    await returnToAccount(page, accountName);

    lap('start STEP 5 (review credit)');
    /* STEP 5 - Open Review Credit */
    await clickAccountAction(page, /^Review Credit$/i);
    console.log('Review Credit button clicked.');

    /* STEP 6 - Review Credit iframe */
    const { element: reviewFrameElement, frame } = getVfFrame(page);
    await expect(reviewFrameElement).toBeVisible({ timeout: 60000 });
    console.log('Review Credit iframe loaded.');

    /* STEP 7 - Initial Go */
    const goButton = frame
      .getByRole('button', { name: /^Go$/i })
      .or(frame.locator('input[value="Go"]'))
      .first();

    await expect(goButton).toBeVisible({ timeout: 30000 });
    await page.evaluate(
      () =>
        new Promise<void>((resolve) => {
          requestAnimationFrame(() => requestAnimationFrame(() => resolve()));
        })
    );
    await captureScreenshot(page, testInfo, 'review-credit-start');
    await goButton.click();
    console.log('Initial Review Credit Go button clicked.');

    /* STEP 8 - Optional Consumer contact selection */
    const consumerReportHeading = frame
      .getByRole('heading', { name: /request consumer credit reports/i })
      .or(frame.getByText(/request consumer credit reports/i))
      .first();

    const creditReviewHeading = frame
      .getByRole('heading', { name: /credit review/i })
      .first();
    const requiredFieldsError = frame
      .getByText(/required fields are missing/i)
      .first();
    const databaseUpdateError = frame
      .getByText(/error occurred updating the salesforce database/i)
      .first();

    // Whichever shows first: consumer selection page, or a final response/error.
    const firstScreen = await waitForOutcome({
      consumerSelection: () =>
        consumerReportHeading.waitFor({ state: 'visible', timeout: 15000 }),
      response: () =>
        creditReviewHeading
          .or(requiredFieldsError)
          .or(databaseUpdateError)
          .first()
          .waitFor({ state: 'visible', timeout: 15000 }),
    });

    if (firstScreen === 'consumerSelection') {
      console.log('Review Credit displayed Consumer contact selection.');

      const availableContactCount =
        await getAvailableConsumerContactCount(frame);

      if (availableContactCount === 0) {
        const cancelButton = frame
          .getByRole('button', { name: /^Cancel$/i })
          .first();

        if (await isVisible(cancelButton)) await cancelButton.click();

        throw new Error(
          `No Consumer contacts are available for Review Credit on account "${accountName}".`
        );
      }

      const selectedContactCount = await selectConsumerContacts(frame);

      if (selectedContactCount === 0) {
        throw new Error(
          'No Consumer contacts could be selected during Review Credit.'
        );
      }

      console.log(
        `${selectedContactCount} Consumer contact(s) selected during Review Credit.`
      );

      const consumerGoButton = frame
        .getByRole('button', { name: /^Go$/i })
        .or(frame.locator('input[value="Go"]'))
        .first();

      await expect(consumerGoButton).toBeVisible({ timeout: 30000 });
      await consumerGoButton.click();
      console.log('Consumer contact selection Go button clicked.');
    }

    /* STEP 9 - Wait for response page or application error */
    await expect(
      creditReviewHeading.or(requiredFieldsError).or(databaseUpdateError).first()
    ).toBeVisible({ timeout: 90000 });

    console.log('Review Credit response page loaded.');
    await captureScreenshot(page, testInfo, 'review-credit-response');

    /* STEP 10 - Read the response */
    const reviewPageText = (
      await frame.locator('body').innerText().catch(() => '')
    )
      .replace(/\s+/g, ' ')
      .trim();

    console.log('Review Credit response:', reviewPageText.slice(0, 1500));

    const requiredFieldsMatch = reviewPageText.match(
      /Required fields are missing:\s*\[([^\]]+)\]/i
    );

    if (requiredFieldsMatch) {
      // Mark the run as skipped (not passed) so a skipped account is visible in the report.
      test.skip(
        true,
        `Account "${accountName}" skipped. Missing field(s): ${requiredFieldsMatch[1]}`
      );
      return;
    }

    if (/error occurred updating the salesforce database/i.test(reviewPageText)) {
      throw new Error('Review Credit failed while updating the Salesforce database.');
    }

    if (/error|exception|unable|failed|invalid/i.test(reviewPageText)) {
      throw new Error(
        `Review Credit failed. Response: ${reviewPageText.slice(0, 1500)}`
      );
    }

    /* STEP 11 - Return to Account */
    const returnToAccountButton = frame
      .getByRole('button', { name: /return to account detail/i })
      .or(frame.getByRole('link', { name: /return to account detail/i }))
      .first();

    await expect(returnToAccountButton).toBeVisible({ timeout: 60000 });
    await returnToAccountButton.scrollIntoViewIfNeeded();
    await returnToAccountButton.click();
    console.log('Return to Account Detail clicked.');

    /* STEP 12 - Confirm return */
    await page.waitForURL(ACCOUNT_VIEW_URL, { timeout: 30000 });
    await waitForAccountPage(page, accountName);
    console.log('Review Credit completed and returned to Account.');

    /* STEP 13-15 - Validate Commercial Report was created */
    await openReportViewAll(page, /Equifax Commercial Reports/i);

    const expectedCommercialReportCount = commercialReportCountBefore + 1;
    console.log(
      `Commercial Reports expected minimum count: ${expectedCommercialReportCount}`
    );

    const commercialReportCountAfter = await waitForReportCount(
      page,
      'Commercial',
      commercialReportCountBefore,
      expectedCommercialReportCount,
      false,
      commercialReportNamesBefore
    );

    console.log(
      `Review Credit completed. Commercial Reports changed from ${commercialReportCountBefore} to ${commercialReportCountAfter}.`
    );
    await captureScreenshot(page, testInfo, 'commercial-reports-after');

    /* ============ PART 2 - CONSUMER CREDIT REVIEW ============ */

    lap('start STEP 16 (part 2 start)');
    /* STEP 16 - Back to Account */
    await returnToAccount(page, accountName);
    console.log('Returned to Account after Commercial Report validation.');

    /* STEP 17 - Consumer Report count before */
    await openReportViewAll(page, /Equifax Consumer Reports/i);

    const consumerReportCountBefore = await getReportCount(page, 'Consumer');
    console.log(
      `Consumer Reports before Consumer Credit Review: ${consumerReportCountBefore}`
    );
    // Remember the existing reports so only newly created ones are screenshotted later.
    const consumerReportNamesBefore = await getReportNames(page, 'Consumer');
    await captureScreenshot(page, testInfo, 'consumer-reports-before');

    /* STEP 18 - Back to Account */
    await returnToAccount(page, accountName);
    console.log('Returned to Account before Consumer Credit Review.');

    lap('start STEP 19 (consumer credit review)');
    /* STEP 19 - Click Consumer Credit Review (direct or via Show More Actions) */
    await clickAccountAction(page, /^Consumer Credit Review$/i);
    console.log('Consumer Credit Review clicked.');

    /* STEP 20 - Consumer iframe */
    const { element: consumerFrameElement, frame: consumerFrame } =
      getVfFrame(page);

    await expect(consumerFrameElement).toBeVisible({ timeout: 60000 });
    await waitForCreditReportPage(consumerFrame);
    console.log('Request Consumer Credit Reports page loaded.');
    await captureScreenshot(page, testInfo, 'consumer-request-page');

    /* STEP 21 - Count available contacts */
    const availableConsumerContactCount =
      await getAvailableConsumerContactCount(consumerFrame);

    if (availableConsumerContactCount === 0) {
      const cancelButton = consumerFrame
        .getByRole('button', { name: /^Cancel$/i })
        .first();

      if (await isVisible(cancelButton)) await cancelButton.click();

      throw new Error(
        `No Consumer contacts are available for account "${accountName}".`
      );
    }

    /* STEP 22 - Select all contacts */
    const selectedConsumerContactCount =
      await selectConsumerContacts(consumerFrame);

    if (selectedConsumerContactCount === 0) {
      throw new Error('No Consumer contact checkboxes could be selected.');
    }

    if (selectedConsumerContactCount !== availableConsumerContactCount) {
      throw new Error(
        `Contact/checkbox mismatch. Contacts=${availableConsumerContactCount}, selected=${selectedConsumerContactCount}`
      );
    }

    console.log(
      `${selectedConsumerContactCount} Consumer contact(s) selected.`
    );
    await captureScreenshot(page, testInfo, 'consumer-contacts-selected');

    /* STEP 23 - Request Reports */
    const requestReportsButton = consumerFrame
      .getByRole('button', { name: /request reports/i })
      .or(consumerFrame.locator('input[value*="Request Reports" i]'))
      .first();

    await expect(requestReportsButton).toBeVisible({ timeout: 30000 });
    await expect(requestReportsButton).toBeEnabled({ timeout: 30000 });
    await requestReportsButton.click();
    console.log('Request Reports clicked.');
    await captureScreenshot(page, testInfo, 'consumer-request-submitted');

    lap('start STEP 24 (wait done)');
    /* STEP 24 - Wait for processing, classify HIT / NO-HIT, click Done */
    const consumerResults = await clickDoneAfterRequest(
      page,
      testInfo,
      selectedConsumerContactCount
    );
    const consumerHitCount = consumerResults.expectedReportCount;

    /* STEP 25 - Confirm return */
    await page.waitForURL(ACCOUNT_VIEW_URL, { timeout: 60000 });
    await waitForAccountPage(page, accountName);
    console.log('Returned to Account after Consumer Credit Review.');

    /*
     * STEP 25b - ALL contacts NO-HIT (e.g. account has only 1 contact and it is NO-HIT):
     * verify the NO-HIT outcome (no report created) and END the test here.
     */
    if (consumerHitCount === 0) {
      lap('all contacts NO-HIT - validating and ending');
      await validateAllNoHitOutcome(
        page,
        testInfo,
        accountName,
        consumerReportCountBefore,
        consumerReportNamesBefore,
        consumerResults,
        selectedConsumerContactCount
      );
      lap('finished (all NO-HIT)');
      return;
    }

    lap('start STEP 26 (validate consumer)');
    /* STEP 26-27 - Validate Consumer Reports persisted (HIT contacts only) */
    await openReportViewAll(page, /Equifax Consumer Reports/i);

    const expectedConsumerReportCount =
      consumerReportCountBefore + consumerHitCount;

    console.log(
      `Consumer Reports expected count: ${expectedConsumerReportCount} (${consumerHitCount} HIT counted, ${consumerResults.noHitContacts.length} NO-HIT excluded, of ${selectedConsumerContactCount} selected)`
    );

    const consumerReportCountAfter = await waitForReportCount(
      page,
      'Consumer',
      consumerReportCountBefore,
      expectedConsumerReportCount,
      true,
      consumerReportNamesBefore
    );

    const actualConsumerReportDelta =
      consumerReportCountAfter - consumerReportCountBefore;
    if (actualConsumerReportDelta !== consumerHitCount) {
      throw new Error(
        `Consumer report delta mismatch. Selected=${selectedConsumerContactCount}, HIT=${consumerHitCount}, NO-HIT=${consumerResults.noHitContacts.length}, ` +
          `expected new reports=${consumerHitCount}, actual new reports=${actualConsumerReportDelta}.`
      );
    }

    console.log(
      `Consumer Credit Review completed. Consumer Reports changed from ${consumerReportCountBefore} to ${consumerReportCountAfter}; new reports=${actualConsumerReportDelta}, HIT=${consumerHitCount}, NO-HIT excluded=${consumerResults.noHitContacts.length}.`
    );
    await captureScreenshot(page, testInfo, 'consumer-reports-after');

    lap('start STEP 28 (consumer screenshots)');
    /* STEP 28 - Screenshot only the NEW Consumer reports of HIT contacts */
    await captureNewConsumerReportScreenshots(
      page,
      testInfo,
      consumerReportNamesBefore,
      consumerResults
    );

    lap('start STEP 29 (commercial capture)');
    /* STEP 29 - Capture ONLY the Commercial report created by this run (waits for PDF to render) */
    await returnToAccount(page, accountName);
    await openReportViewAll(page, /Equifax Commercial Reports/i);
    await captureNewReportScreenshot(
      page,
      testInfo,
      'Commercial',
      commercialReportNamesBefore
    );

    lap('finished');
    console.log('Consumer Credit Review validation completed.');

    return;
  }
);