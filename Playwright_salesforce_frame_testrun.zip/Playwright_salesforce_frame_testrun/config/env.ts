import dotenv from 'dotenv';

dotenv.config();

export const env = {
  subscriberOrgId: process.env.SUBSCRIBER_ORG_ID,
  baseUrl: process.env.LMA_URL,
  username: process.env.LMA_USERNAME,
  password: process.env.LMA_PASSWORD,
};

if (!env.baseUrl) {
  throw new Error('LMA_URL is missing in .env');
}

if (!env.username) {

  throw new Error('LMA_USERNAME is missing in .env');
}

if (!env.password) {
  throw new Error('LMA_PASSWORD is missing in .env');
}