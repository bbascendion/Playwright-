import fs from 'fs';
import path from 'path';
import { Page, TestInfo } from '@playwright/test';

function sanitizeFileName(value: string): string {
  return value
    .trim()
    .replace(/[^a-zA-Z0-9-_]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .toLowerCase();
}

export async function captureScreenshot(
  page: Page,
  testInfo: TestInfo,
  screenshotName: string
): Promise<string> {
  const safeName = sanitizeFileName(screenshotName);
  const timestamp = Date.now();

  const screenshotPath = testInfo.outputPath(
    'screenshots',
    `${timestamp}-${safeName}.png`
  );

  fs.mkdirSync(path.dirname(screenshotPath), {
    recursive: true,
  });

  await page.waitForTimeout(300);

  await page.screenshot({
    path: screenshotPath,
    fullPage: true,
    animations: 'disabled',
  });

  /*
   * Mandatory for the custom Excel reporter.
   * The reporter reads result.attachments.
   */
  await testInfo.attach(safeName, {
    path: screenshotPath,
    contentType: 'image/png',
  });

  console.log(
    `Screenshot captured and attached: ${safeName} -> ${screenshotPath}`
  );

  return screenshotPath;
}