import fs from 'fs';
import path from 'path';
 
const csvFileCandidates = [
  path.resolve(
    process.cwd(),
    'test-data',
    'salesfrocedataauto.csv'
  ),
  path.resolve(
    process.cwd(),
    'data',
    'salesfrocedataauto.csv'
  ),
  path.resolve(
    __dirname,
    '..',
    'test-data',
    'salesfrocedataauto.csv'
  )
];
 
const csvFilePath =
  csvFileCandidates.find(candidate =>
    fs.existsSync(candidate)
  ) || csvFileCandidates[0];
 
function parseCsvLine(line: string): string[] {
  const values: string[] = [];
  let current = '';
  let inQuotes = false;
 
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
 
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      values.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
 
  values.push(current.trim());
 
  return values;
}
 
function normalizeHeader(header: string): string {
  return header
    .replace(/^"|"$/g, '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ');
}
 
export function getRandomAccountName(): string {
  if (!fs.existsSync(csvFilePath)) {
    throw new Error(
      `Salesforce data CSV file not found: ${csvFilePath}`
    );
  }
 
  const csvContent = fs.readFileSync(
    csvFilePath,
    'utf-8'
  );
 
  const lines = csvContent
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(Boolean);
 
  if (lines.length < 2) {
    throw new Error(
      'salesfrocedataauto.csv does not contain any account data.'
    );
  }
 
  const headers = parseCsvLine(lines[0]).map(
    normalizeHeader
  );
 
  const accountNameColumnCandidates = [
    'account name',
    'accountname',
    'account_name',
    'forseva1__account__r.name',
    'forseva1__account__r name',
  ];
 
  const accountNameColumnIndex =
    headers.findIndex(header =>
      accountNameColumnCandidates.includes(header)
    );
 
  if (accountNameColumnIndex === -1) {
    throw new Error(
      `Account Name column was not found in salesfrocedataauto.csv.
 
Available columns:
${headers.join(', ')}`
    );
  }
 
  const accountNames: string[] = [];
 
  for (let i = 1; i < lines.length; i++) {
    const values = parseCsvLine(lines[i]);
 
    const accountName =
      values[accountNameColumnIndex]?.trim();
 
    if (accountName) {
      accountNames.push(accountName);
    }
  }
 
  if (accountNames.length === 0) {
    throw new Error(
      'No valid Account Names were found in salesfrocedataauto.csv.'
    );
  }
 
  const randomIndex = Math.floor(
    Math.random() * accountNames.length
  );
 
  const selectedAccount =
    accountNames[randomIndex];
 
  console.log(
    `Random Account selected from CSV: ${selectedAccount}`
  );
 
  return selectedAccount;
}
 
// ===========================================================================
// ADDITIONAL: full-row record (name + Billing Address fields), for tests
// that need to create the Account if it doesn't already exist. This reuses
// the same csvFilePath / parseCsvLine / normalizeHeader as
// getRandomAccountName() above, unchanged, and adds nothing to that
// function's own behavior.
// ===========================================================================
 
export interface AccountRecord {
  name: string;
  billingStreet?: string;
  billingCity?: string;
  billingState?: string;
  billingPostalCode?: string;
  billingCountry?: string;
}
 
/**
 * Finds the first header matching any of the given normalized candidates.
 * Returns -1 if none match, same convention as Array.prototype.findIndex.
 */
function findColumnIndex(
  headers: string[],
  candidates: string[]
): number {
  return headers.findIndex(header => candidates.includes(header));
}
 
/**
 * Same column-name candidates used by getRandomAccountName(), duplicated
 * here (not shared) so a future edit to one never silently changes the
 * other's behavior.
 */
const ACCOUNT_NAME_COLUMN_CANDIDATES = [
  'account name',
  'accountname',
  'account_name',
  'forseva1__account__r.name',
  'forseva1__account__r name',
];
 
const BILLING_STREET_COLUMN_CANDIDATES = [
  'billing street',
  'billingstreet',
  'billing_street',
  'forseva1__address1__c',
  'address1',
  'address',
];
 
const BILLING_CITY_COLUMN_CANDIDATES = [
  'billing city',
  'billingcity',
  'billing_city',
  'forseva1__account__r.billingcity',
  'forseva1__account__r billingcity',
];
 
const BILLING_STATE_COLUMN_CANDIDATES = [
  'billing state',
  'billing state/province',
  'billingstate',
  'billing_state',
  'forseva1__account__r.billingstate',
  'forseva1__account__r billingstate',
];
 
const BILLING_POSTAL_CODE_COLUMN_CANDIDATES = [
  'billing zip/postal code',
  'billing postal code',
  'billingpostalcode',
  'billing_postal_code',
  'billing zip',
  'forseva1__account__r.billingpostalcode',
  'forseva1__account__r billingpostalcode',
];
 
const BILLING_COUNTRY_COLUMN_CANDIDATES = [
  'billing country',
  'billingcountry',
  'billing_country',
  'forseva1__account__r.billingcountry',
  'forseva1__account__r billingcountry',
];
 
/**
 * Reads a value from a parsed CSV row by column index, trims it, and
 * returns undefined for an empty cell rather than an empty string — so
 * callers can skip filling a form field instead of clearing it.
 */
function cellOrUndefined(
  values: string[],
  columnIndex: number
): string | undefined {
  if (columnIndex === -1) {
    return undefined;
  }
 
  const raw = values[columnIndex]?.trim();
  return raw && raw.length > 0 ? raw : undefined;
}
 
/**
 * Picks one random row from salesfrocedataauto.csv and returns it as an
 * AccountRecord, including the Billing Address fields needed if the
 * account has to be created (it doesn't already exist in the org).
 *
 * The account Name is trimmed of surrounding WHITESPACE only — not of a
 * trailing comma some rows carry as part of the literal name (e.g.
 * "FLORIST/MONO.PLUS BREEIJEN,") — since that comma is real data that must
 * match exactly in Salesforce.
 */
export function getRandomAccountRecord(
  eligibleAccountNames?: string[]
): AccountRecord {
  if (!fs.existsSync(csvFilePath)) {
    throw new Error(
      `Salesforce data CSV file not found: ${csvFilePath}`
    );
  }
 
  const csvContent = fs.readFileSync(csvFilePath, 'utf-8');
 
  const lines = csvContent
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(Boolean);
 
  if (lines.length < 2) {
    throw new Error(
      'salesfrocedataauto.csv does not contain any account data.'
    );
  }
 
  const headers = parseCsvLine(lines[0]).map(normalizeHeader);
 
  const nameColumnIndex = findColumnIndex(
    headers,
    ACCOUNT_NAME_COLUMN_CANDIDATES
  );
 
  if (nameColumnIndex === -1) {
    throw new Error(
      `Account Name column was not found in salesfrocedataauto.csv.
 
Available columns:
${headers.join(', ')}`
    );
  }
 
  const streetColumnIndex = findColumnIndex(
    headers,
    BILLING_STREET_COLUMN_CANDIDATES
  );
  const cityColumnIndex = findColumnIndex(
    headers,
    BILLING_CITY_COLUMN_CANDIDATES
  );
  const stateColumnIndex = findColumnIndex(
    headers,
    BILLING_STATE_COLUMN_CANDIDATES
  );
  const postalCodeColumnIndex = findColumnIndex(
    headers,
    BILLING_POSTAL_CODE_COLUMN_CANDIDATES
  );
  const countryColumnIndex = findColumnIndex(
    headers,
    BILLING_COUNTRY_COLUMN_CANDIDATES
  );
 
  const logMissing = (label: string, index: number) => {
    if (index === -1) {
      console.log(
        `"${label}" column was not found in salesfrocedataauto.csv; that field will be left blank when creating a new Account.`
      );
    }
  };
 
  logMissing('Billing Street', streetColumnIndex);
  logMissing('Billing City', cityColumnIndex);
  logMissing('Billing State', stateColumnIndex);
  logMissing('Billing Postal Code', postalCodeColumnIndex);
  logMissing('Billing Country', countryColumnIndex);
 
  const records: AccountRecord[] = [];
 
  for (let i = 1; i < lines.length; i++) {
    const values = parseCsvLine(lines[i]);
 
    // Trim WHITESPACE only, preserving any trailing comma that is part of
    // the actual account name.
    const rawName = values[nameColumnIndex] ?? '';
    const name = rawName.replace(/^\s+|\s+$/g, '');
 
    if (!name) {
      continue;
    }
 
    records.push({
      name,
      billingStreet: cellOrUndefined(values, streetColumnIndex),
      billingCity: cellOrUndefined(values, cityColumnIndex),
      billingState: cellOrUndefined(values, stateColumnIndex),
      billingPostalCode: cellOrUndefined(values, postalCodeColumnIndex),
      billingCountry: cellOrUndefined(values, countryColumnIndex),
    });
  }
 
  if (records.length === 0) {
    throw new Error(
      'No valid Account rows were found in salesfrocedataauto.csv.'
    );
  }
 
  const eligibleNames = eligibleAccountNames
    ? new Set(eligibleAccountNames.map(name => name.trim().toLowerCase()))
    : undefined;
  const candidateRecords = eligibleNames
    ? records.filter(record => eligibleNames.has(record.name.toLowerCase()))
    : records;

  if (candidateRecords.length === 0) {
    throw new Error(
      'No accounts in salesfrocedataauto.csv matched the supplied eligible account names.'
    );
  }

  const randomIndex = Math.floor(Math.random() * candidateRecords.length);
  const selectedRecord = candidateRecords[randomIndex];
 
  console.log(
    `Random Account record selected from CSV: ${JSON.stringify(selectedRecord)}`
  );
 
  return selectedRecord;
}
 