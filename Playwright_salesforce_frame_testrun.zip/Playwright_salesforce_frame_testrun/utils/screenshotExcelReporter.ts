import * as fs from 'fs';
import * as path from 'path';
import type {
  FullConfig,
  Reporter,
  Suite,
  TestCase,
  TestResult,
} from '@playwright/test/reporter';
import {
  createScreenshotExcelReport,
  type ScreenshotReportEntry,
} from './createScreenshotExcelReport';

function formatRunTimestamp(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  return `${year}${month}${day}_${hours}${minutes}${seconds}`;
}

function compareTests(rootDir: string, left: TestCase, right: TestCase): number {
  const leftFile = path.relative(rootDir, left.location.file).toLowerCase();
  const rightFile = path.relative(rootDir, right.location.file).toLowerCase();

  return (
    leftFile.localeCompare(rightFile) ||
    left.location.line - right.location.line ||
    left.location.column - right.location.column ||
    left.title.localeCompare(right.title) ||
    left.id.localeCompare(right.id)
  );
}

export default class ScreenshotExcelReporter implements Reporter {
  private reportDirectory = '';
  private runDirectory = '';
  private readonly testCaseIds = new Map<string, string>();
  private readonly testEvidence = new Map<
    string,
    {
      testCaseId: string;
      retry: number;
      screenshots: ScreenshotReportEntry[];
    }
  >();
  private runPrefix = '';

  onBegin(config: FullConfig, suite: Suite): void {
    const projectDirectory = config.configFile
      ? path.dirname(config.configFile)
      : config.rootDir;
    this.reportDirectory = path.resolve(
      projectDirectory,
      'test-artifacts',
      'screenshot-reports'
    );
    const tests = suite.allTests().sort((left, right) =>
      compareTests(config.rootDir, left, right)
    );
    tests.forEach((test, index) => {
      this.testCaseIds.set(test.id, `TC-${String(index + 1).padStart(3, '0')}`);
    });

    this.runPrefix = `RUN_${formatRunTimestamp(new Date())}`;
    console.log(`Screenshot Excel reporting enabled under: ${this.reportDirectory}`);
  }

  onTestEnd(test: TestCase, result: TestResult): void {
    const testCaseId =
      this.testCaseIds.get(test.id) ??
      `TC-${String(this.testCaseIds.size + 1).padStart(3, '0')}`;
    this.testCaseIds.set(test.id, testCaseId);

    // Filter PNG screenshots
    const screenshots = result.attachments
      .filter((attachment) => attachment.contentType === 'image/png')
      .filter(
        (attachment) =>
          !attachment.path?.endsWith(
            'cfeb82c674bc3c40727d615cbaba4fa0ee6806fb.png'
          )
      )
      .map((attachment) => ({
        attachment,
        testTitle: test.titlePath().filter(Boolean).join(' › '),
        testStatus: result.status,
      }));

    const previous = this.testEvidence.get(test.id);
    if (!previous || result.retry >= previous.retry) {
      this.testEvidence.set(test.id, {
        testCaseId,
        retry: result.retry,
        screenshots,
      });
    }
  }

  async onEnd(): Promise<void> {
    const evidence = [...this.testEvidence.values()]
      .filter(({ screenshots }) => screenshots.length > 0)
      .sort((left, right) => left.testCaseId.localeCompare(right.testCaseId));

    if (evidence.length === 0) {
      console.log(
        `No PNG screenshots were attached to this test run; no Excel reports were created under ${this.reportDirectory}.`
      );
      return;
    }

    this.runDirectory = this.createRunDirectory(this.runPrefix);
    console.log(`Screenshot evidence for this run will be saved to: ${this.runDirectory}`);

    for (const testEvidence of evidence) {
  const reportPath = path.join(
    this.runDirectory,
    `${testEvidence.testCaseId}_evidence.xlsx`
  );

  await createScreenshotExcelReport(
    testEvidence.screenshots,
    reportPath
  );

  console.log(
    `Created ${testEvidence.testCaseId} Excel evidence with ${testEvidence.screenshots.length} screenshot(s): ${reportPath}`
  );
}

    console.log(
      `Screenshot Excel Reporter: Created ${evidence.length} evidence report(s) in ${this.runDirectory}`
    );
  }

  private createRunDirectory(runPrefix: string): string {
    fs.mkdirSync(this.reportDirectory, { recursive: true });
    let runDirectory = path.join(this.reportDirectory, runPrefix);
    let collisionNumber = 1;

    while (true) {
      try {
        fs.mkdirSync(runDirectory);
        return runDirectory;
      } catch (error) {
        if (
          !(error instanceof Error) ||
          !('code' in error) ||
          error.code !== 'EEXIST'
        ) {
          throw error;
        }

        runDirectory = path.join(
          this.reportDirectory,
          `${runPrefix}_${String(collisionNumber).padStart(3, '0')}`
        );
        collisionNumber++;
      }
    }
  }
}
