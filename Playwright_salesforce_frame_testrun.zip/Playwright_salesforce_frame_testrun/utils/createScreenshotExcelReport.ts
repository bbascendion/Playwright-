import * as fs from 'fs';
import ExcelJS from 'exceljs';
import type { TestResult } from '@playwright/test/reporter';

export type ScreenshotReportEntry = {
  attachment: TestResult['attachments'][number];
  testTitle: string;
  testStatus: string;
};

/*
 * Excel layout
 *
 * Sheet: Screenshots
 * A = Screenshot
 * B = Test
 * C = Status
 * D = Image
 */
const COLUMN_WIDTHS = [42, 64, 14, 90];
const ROW_HEIGHT_PT = 286.05;

/*
 * Image box
 */
const MAX_IMAGE_WIDTH_PX = 620;
const MAX_IMAGE_HEIGHT_PX = 365;
const IMAGE_OFFSET_PX = 6;

/*
 * Screenshot order
 *
 * startsWith() is intentionally used so dynamic IDs such as
 * EfxConsumer-387 or Equifax-CC-137 keep working between executions.
 */
const SCREENSHOT_ORDER = [
  'org-subscribers',
  'login-successful',
  'account-contacts-ready',
  'commercial-reports-before',
  'review-credit-start',
  'review-credit-response',
  'commercial-reports-after',
  'consumer-reports-before',
  'consumer-request-page',
  'consumer-contacts-selected',
  'consumer-request-submitted',
  'consumer-processing-complete',
  'consumer-no-hit-result',
  'consumer-reports-after',
  'consumer-report-EfxConsumer-',
  'commercial-report-Equifax-CC-',
];

/**
 * Gets the expected ordering position of a screenshot.
 *
 * startsWith() is intentionally used so screenshots containing
 * dynamic IDs continue to be placed correctly.
 */
function getScreenshotOrder(name: string): number {
  const normalizedName = name
    .replace(/\.png$/i, '')
    .trim();

  const index = SCREENSHOT_ORDER.findIndex((expectedName) =>
    normalizedName.startsWith(expectedName)
  );

  /*
   * Any screenshot that is not included in SCREENSHOT_ORDER
   * is placed after known screenshots.
   */
  return index === -1
    ? Number.MAX_SAFE_INTEGER
    : index;
}

/**
 * Sort screenshot entries without modifying the original array.
 *
 * If multiple screenshots have the same order value,
 * their original capture order is retained.
 */
function sortScreenshotEntries(
  entries: ScreenshotReportEntry[]
): ScreenshotReportEntry[] {
  return entries
    .map((entry, originalIndex) => ({
      entry,
      originalIndex,
    }))
    .sort((a, b) => {
      const aOrder = getScreenshotOrder(
        a.entry.attachment.name
      );

      const bOrder = getScreenshotOrder(
        b.entry.attachment.name
      );

      if (aOrder !== bOrder) {
        return aOrder - bOrder;
      }

      /*
       * Important:
       * Preserve original capture order for screenshots
       * having the same screenshot-order prefix.
       */
      return a.originalIndex - b.originalIndex;
    })
    .map(({ entry }) => entry);
}

/**
 * Keep screenshots only up to and including the first
 * commercial report detail screenshot.
 *
 * Examples:
 *
 * commercial-report-Equifax-CC-137-detail
 * commercial-report-Equifax-CC-126-detail
 *
 * Because the Equifax ID is dynamic, we do NOT hardcode 137.
 *
 * Anything captured after the detail screenshot is removed
 * from the Excel report.
 */
function limitEntriesToCommercialReportDetail(
  entries: ScreenshotReportEntry[]
): ScreenshotReportEntry[] {
  const detailScreenshotIndex = entries.findIndex(
    (entry) => {
      const normalizedName =
        entry.attachment.name
          .replace(/\.png$/i, '')
          .trim();

      return (
        normalizedName.startsWith(
          'commercial-report-Equifax-CC-'
        ) &&
        normalizedName.endsWith('-detail')
      );
    }
  );

  /*
   * If the expected commercial detail screenshot
   * doesn't exist, retain the complete sorted list.
   *
   * This avoids accidentally deleting legitimate
   * screenshots when the detail screenshot was
   * not captured in a particular execution.
   */
  if (detailScreenshotIndex === -1) {
    console.warn(
      'Commercial report detail screenshot was not found. ' +
        'Keeping all sorted screenshots.'
    );

    return entries;
  }

  /*
   * slice end index is exclusive.
   *
   * +1 ensures the commercial detail screenshot itself
   * remains in the report.
   */
  return entries.slice(
    0,
    detailScreenshotIndex + 1
  );
}

/**
 * Reads screenshot PNG either from attachment.body
 * or attachment.path.
 */
function readPng(
  entry: ScreenshotReportEntry
): Buffer | null {
  const { attachment } = entry;

  if (attachment.body) {
    return Buffer.from(attachment.body);
  }

  if (
    attachment.path &&
    fs.existsSync(attachment.path)
  ) {
    return fs.readFileSync(
      attachment.path
    );
  }

  return null;
}

/**
 * Reads PNG width and height from the PNG header.
 * This keeps the screenshot aspect ratio intact.
 */
function pngSize(
  buffer: Buffer
): {
  width: number;
  height: number;
} {
  const isPng =
    buffer.length >= 24 &&
    buffer.toString(
      'ascii',
      1,
      4
    ) === 'PNG';

  if (!isPng) {
    return {
      width: 1280,
      height: 720,
    };
  }

  return {
    width: buffer.readUInt32BE(16),
    height: buffer.readUInt32BE(20),
  };
}

/**
 * Resize screenshot while maintaining aspect ratio.
 */
function fitSize(
  width: number,
  height: number
): {
  width: number;
  height: number;
} {
  const scale = Math.min(
    MAX_IMAGE_WIDTH_PX / width,
    MAX_IMAGE_HEIGHT_PX / height,
    1
  );

  return {
    width: Math.round(
      width * scale
    ),

    height: Math.round(
      height * scale
    ),
  };
}

/**
 * Creates the final screenshot Excel report.
 */
export async function createScreenshotExcelReport(
  entries: ScreenshotReportEntry[],
  reportPath: string
): Promise<void> {
  const workbook =
    new ExcelJS.Workbook();

  const sheet =
    workbook.addWorksheet(
      'Screenshots'
    );

  /*
   * Excel columns
   */
  sheet.columns = [
    {
      header: 'Screenshot',
      key: 'name',
      width: COLUMN_WIDTHS[0],
    },
    {
      header: 'Test',
      key: 'test',
      width: COLUMN_WIDTHS[1],
    },
    {
      header: 'Status',
      key: 'status',
      width: COLUMN_WIDTHS[2],
    },
    {
      header: 'Image',
      key: 'image',
      width: COLUMN_WIDTHS[3],
    },
  ];

  /*
   * Header formatting
   */
  const header =
    sheet.getRow(1);

  header.font = {
    bold: true,
    name: 'Calibri',
    size: 11,
  };

  header.alignment = {
    vertical: 'middle',
    horizontal: 'left',
  };

  /*
   * STEP 1:
   * Sort all screenshots into the required sequence.
   */
  const sortedEntries =
    sortScreenshotEntries(entries);

  /*
   * STEP 2:
   * Keep screenshots only through the final required
   * commercial report detail screenshot.
   *
   * For example:
   *
   * commercial-report-Equifax-CC-137-detail
   *
   * Any screenshots captured after that are excluded
   * and therefore cannot create extra Excel rows.
   */
  const orderedEntries =
    limitEntriesToCommercialReportDetail(
      sortedEntries
    );

  /*
   * Debug output showing exactly what will
   * be written into Excel.
   */
  console.log(
    '\nScreenshot Excel report order:'
  );

  orderedEntries.forEach(
    (entry, index) => {
      console.log(
        `${index + 1}. ${entry.attachment.name}`
      );
    }
  );

  /*
   * Also report screenshots that were excluded.
   */
  if (
    orderedEntries.length <
    sortedEntries.length
  ) {
    console.log(
      '\nScreenshots excluded from Excel:'
    );

    sortedEntries
      .slice(orderedEntries.length)
      .forEach((entry) => {
        console.log(
          `Excluded: ${entry.attachment.name}`
        );
      });
  }

  let rowNumber = 2;

  /*
   * Write screenshots into Excel
   * in the required order.
   */
  for (
    const entry of orderedEntries
  ) {
    const png =
      readPng(entry);

    if (!png) {
      console.log(
        `Skipping screenshot "${entry.attachment.name}" - no file or body found.`
      );

      continue;
    }

    /*
     * Create Excel row.
     */
    const row =
      sheet.getRow(rowNumber);

    row.getCell(1).value =
      entry.attachment.name;

    row.getCell(2).value =
      entry.testTitle;

    row.getCell(3).value =
      entry.testStatus;

    row.height =
      ROW_HEIGHT_PT;

    /*
     * Cell formatting.
     */
    for (
      let col = 1;
      col <= 4;
      col++
    ) {
      row.getCell(
        col
      ).alignment = {
        vertical: 'top',
        horizontal: 'left',
        wrapText: true,
      };
    }

    /*
     * Add screenshot image
     * to workbook.
     */
    const imageId =
      workbook.addImage({
        buffer: png as any,
        extension: 'png',
      });

    const dimensions =
      pngSize(png);

    const size =
      fitSize(
        dimensions.width,
        dimensions.height
      );

    /*
     * Column D = index 3 because
     * ExcelJS image anchors use
     * zero-based columns.
     */
    sheet.addImage(
      imageId,
      {
        tl: {
          col:
            3 +
            IMAGE_OFFSET_PX /
              (
                COLUMN_WIDTHS[3] *
                  7 +
                5
              ),

          row:
            rowNumber -
            1 +
            IMAGE_OFFSET_PX /
              (
                ROW_HEIGHT_PT *
                (96 / 72)
              ),
        },

        ext: {
          width: size.width,
          height: size.height,
        },

        editAs: 'oneCell',
      }
    );

    row.commit();

    rowNumber++;
  }

  /*
   * Save final Excel report.
   */
  await workbook.xlsx.writeFile(
    reportPath
  );

  console.log(
    `\nScreenshot Excel report created successfully: ${reportPath}`
  );

  console.log(
    `Total screenshots added to Excel: ${orderedEntries.length}`
  );
}